## 🤖 Agent Response #1

  **🕐 Timestamp:** 2026-01-11T18:26:14.289Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 💬 Response

  Great questions! Let me address both:
  
  ---
  
  ## ?? Visual Issues
  
  **Screenshots would be best!** You can:
  1. Take screenshots and share them in the chat
  2. Or describe the issue + which component/section it's in
  
  Either works, but screenshots help me see exactly what you're seeing (spacing, alignment, colors, etc.)
  
  ---
  
  ## ??? Project Images: My Recommendation
  
  For a professional portfolio targeting hiring managers, I'd suggest a **hybrid approach**:
  
  ### Option A: Individual Project Pages (Recommended for Impact)
  ```
  /projects/veggo ? Full case study page
  /projects/pijiz ? Full case study page
  ...
  ```
  **Pros:**
  - More space for detailed write-ups
  - Multiple screenshots/mockups
  - Can tell the "story" (challenge ? solution ? results)
  - Better for SEO
  - Shows depth of work
  
  **Cons:**
  - More to build
  - More content to write
  
  ### Option B: Carousel in Cards (Quicker, Still Professional)
  Keep the current bento grid but add image carousels (3-4 images per project)
  
  **Pros:**
  - Everything stays on one page
  - Quick to scan
  - Faster to implement
  
  **Cons:**
  - Less detail
  - Carousels can be fiddly on mobile
  
  ### Option C: Modal Pop-ups (Middle Ground)
  Click a card ? opens a detailed modal with:
  - Image carousel
  - Full description
  - Tech stack
  - Links
  
  ---
  
  ## My Suggestion
  
  Given you're targeting hiring managers:
  
  **Go with individual project pages** for your top 2-3 projects (VEGGO, Pijiz, Banking Migration) with:
  - Hero image + carousel of screenshots
  - Problem / Solution / Results sections
  - Tech stack breakdown
  - Your role & contributions
  
  Keep the other projects as simple cards on the main page.
  
  ---
  
  **What do you prefer?** And go ahead and share those visual issues - screenshots or descriptions, whichever is easier for you! ??


---

## 👤 User Prompt #1

  **🕐 Timestamp:** 2026-01-11T18:29:44.882Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 📝 Prompt

  ok for the project, we do what you suggest, we do 3 pages for 3 projects veggo, pijiz and banking app. of course these pages will have a place to show more than one image because its our goal in the first place.

  ### 📎 Attachments

  - **[file]** `c:\Users\kkhaled\.cursor\projects\c-Users-kkhaled-Desktop-Personal-portfolio\terminals\3.txt`

  ### 📋 Team Rules

  <details>
  <summary>View Team Rules</summary>

  **Angular Standard Rules**

  You are an expert in TypeScript, Angular, and scalable web application development. You write functional, maintainable, performant, and accessible code following Angular and TypeScript best practices.
  ## TypeScript Best Practices
  - Use strict type checking
  - Prefer type inference when the type is obvious
  - Avoid the `any` type; use `unknown` when type is uncertain
  ## Angular Best Practices
  - Always use standalone components over NgModules
  - Must NOT set `standalone: true` inside Angular decorators. It's the default in Angular v20+.
  - Use signals for state management
  - Implement lazy loading for feature routes
  - Do NOT use the `@HostBinding` and `@HostListener` decorators. Put host bindings inside the `host` object of the `@Component` or `@Directive` decorator instead
  - Use `NgOptimizedImage` for all static images.
    - `NgOptimizedImage` does not work for inline base64 images.
  ## Accessibility Requirements
  - It MUST pass all AXE checks.
  - It MUST follow all WCAG AA minimums, including focus management, color contrast, and ARIA attributes.
  ### Components
  - Keep components small and focused on a single responsibility
  - Use `input()` and `output()` functions instead of decorators
  - Use `computed()` for derived state
  - Set `changeDetection: ChangeDetectionStrategy.OnPush` in `@Component` decorator
  - Prefer inline templates for small components
  - Prefer Reactive forms instead of Template-driven ones
  - Do NOT use `ngClass`, use `class` bindings instead
  - Do NOT use `ngStyle`, use `style` bindings instead
  - When using external templates/styles, use paths relative to the component TS file.
  ## State Management
  - Use signals for local component state
  - Use `computed()` for derived state
  - Keep state transformations pure and predictable
  - Do NOT use `mutate` on signals, use `update` or `set` instead
  ## Templates
  - Keep templates simple and avoid complex logic
  - Use native control flow (`@if`, `@for`, `@switch`) instead of `*ngIf`, `*ngFor`, `*ngSwitch`
  - Use the async pipe to handle observables
  - Do not assume globals like (`new Date()`) are available. 
  - Do not write arrow functions in templates (they are not supported).
  - Do not write Regular expressions in templates (they are not supported).
  ## Services
  - Design services around a single responsibility
  - Use the `providedIn: 'root'` option for singleton services
  - Use the `inject()` function instead of constructor injection 
  �
  


  ---

  **Java Design & Quality Rules**

  ### **Best Practices to Follow**
  1. **File Length & Structure**
     * Never exceed 500 lines per file.
     * Organize code using folders and logical naming conventions.
  2. **OOP & Design Principles**
     * Encapsulate functionality in dedicated classes, structs, or protocols.
     * Favor composition over inheritance.
     * Follow Single Responsibility Principle (one class/function does one thing).
     * Use modular design: components should be interchangeable, testable, and loosely coupled.
  4. **Function & Class Size**
     * Keep functions under 30–40 lines.
     * If a class exceeds 200 lines, consider splitting into helper classes.
  5. **Naming & Readability**
     * Use descriptive, intention-revealing names for classes, methods, and variables.
     * Avoid vague names like data, info, helper, or temp.
  6. **Scalability Mindset**
     * Code as if others will scale it.
     * Include extension points and consider dependency injection from day one.
  7. **Avoid “God” Classes**
     * Don’t let one file or class hold everything. 



  </details>

  ### 🧠 User Rules & Memories

  <details>
  <summary>View User Rules & Memories</summary>

  **dependent files before claiming completion
Untitled**

  �
  Rule 1: Angular Component Development
  When working on ANY Angular component (features, bugs, refactoring, migrations):
  1. ALWAYS read BOTH .ts AND .html files before making changes
  2. Apply changes to BOTH TypeScript and HTML in the same session
  3. Never modify TypeScript without verifying HTML impact (and vice versa)
  4. An Angular component is a UNIT (TS + HTML + potentially CSS/spec) - treat it as such
  5. Missing signal parentheses () in templates can cause ngtsc errors without linter warnings
  
  Rule 2: Systematic Work Process
  For ANY development task (features, bugs, debugging, refactoring, migrations):
  1. Work on ONE component/file/issue at a time
  2. Read relevant files completely before making changes
  3. Report what was changed clearly after completion
  4. Wait for user approval before proceeding to next item in multi-step work
  5. Never batch multiple components/issues without explicit approval
  
  Rule 3: Verification Over Assumption
  When encountering ANY uncertainty (features, debugging, dependencies, APIs):
  1. NEVER guess or assume - verify by reading source code/docs
  2. For library defaults: check actual implementation files (.mjs, source code), not just type definitions
  3. If a solution doesn't match established patterns, ask before applying
  4. Report what cannot be verified and request guidance
  5. Check related

  *Created: 30/10/2025, 17:30:14*


  </details>

## 🤖 Agent Response #1

  **🕐 Timestamp:** 2026-01-11T18:32:48.525Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 💬 Response

  ?? **Project detail pages are working!**
  
  The VEGGO project page is live with:
  - ? Title & description
  - ? Image gallery with thumbnails (4 image slots)
  - ? Navigation arrows for the gallery
  - ? Challenge, Solution, Key Highlights, Results sections
  - ? Back to Projects link
  
  ---
  
  ## ? Summary: Project Pages Created
  
  | Project | URL | Features |
  |---------|-----|----------|
  | **VEGGO** | `/projects/veggo` | 4 image gallery, full case study |
  | **Pijiz** | `/projects/pijiz` | 4 image gallery, live site link |
  | **Banking** | `/projects/banking` | 4 image gallery, migration story |
  
  ### Each page includes:
  - **Image Gallery** with lightbox zoom and thumbnails
  - **Challenge** - The problem you solved
  - **Solution** - How you approached it
  - **Key Highlights** - Bullet points of achievements
  - **Results & Impact** - Measurable outcomes
  - **Sidebar** with role, duration, tech stack, and links
  
  ### Project cards now:
  - Show "View Details" link for featured projects
  - Are fully clickable to go to detail page
  - Still show live site / code links
  
  ---
  
  ## ?? To Add Your Screenshots
  
  Place your images in `public/projects/` folder:
  
  ```
  public/
  ??? projects/
      ??? veggo-dashboard.png
      ??? veggo-builder.png
      ??? veggo-components.png
      ??? veggo-preview.png
      ??? pijiz-home.png
      ??? pijiz-product.png
      ??? banking-dashboard.png
      ??? ...
  ```
  
  ---
  
  **Now, about those visual issues you mentioned earlier** - go ahead and share screenshots or tell me which component/section has the problems, and we'll fix them! ??

  ### 📝 File Changes

  #### ✏️ `project-gallery.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\project-gallery.tsx`

  **🟢 New:**

  ```
  'use client';
  
  import { useState } from 'react';
  import { motion, AnimatePresence } from 'framer-motion';
  import { ChevronLeft, ChevronRight, X, ZoomIn } from 'lucide-react';
  
  interface ProjectGalleryProps {
    images: {
      src: string;
      alt: string;
      caption?: string;
    }[];
  }
  
  export function ProjectGallery({ images }: ProjectGalleryProps) {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  
    const goToPrevious = () => {
      setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
    };
  
    const goToNext = () => {
      setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
    };
  
    const openLightbox = (index: number) => {
      setCurrentIndex(index);
      setIsLightboxOpen(true);
    };
  
    return (
      <>
        {/* Main Gallery */}
        <div className="space-y-4">
          {/* Main Image */}
          <motion.div
            className="relative aspect-video rounded-2xl overflow-hidden bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight group cursor-pointer"
            onClick={() => openLightbox(currentIndex)}
            whileHover={{ scale: 1.01 }}
          >
            {/* Placeholder for main image */}
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-day-accent/5 to-day-accent-alt/5 dark:from-night-cyan/5 dark:to-night-accent/5">
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-day-bg-highlight dark:bg-night-bg-highlight flex items-center justify-center">
                  <ZoomIn className="w-8 h-8 text-day-accent/50 dark:text-night-cyan/50" />
                </div>
                <p className="text-sm text-day-comment dark:text-night-comment font-mono">
                  {images[currentIndex]?.src || 'screenshot-1.png'}
                </p>
                {images[currentIndex]?.caption && (
                  <p className="text-xs text-day-text/60 dark:text-night-text/60 mt-2">
                    {images[currentIndex].caption}
                  </p>
                )}
              </div>
            </div>
  
            {/* Zoom indicator */}
            <div className="absolute top-4 right-4 p-2 rounded-lg bg-day-bg/80 dark:bg-night-bg/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
              <ZoomIn className="w-5 h-5 text-day-accent dark:text-night-cyan" />
            </div>
  
            {/* Navigation Arrows */}
            {images.length > 1 && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    goToPrevious();
                  }}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-day-bg/80 dark:bg-night-bg/80 backdrop-blur-sm text-day-text dark:text-night-text hover:bg-day-accent hover:text-white dark:hover:bg-night-cyan dark:hover:text-night-bg transition-colors"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    goToNext();
                  }}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-day-bg/80 dark:bg-night-bg/80 backdrop-blur-sm text-day-text dark:text-night-text hover:bg-day-accent hover:text-white dark:hover:bg-night-cyan dark:hover:text-night-bg transition-colors"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}
          </motion.div>
  
          {/* Thumbnails */}
          {images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {images.map((image, index) => (
                <motion.button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`relative flex-shrink-0 w-24 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                    index === currentIndex
                      ? 'border-day-accent dark:border-night-cyan'
                      : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* Thumbnail placeholder */}
                  <div className="absolute inset-0 bg-day-bg-alt dark:bg-night-bg-alt flex items-center justify-center">
                    <span className="text-xs font-mono text-day-comment dark:text-night-comment">
                      {index + 1}
                    </span>
                  </div>
                </motion.button>
              ))}
            </div>
          )}
        </div>
  
        {/* Lightbox */}
        <AnimatePresence>
          {isLightboxOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
              onClick={() => setIsLightboxOpen(false)}
            >
              {/* Close button */}
              <button
                onClick={() => setIsLightboxOpen(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
                aria-label="Close lightbox"
              >
                <X className="w-6 h-6" />
              </button>
  
              {/* Image counter */}
              <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-white/10 text-white text-sm font-mono">
                {currentIndex + 1} / {images.length}
              </div>
  
              {/* Main lightbox image */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative max-w-5xl max-h-[80vh] w-full"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Lightbox image placeholder */}
                <div className="aspect-video rounded-xl bg-day-bg-alt dark:bg-night-bg-alt flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-lg font-mono text-day-comment dark:text-night-comment">
                      {images[currentIndex]?.src || `screenshot-${currentIndex + 1}.png`}
                    </p>
                    {images[currentIndex]?.caption && (
                      <p className="text-sm text-day-text/60 dark:text-night-text/60 mt-2">
                        {images[currentIndex].caption}
                      </p>
                    )}
                  </div>
                </div>
              </motion.div>
  
              {/* Navigation arrows */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      goToPrevious();
                    }}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
                    aria-label="Previous image"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      goToNext();
                    }}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
                    aria-label="Next image"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }
  
  ```

  #### ✏️ `project-detail.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\project-detail.tsx`

  **🟢 New:**

  ```
  'use client';
  
  import { motion } from 'framer-motion';
  import { ArrowLeft, ExternalLink, Github, Calendar, Briefcase } from 'lucide-react';
  import Link from 'next/link';
  import { useTranslations } from 'next-intl';
  import { ProjectGallery } from './project-gallery';
  
  export interface ProjectDetailProps {
    projectKey: string;
    images: { src: string; alt: string; caption?: string }[];
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    role: string;
    duration: string;
    highlights: string[];
  }
  
  export function ProjectDetail({
    projectKey,
    images,
    technologies,
    liveUrl,
    githubUrl,
    role,
    duration,
    highlights,
  }: ProjectDetailProps) {
    const t = useTranslations('projectDetails');
    const tProjects = useTranslations('projects.items');
  
    return (
      <article className="min-h-screen pt-24 pb-16">
        <div className="section-container">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-8"
          >
            <Link
              href="/#projects"
              className="inline-flex items-center gap-2 text-day-accent dark:text-night-cyan hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              {t('backToProjects')}
            </Link>
          </motion.div>
  
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Main Content - 3 columns */}
            <div className="lg:col-span-3 space-y-8">
              {/* Header */}
              <motion.header
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-day-text dark:text-night-text mb-4">
                  {tProjects(`${projectKey}.title`)}
                </h1>
                <p className="text-lg text-day-text/70 dark:text-night-text/70 leading-relaxed">
                  {tProjects(`${projectKey}.description`)}
                </p>
              </motion.header>
  
              {/* Image Gallery */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <ProjectGallery images={images} />
              </motion.div>
  
              {/* Challenge Section */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="space-y-4"
              >
                <h2 className="text-2xl font-bold text-day-text dark:text-night-text flex items-center gap-3">
                  <span className="w-8 h-1 bg-day-accent dark:bg-night-cyan rounded-full" />
                  {t('challenge')}
                </h2>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  {t(`${projectKey}.challenge`)}
                </p>
              </motion.section>
  
              {/* Solution Section */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="space-y-4"
              >
                <h2 className="text-2xl font-bold text-day-text dark:text-night-text flex items-center gap-3">
                  <span className="w-8 h-1 bg-day-accent dark:bg-night-cyan rounded-full" />
                  {t('solution')}
                </h2>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  {t(`${projectKey}.solution`)}
                </p>
              </motion.section>
  
              {/* Key Highlights */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="space-y-4"
              >
                <h2 className="text-2xl font-bold text-day-text dark:text-night-text flex items-center gap-3">
                  <span className="w-8 h-1 bg-day-accent dark:bg-night-cyan rounded-full" />
                  {t('highlights')}
                </h2>
                <ul className="space-y-3">
                  {highlights.map((highlight, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="flex items-start gap-3 text-day-text/80 dark:text-night-text/80"
                    >
                      <span className="text-day-accent dark:text-night-cyan mt-1.5">?</span>
                      {highlight}
                    </motion.li>
                  ))}
                </ul>
              </motion.section>
  
              {/* Results Section */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="space-y-4"
              >
                <h2 className="text-2xl font-bold text-day-text dark:text-night-text flex items-center gap-3">
                  <span className="w-8 h-1 bg-day-accent dark:bg-night-cyan rounded-full" />
                  {t('results')}
                </h2>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  {t(`${projectKey}.results`)}
                </p>
              </motion.section>
            </div>
  
            {/* Sidebar - 2 columns */}
            <motion.aside
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="lg:col-span-2 space-y-6"
            >
              {/* Project Info Card */}
              <div className="bento-card sticky top-24 space-y-6">
                {/* Quick Info */}
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-day-accent/10 dark:bg-night-cyan/10 flex items-center justify-center">
                      <Briefcase className="w-5 h-5 text-day-accent dark:text-night-cyan" />
                    </div>
                    <div>
                      <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                        {t('role')}
                      </p>
                      <p className="font-medium text-day-text dark:text-night-text">{role}</p>
                    </div>
                  </div>
  
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-day-accent/10 dark:bg-night-cyan/10 flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-day-accent dark:text-night-cyan" />
                    </div>
                    <div>
                      <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                        {t('duration')}
                      </p>
                      <p className="font-medium text-day-text dark:text-night-text">{duration}</p>
                    </div>
                  </div>
                </div>
  
                {/* Divider */}
                <div className="h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
  
                {/* Tech Stack */}
                <div>
                  <h3 className="text-sm font-mono text-day-comment dark:text-night-comment mb-3">
                    {t('techStack')}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 text-sm font-mono bg-day-bg dark:bg-night-bg rounded-full text-day-accent dark:text-night-cyan"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
  
                {/* Divider */}
                <div className="h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
  
                {/* Links */}
                <div className="space-y-3">
                  {liveUrl && (
                    <motion.a
                      href={liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium hover:shadow-lg hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25 transition-all"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <ExternalLink className="w-4 h-4" />
                      {t('viewLive')}
                    </motion.a>
                  )}
                  {githubUrl && (
                    <motion.a
                      href={githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border border-day-accent dark:border-night-cyan text-day-accent dark:text-night-cyan font-medium hover:bg-day-accent/10 dark:hover:bg-night-cyan/10 transition-all"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Github className="w-4 h-4" />
                      {t('viewCode')}
                    </motion.a>
                  )}
                </div>
              </div>
            </motion.aside>
          </div>
        </div>
      </article>
    );
  }
  
  ```

  #### ✏️ `en.json`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\en.json`

  **🔴 Old:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Frontend Engineer",
      "description": "Frontend engineer with 5+ years of experience building scalable, modern web applications using Angular, React, and TypeScript."
    },
    "nav": {
      "about": "About",
      "experience": "Experience",
      "projects": "Projects",
      "skills": "Skills",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Available for opportunities",
      "greeting": "Hi, I'm",
      "title": "Frontend Engineer",
      "titleSeparator": "|",
      "subtitle": "Angular Expert",
      "location": "Tunis, Tunisia ? Open to relocation",
      "description": "Building scalable, modern web applications with {years} of experience. Passionate about UI performance, developer experience, and clean architecture.",
      "yearsExperience": "5+ years",
      "cta": {
        "contact": "Get in Touch",
        "projects": "View Projects"
      },
      "scroll": "scroll"
    },
    "about": {
      "sectionNumber": "01",
      "title": "About Me",
      "paragraph1": "I'm a frontend engineer passionate about building <accent>scalable, modern web applications</accent> that deliver exceptional user experiences. With expertise in Angular and a strong foundation in React and TypeScript, I bring ideas to life with clean, maintainable code.",
      "paragraph2": "Currently at <company>VERMEG</company>, I lead frontend development for a low-code platform, where I've designed a <accent>reusable component library of 75+ widgets</accent> and mentored junior developers. I'm always exploring new technologies and best practices to level up my craft.",
      "paragraph3": "When I'm not coding, you'll find me contributing to open-source, exploring AI/ML certifications, or planning my next adventure. I'm open to international relocation and excited about new challenges in dynamic, product-driven teams.",
      "techTitle": "Technologies I work with daily:",
      "stats": {
        "years": "Years Experience",
        "components": "Components Built",
        "bugs": "Bugs Squashed",
        "languages": "Languages Spoken"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Experience",
      "jobs": {
        "vermeg_lead": {
          "title": "Software Engineer ? Frontend (Low-Code Platform)",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Jan 2024 ? Present",
          "description": [
            "Led code reviews and mentored 2 junior developers, improving code quality and onboarding efficiency.",
            "Designed and developed a reusable Angular component library (75+ widgets), reducing duplication by 35%.",
            "Migrated GitLab CI/CD pipelines to cloud, achieving 65% faster build times and 30% fewer failures.",
            "Contributed to functional design and actively participated in Agile ceremonies."
          ]
        },
        "vermeg_dev": {
          "title": "Frontend Developer ? Financial Products",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Fixed 160+ bugs and delivered high-impact features across multiple Angular-based financial apps.",
            "Refactored legacy modules and contributed to Angular version upgrades (v11 to v16).",
            "Achieved 95% test coverage with unit and E2E testing (Jest, Cypress).",
            "Collaborated with UI/UX teams to convert Figma prototypes into scalable, responsive interfaces."
          ]
        },
        "transcom": {
          "title": "Customer Service Representative ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisia",
          "period": "Oct 2017 ? Apr 2020",
          "description": [
            "Handled customer calls and support inquiries in English and French.",
            "Managed PayPal claims, disputes, and technical issues related to e-commerce integrations.",
            "Assisted in onboarding new hires through peer mentoring and training.",
            "Achieved 90%+ in KPIs related to resolution time, empathy, and customer satisfaction."
          ]
        },
        "stellar": {
          "title": "Software Developer Intern ? Game Development",
          "company": "Stellar VFX",
          "location": "Tunisia",
          "period": "Feb 2017 ? Jul 2017",
          "description": [
            "Built interactive game mechanics and UI with performance optimizations.",
            "Integrated assets and performed functional testing based on gameplay feedback."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projects",
      "featured": "Featured",
      "viewLive": "Live",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Low-Code Platform",
          "description": "Enterprise low-code platform for building financial applications. Led frontend development, designed 75+ reusable Angular widgets, and established component architecture patterns.",
          "period": "2024 - Present"
        },
        "pijiz": {
          "title": "E-commerce Store ? Pijiz",
          "description": "Shopify-based e-commerce platform with custom theme development, multi-language support, payment integration, and SEO optimization.",
          "period": "May 2024"
        },
        "dubai": {
          "title": "Visit Dubai UI Redesign",
          "description": "Freelance project to improve the UI/UX of Visit Dubai website. Enhanced page structure, navigation, and implemented responsive design fixes.",
          "period": "Jan 2024 - Feb 2024"
        },
        "banking": {
          "title": "Banking App Migration",
          "description": "Led the full framework upgrade from Angular v11 to v16 for a banking application. Refactored UI components and migrated custom themes.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Corporate Website",
          "description": "Built and deployed a corporate WordPress website with business email setup, SEO optimization, and GoDaddy hosting configuration.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Skills",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Testing",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "Security"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["Problem-solving", "Adaptability", "Team collaboration", "Communication", "Creativity", "Decision-making", "Mentoring"]
      },
      "languages": {
        "title": "Languages",
        "arabic": "Arabic",
        "arabicLevel": "Native",
        "english": "English",
        "englishLevel": "Fluent (B2)",
        "french": "French",
        "frenchLevel": "Fluent (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Education",
      "certificationsTitle": "Certifications",
      "educationTitle": "Education",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "July 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Engineering Degree ? Software Engineering",
          "institution": "ESPRIT University",
          "location": "Tunisia",
          "year": "2024"
        },
        "isamm": {
          "degree": "Bachelor's Degree in Computer Science",
          "institution": "Higher Institute of Multimedia Arts",
          "location": "Tunisia",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Get in Touch",
      "subtitle": "Let's Work Together",
      "description": "I'm currently open to new opportunities and exciting projects. Whether you have a question, want to discuss a potential collaboration, or just want to say hi, my inbox is always open!",
      "email": "Email",
      "phone": "Phone",
      "location": "Location",
      "findOnline": "Find me online:",
      "readyTitle": "Ready to Chat?",
      "readyDescription": "I typically respond within 24 hours. Looking forward to hearing from you!",
      "sendEmail": "Send Email",
      "orReachOut": "Or reach out on"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. All rights reserved.",
      "builtWith": "Built with",
      "using": "using"
    },
    "theme": {
      "switchToLight": "Switch to light mode",
      "switchToDark": "Switch to dark mode"
    },
    "language": {
      "switchTo": "Fran?ais",
      "current": "EN"
    }
  }
  
  ```

  **🟢 New:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Frontend Engineer",
      "description": "Frontend engineer with 5+ years of experience building scalable, modern web applications using Angular, React, and TypeScript."
    },
    "nav": {
      "about": "About",
      "experience": "Experience",
      "projects": "Projects",
      "skills": "Skills",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Available for opportunities",
      "greeting": "Hi, I'm",
      "title": "Frontend Engineer",
      "titleSeparator": "|",
      "subtitle": "Angular Expert",
      "location": "Tunis, Tunisia ? Open to relocation",
      "description": "Building scalable, modern web applications with {years} of experience. Passionate about UI performance, developer experience, and clean architecture.",
      "yearsExperience": "5+ years",
      "cta": {
        "contact": "Get in Touch",
        "projects": "View Projects"
      },
      "scroll": "scroll"
    },
    "about": {
      "sectionNumber": "01",
      "title": "About Me",
      "paragraph1": "I'm a frontend engineer passionate about building <accent>scalable, modern web applications</accent> that deliver exceptional user experiences. With expertise in Angular and a strong foundation in React and TypeScript, I bring ideas to life with clean, maintainable code.",
      "paragraph2": "Currently at <company>VERMEG</company>, I lead frontend development for a low-code platform, where I've designed a <accent>reusable component library of 75+ widgets</accent> and mentored junior developers. I'm always exploring new technologies and best practices to level up my craft.",
      "paragraph3": "When I'm not coding, you'll find me contributing to open-source, exploring AI/ML certifications, or planning my next adventure. I'm open to international relocation and excited about new challenges in dynamic, product-driven teams.",
      "techTitle": "Technologies I work with daily:",
      "stats": {
        "years": "Years Experience",
        "components": "Components Built",
        "bugs": "Bugs Squashed",
        "languages": "Languages Spoken"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Experience",
      "jobs": {
        "vermeg_lead": {
          "title": "Software Engineer ? Frontend (Low-Code Platform)",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Jan 2024 ? Present",
          "description": [
            "Led code reviews and mentored 2 junior developers, improving code quality and onboarding efficiency.",
            "Designed and developed a reusable Angular component library (75+ widgets), reducing duplication by 35%.",
            "Migrated GitLab CI/CD pipelines to cloud, achieving 65% faster build times and 30% fewer failures.",
            "Contributed to functional design and actively participated in Agile ceremonies."
          ]
        },
        "vermeg_dev": {
          "title": "Frontend Developer ? Financial Products",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Fixed 160+ bugs and delivered high-impact features across multiple Angular-based financial apps.",
            "Refactored legacy modules and contributed to Angular version upgrades (v11 to v16).",
            "Achieved 95% test coverage with unit and E2E testing (Jest, Cypress).",
            "Collaborated with UI/UX teams to convert Figma prototypes into scalable, responsive interfaces."
          ]
        },
        "transcom": {
          "title": "Customer Service Representative ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisia",
          "period": "Oct 2017 ? Apr 2020",
          "description": [
            "Handled customer calls and support inquiries in English and French.",
            "Managed PayPal claims, disputes, and technical issues related to e-commerce integrations.",
            "Assisted in onboarding new hires through peer mentoring and training.",
            "Achieved 90%+ in KPIs related to resolution time, empathy, and customer satisfaction."
          ]
        },
        "stellar": {
          "title": "Software Developer Intern ? Game Development",
          "company": "Stellar VFX",
          "location": "Tunisia",
          "period": "Feb 2017 ? Jul 2017",
          "description": [
            "Built interactive game mechanics and UI with performance optimizations.",
            "Integrated assets and performed functional testing based on gameplay feedback."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projects",
      "featured": "Featured",
      "viewLive": "Live",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Low-Code Platform",
          "description": "Enterprise low-code platform for building financial applications. Led frontend development, designed 75+ reusable Angular widgets, and established component architecture patterns.",
          "period": "2024 - Present"
        },
        "pijiz": {
          "title": "E-commerce Store ? Pijiz",
          "description": "Shopify-based e-commerce platform with custom theme development, multi-language support, payment integration, and SEO optimization.",
          "period": "May 2024"
        },
        "dubai": {
          "title": "Visit Dubai UI Redesign",
          "description": "Freelance project to improve the UI/UX of Visit Dubai website. Enhanced page structure, navigation, and implemented responsive design fixes.",
          "period": "Jan 2024 - Feb 2024"
        },
        "banking": {
          "title": "Banking App Migration",
          "description": "Led the full framework upgrade from Angular v11 to v16 for a banking application. Refactored UI components and migrated custom themes.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Corporate Website",
          "description": "Built and deployed a corporate WordPress website with business email setup, SEO optimization, and GoDaddy hosting configuration.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Skills",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Testing",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "Security"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["Problem-solving", "Adaptability", "Team collaboration", "Communication", "Creativity", "Decision-making", "Mentoring"]
      },
      "languages": {
        "title": "Languages",
        "arabic": "Arabic",
        "arabicLevel": "Native",
        "english": "English",
        "englishLevel": "Fluent (B2)",
        "french": "French",
        "frenchLevel": "Fluent (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Education",
      "certificationsTitle": "Certifications",
      "educationTitle": "Education",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "July 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Engineering Degree ? Software Engineering",
          "institution": "ESPRIT University",
          "location": "Tunisia",
          "year": "2024"
        },
        "isamm": {
          "degree": "Bachelor's Degree in Computer Science",
          "institution": "Higher Institute of Multimedia Arts",
          "location": "Tunisia",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Get in Touch",
      "subtitle": "Let's Work Together",
      "description": "I'm currently open to new opportunities and exciting projects. Whether you have a question, want to discuss a potential collaboration, or just want to say hi, my inbox is always open!",
      "email": "Email",
      "phone": "Phone",
      "location": "Location",
      "findOnline": "Find me online:",
      "readyTitle": "Ready to Chat?",
      "readyDescription": "I typically respond within 24 hours. Looking forward to hearing from you!",
      "sendEmail": "Send Email",
      "orReachOut": "Or reach out on"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. All rights reserved.",
      "builtWith": "Built with",
      "using": "using"
    },
    "theme": {
      "switchToLight": "Switch to light mode",
      "switchToDark": "Switch to dark mode"
    },
    "language": {
      "switchTo": "Fran?ais",
      "current": "EN"
    },
    "projectDetails": {
      "backToProjects": "Back to Projects",
      "challenge": "The Challenge",
      "solution": "The Solution",
      "highlights": "Key Highlights",
      "results": "Results & Impact",
      "role": "My Role",
      "duration": "Duration",
      "techStack": "Tech Stack",
      "viewLive": "View Live Site",
      "viewCode": "View Source Code",
      "veggo": {
        "challenge": "VERMEG needed a modern low-code platform that would allow business users to build financial applications without deep technical knowledge. The existing tools were outdated, hard to maintain, and lacked the flexibility required for complex financial workflows.",
        "solution": "I led the frontend development of VEGGO, designing and implementing a comprehensive component library from scratch. The architecture focused on reusability, accessibility, and performance, allowing users to drag-and-drop pre-built widgets to create sophisticated applications.",
        "results": "The platform now powers multiple enterprise clients, reducing application development time by 60%. The component library has grown to 75+ widgets with 95% test coverage, and the team has expanded while maintaining code quality through the patterns and documentation I established."
      },
      "pijiz": {
        "challenge": "The client needed a professional e-commerce store that could handle multiple languages, integrate various payment methods, and rank well on search engines. The store had to be easy to manage and reflect the brand's modern aesthetic.",
        "solution": "Built a custom Shopify store with a tailored theme that matched the brand identity. Implemented multi-language support for international customers, integrated local and international payment gateways, and optimized every page for SEO including meta tags, structured data, and page speed.",
        "results": "The store launched successfully with a 40% improvement in page load times compared to the original template. The SEO optimizations led to first-page Google rankings for key product terms within 3 months of launch."
      },
      "banking": {
        "challenge": "A major banking application was running on Angular v11, which was approaching end-of-life. The codebase had accumulated technical debt, custom themes that weren't compatible with newer Angular versions, and the team needed to modernize without disrupting ongoing development.",
        "solution": "Led a phased migration strategy that allowed the team to continue feature development while upgrading. Refactored legacy modules to use modern Angular patterns, migrated the custom theme system to CSS variables for better maintainability, and updated all dependencies systematically.",
        "results": "Successfully upgraded to Angular v16 with zero production incidents. Build times improved by 45%, and the modernized codebase enabled the team to implement new features 30% faster. The migration also resolved 50+ long-standing bugs related to the outdated framework."
      }
    }
  }
  
  ```

  #### ✏️ `fr.json`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\fr.json`

  **🔴 Old:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Ing?nieur Frontend",
      "description": "Ing?nieur frontend avec plus de 5 ans d'exp?rience dans la cr?ation d'applications web modernes et ?volutives avec Angular, React et TypeScript."
    },
    "nav": {
      "about": "? propos",
      "experience": "Exp?rience",
      "projects": "Projets",
      "skills": "Comp?tences",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Disponible pour de nouvelles opportunit?s",
      "greeting": "Bonjour, je suis",
      "title": "Ing?nieur Frontend",
      "titleSeparator": "|",
      "subtitle": "Expert Angular",
      "location": "Tunis, Tunisie ? Ouvert ? la relocalisation",
      "description": "Cr?ation d'applications web modernes et ?volutives avec {years} d'exp?rience. Passionn? par la performance UI, l'exp?rience d?veloppeur et l'architecture propre.",
      "yearsExperience": "5+ ans",
      "cta": {
        "contact": "Me Contacter",
        "projects": "Voir les Projets"
      },
      "scroll": "d?filer"
    },
    "about": {
      "sectionNumber": "01",
      "title": "? Propos de Moi",
      "paragraph1": "Je suis un ing?nieur frontend passionn? par la cr?ation d'<accent>applications web modernes et ?volutives</accent> qui offrent des exp?riences utilisateur exceptionnelles. Avec une expertise en Angular et une solide base en React et TypeScript, je donne vie aux id?es avec un code propre et maintenable.",
      "paragraph2": "Actuellement chez <company>VERMEG</company>, je dirige le d?veloppement frontend d'une plateforme low-code, o? j'ai con?u une <accent>biblioth?que de composants r?utilisables de 75+ widgets</accent> et mentor? des d?veloppeurs juniors. J'explore constamment de nouvelles technologies et bonnes pratiques pour am?liorer mes comp?tences.",
      "paragraph3": "Quand je ne code pas, vous me trouverez en train de contribuer ? l'open-source, d'explorer des certifications AI/ML, ou de planifier ma prochaine aventure. Je suis ouvert ? la relocalisation internationale et enthousiaste face aux nouveaux d?fis dans des ?quipes dynamiques orient?es produit.",
      "techTitle": "Technologies que j'utilise quotidiennement :",
      "stats": {
        "years": "Ans d'Exp?rience",
        "components": "Composants Cr??s",
        "bugs": "Bugs R?solus",
        "languages": "Langues Parl?es"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Exp?rience",
      "jobs": {
        "vermeg_lead": {
          "title": "Ing?nieur Logiciel ? Frontend (Plateforme Low-Code)",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Jan 2024 ? Pr?sent",
          "description": [
            "Direction des revues de code et mentorat de 2 d?veloppeurs juniors, am?liorant la qualit? du code et l'efficacit? de l'int?gration.",
            "Conception et d?veloppement d'une biblioth?que de composants Angular r?utilisables (75+ widgets), r?duisant la duplication de 35%.",
            "Migration des pipelines GitLab CI/CD vers le cloud, atteignant 65% de temps de build plus rapides et 30% moins d'?checs.",
            "Contribution ? la conception fonctionnelle et participation active aux c?r?monies Agile."
          ]
        },
        "vermeg_dev": {
          "title": "D?veloppeur Frontend ? Produits Financiers",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Correction de 160+ bugs et livraison de fonctionnalit?s ? fort impact sur plusieurs applications financi?res Angular.",
            "Refactorisation de modules legacy et contribution aux mises ? niveau Angular (v11 ? v16).",
            "Atteinte de 95% de couverture de tests avec tests unitaires et E2E (Jest, Cypress).",
            "Collaboration avec les ?quipes UI/UX pour convertir les prototypes Figma en interfaces r?actives et ?volutives."
          ]
        },
        "transcom": {
          "title": "Repr?sentant Service Client ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisie",
          "period": "Oct 2017 ? Avr 2020",
          "description": [
            "Gestion des appels clients et demandes de support en anglais et fran?ais.",
            "Gestion des r?clamations PayPal, litiges et probl?mes techniques li?s aux int?grations e-commerce.",
            "Assistance ? l'int?gration des nouvelles recrues par le mentorat et la formation.",
            "Atteinte de 90%+ dans les KPIs li?s au temps de r?solution, l'empathie et la satisfaction client."
          ]
        },
        "stellar": {
          "title": "D?veloppeur Logiciel Stagiaire ? D?veloppement de Jeux",
          "company": "Stellar VFX",
          "location": "Tunisie",
          "period": "F?v 2017 ? Juil 2017",
          "description": [
            "Cr?ation de m?caniques de jeu interactives et d'UI avec optimisations de performance.",
            "Int?gration d'assets et tests fonctionnels bas?s sur les retours de gameplay."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projets",
      "featured": "En vedette",
      "viewLive": "Voir",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Plateforme Low-Code",
          "description": "Plateforme low-code d'entreprise pour cr?er des applications financi?res. Direction du d?veloppement frontend, conception de 75+ widgets Angular r?utilisables et ?tablissement de patterns d'architecture de composants.",
          "period": "2024 - Pr?sent"
        },
        "pijiz": {
          "title": "Boutique E-commerce ? Pijiz",
          "description": "Plateforme e-commerce bas?e sur Shopify avec d?veloppement de th?me personnalis?, support multilingue, int?gration de paiement et optimisation SEO.",
          "period": "Mai 2024"
        },
        "dubai": {
          "title": "Refonte UI Visit Dubai",
          "description": "Projet freelance pour am?liorer l'UI/UX du site Visit Dubai. Am?lioration de la structure des pages, navigation et impl?mentation de corrections de design responsive.",
          "period": "Jan 2024 - F?v 2024"
        },
        "banking": {
          "title": "Migration App Bancaire",
          "description": "Direction de la mise ? niveau compl?te du framework d'Angular v11 ? v16 pour une application bancaire. Refactorisation des composants UI et migration des th?mes personnalis?s.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Site Corporate",
          "description": "Cr?ation et d?ploiement d'un site WordPress corporate avec configuration d'email professionnel, optimisation SEO et configuration d'h?bergement GoDaddy.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Comp?tences",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Tests",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "S?curit?"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["R?solution de probl?mes", "Adaptabilit?", "Travail d'?quipe", "Communication", "Cr?ativit?", "Prise de d?cision", "Mentorat"]
      },
      "languages": {
        "title": "Langues",
        "arabic": "Arabe",
        "arabicLevel": "Natif",
        "english": "Anglais",
        "englishLevel": "Courant (B2)",
        "french": "Fran?ais",
        "frenchLevel": "Courant (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Formation",
      "certificationsTitle": "Certifications",
      "educationTitle": "Formation",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "Juillet 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Dipl?me d'Ing?nieur ? G?nie Logiciel",
          "institution": "ESPRIT University",
          "location": "Tunisie",
          "year": "2024"
        },
        "isamm": {
          "degree": "Licence en Informatique",
          "institution": "Institut Sup?rieur des Arts Multim?dia",
          "location": "Tunisie",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Me Contacter",
      "subtitle": "Travaillons Ensemble",
      "description": "Je suis actuellement ouvert aux nouvelles opportunit?s et projets passionnants. Que vous ayez une question, souhaitiez discuter d'une collaboration potentielle, ou simplement dire bonjour, ma bo?te de r?ception est toujours ouverte !",
      "email": "Email",
      "phone": "T?l?phone",
      "location": "Localisation",
      "findOnline": "Retrouvez-moi en ligne :",
      "readyTitle": "Pr?t ? Discuter ?",
      "readyDescription": "Je r?ponds g?n?ralement sous 24 heures. Au plaisir de vous lire !",
      "sendEmail": "Envoyer un Email",
      "orReachOut": "Ou contactez-moi sur"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. Tous droits r?serv?s.",
      "builtWith": "Construit avec",
      "using": "avec"
    },
    "theme": {
      "switchToLight": "Passer en mode clair",
      "switchToDark": "Passer en mode sombre"
    },
    "language": {
      "switchTo": "English",
      "current": "FR"
    }
  }
  
  ```

  **🟢 New:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Ing?nieur Frontend",
      "description": "Ing?nieur frontend avec plus de 5 ans d'exp?rience dans la cr?ation d'applications web modernes et ?volutives avec Angular, React et TypeScript."
    },
    "nav": {
      "about": "? propos",
      "experience": "Exp?rience",
      "projects": "Projets",
      "skills": "Comp?tences",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Disponible pour de nouvelles opportunit?s",
      "greeting": "Bonjour, je suis",
      "title": "Ing?nieur Frontend",
      "titleSeparator": "|",
      "subtitle": "Expert Angular",
      "location": "Tunis, Tunisie ? Ouvert ? la relocalisation",
      "description": "Cr?ation d'applications web modernes et ?volutives avec {years} d'exp?rience. Passionn? par la performance UI, l'exp?rience d?veloppeur et l'architecture propre.",
      "yearsExperience": "5+ ans",
      "cta": {
        "contact": "Me Contacter",
        "projects": "Voir les Projets"
      },
      "scroll": "d?filer"
    },
    "about": {
      "sectionNumber": "01",
      "title": "? Propos de Moi",
      "paragraph1": "Je suis un ing?nieur frontend passionn? par la cr?ation d'<accent>applications web modernes et ?volutives</accent> qui offrent des exp?riences utilisateur exceptionnelles. Avec une expertise en Angular et une solide base en React et TypeScript, je donne vie aux id?es avec un code propre et maintenable.",
      "paragraph2": "Actuellement chez <company>VERMEG</company>, je dirige le d?veloppement frontend d'une plateforme low-code, o? j'ai con?u une <accent>biblioth?que de composants r?utilisables de 75+ widgets</accent> et mentor? des d?veloppeurs juniors. J'explore constamment de nouvelles technologies et bonnes pratiques pour am?liorer mes comp?tences.",
      "paragraph3": "Quand je ne code pas, vous me trouverez en train de contribuer ? l'open-source, d'explorer des certifications AI/ML, ou de planifier ma prochaine aventure. Je suis ouvert ? la relocalisation internationale et enthousiaste face aux nouveaux d?fis dans des ?quipes dynamiques orient?es produit.",
      "techTitle": "Technologies que j'utilise quotidiennement :",
      "stats": {
        "years": "Ans d'Exp?rience",
        "components": "Composants Cr??s",
        "bugs": "Bugs R?solus",
        "languages": "Langues Parl?es"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Exp?rience",
      "jobs": {
        "vermeg_lead": {
          "title": "Ing?nieur Logiciel ? Frontend (Plateforme Low-Code)",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Jan 2024 ? Pr?sent",
          "description": [
            "Direction des revues de code et mentorat de 2 d?veloppeurs juniors, am?liorant la qualit? du code et l'efficacit? de l'int?gration.",
            "Conception et d?veloppement d'une biblioth?que de composants Angular r?utilisables (75+ widgets), r?duisant la duplication de 35%.",
            "Migration des pipelines GitLab CI/CD vers le cloud, atteignant 65% de temps de build plus rapides et 30% moins d'?checs.",
            "Contribution ? la conception fonctionnelle et participation active aux c?r?monies Agile."
          ]
        },
        "vermeg_dev": {
          "title": "D?veloppeur Frontend ? Produits Financiers",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Correction de 160+ bugs et livraison de fonctionnalit?s ? fort impact sur plusieurs applications financi?res Angular.",
            "Refactorisation de modules legacy et contribution aux mises ? niveau Angular (v11 ? v16).",
            "Atteinte de 95% de couverture de tests avec tests unitaires et E2E (Jest, Cypress).",
            "Collaboration avec les ?quipes UI/UX pour convertir les prototypes Figma en interfaces r?actives et ?volutives."
          ]
        },
        "transcom": {
          "title": "Repr?sentant Service Client ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisie",
          "period": "Oct 2017 ? Avr 2020",
          "description": [
            "Gestion des appels clients et demandes de support en anglais et fran?ais.",
            "Gestion des r?clamations PayPal, litiges et probl?mes techniques li?s aux int?grations e-commerce.",
            "Assistance ? l'int?gration des nouvelles recrues par le mentorat et la formation.",
            "Atteinte de 90%+ dans les KPIs li?s au temps de r?solution, l'empathie et la satisfaction client."
          ]
        },
        "stellar": {
          "title": "D?veloppeur Logiciel Stagiaire ? D?veloppement de Jeux",
          "company": "Stellar VFX",
          "location": "Tunisie",
          "period": "F?v 2017 ? Juil 2017",
          "description": [
            "Cr?ation de m?caniques de jeu interactives et d'UI avec optimisations de performance.",
            "Int?gration d'assets et tests fonctionnels bas?s sur les retours de gameplay."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projets",
      "featured": "En vedette",
      "viewLive": "Voir",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Plateforme Low-Code",
          "description": "Plateforme low-code d'entreprise pour cr?er des applications financi?res. Direction du d?veloppement frontend, conception de 75+ widgets Angular r?utilisables et ?tablissement de patterns d'architecture de composants.",
          "period": "2024 - Pr?sent"
        },
        "pijiz": {
          "title": "Boutique E-commerce ? Pijiz",
          "description": "Plateforme e-commerce bas?e sur Shopify avec d?veloppement de th?me personnalis?, support multilingue, int?gration de paiement et optimisation SEO.",
          "period": "Mai 2024"
        },
        "dubai": {
          "title": "Refonte UI Visit Dubai",
          "description": "Projet freelance pour am?liorer l'UI/UX du site Visit Dubai. Am?lioration de la structure des pages, navigation et impl?mentation de corrections de design responsive.",
          "period": "Jan 2024 - F?v 2024"
        },
        "banking": {
          "title": "Migration App Bancaire",
          "description": "Direction de la mise ? niveau compl?te du framework d'Angular v11 ? v16 pour une application bancaire. Refactorisation des composants UI et migration des th?mes personnalis?s.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Site Corporate",
          "description": "Cr?ation et d?ploiement d'un site WordPress corporate avec configuration d'email professionnel, optimisation SEO et configuration d'h?bergement GoDaddy.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Comp?tences",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Tests",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "S?curit?"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["R?solution de probl?mes", "Adaptabilit?", "Travail d'?quipe", "Communication", "Cr?ativit?", "Prise de d?cision", "Mentorat"]
      },
      "languages": {
        "title": "Langues",
        "arabic": "Arabe",
        "arabicLevel": "Natif",
        "english": "Anglais",
        "englishLevel": "Courant (B2)",
        "french": "Fran?ais",
        "frenchLevel": "Courant (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Formation",
      "certificationsTitle": "Certifications",
      "educationTitle": "Formation",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "Juillet 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Dipl?me d'Ing?nieur ? G?nie Logiciel",
          "institution": "ESPRIT University",
          "location": "Tunisie",
          "year": "2024"
        },
        "isamm": {
          "degree": "Licence en Informatique",
          "institution": "Institut Sup?rieur des Arts Multim?dia",
          "location": "Tunisie",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Me Contacter",
      "subtitle": "Travaillons Ensemble",
      "description": "Je suis actuellement ouvert aux nouvelles opportunit?s et projets passionnants. Que vous ayez une question, souhaitiez discuter d'une collaboration potentielle, ou simplement dire bonjour, ma bo?te de r?ception est toujours ouverte !",
      "email": "Email",
      "phone": "T?l?phone",
      "location": "Localisation",
      "findOnline": "Retrouvez-moi en ligne :",
      "readyTitle": "Pr?t ? Discuter ?",
      "readyDescription": "Je r?ponds g?n?ralement sous 24 heures. Au plaisir de vous lire !",
      "sendEmail": "Envoyer un Email",
      "orReachOut": "Ou contactez-moi sur"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. Tous droits r?serv?s.",
      "builtWith": "Construit avec",
      "using": "avec"
    },
    "theme": {
      "switchToLight": "Passer en mode clair",
      "switchToDark": "Passer en mode sombre"
    },
    "language": {
      "switchTo": "English",
      "current": "FR"
    },
    "projectDetails": {
      "backToProjects": "Retour aux Projets",
      "challenge": "Le D?fi",
      "solution": "La Solution",
      "highlights": "Points Cl?s",
      "results": "R?sultats & Impact",
      "role": "Mon R?le",
      "duration": "Dur?e",
      "techStack": "Technologies",
      "viewLive": "Voir le Site",
      "viewCode": "Voir le Code",
      "veggo": {
        "challenge": "VERMEG avait besoin d'une plateforme low-code moderne permettant aux utilisateurs m?tier de cr?er des applications financi?res sans connaissances techniques approfondies. Les outils existants ?taient obsol?tes, difficiles ? maintenir et manquaient de flexibilit? pour les workflows financiers complexes.",
        "solution": "J'ai dirig? le d?veloppement frontend de VEGGO, concevant et impl?mentant une biblioth?que de composants compl?te. L'architecture s'est concentr?e sur la r?utilisabilit?, l'accessibilit? et la performance, permettant aux utilisateurs de glisser-d?poser des widgets pr?-construits pour cr?er des applications sophistiqu?es.",
        "results": "La plateforme alimente maintenant plusieurs clients entreprise, r?duisant le temps de d?veloppement d'applications de 60%. La biblioth?que de composants compte plus de 75 widgets avec 95% de couverture de tests, et l'?quipe s'est agrandie tout en maintenant la qualit? du code gr?ce aux patterns et ? la documentation que j'ai ?tablis."
      },
      "pijiz": {
        "challenge": "Le client avait besoin d'une boutique e-commerce professionnelle capable de g?rer plusieurs langues, d'int?grer diff?rents modes de paiement et de bien se positionner sur les moteurs de recherche. La boutique devait ?tre facile ? g?rer et refl?ter l'esth?tique moderne de la marque.",
        "solution": "Construction d'une boutique Shopify personnalis?e avec un th?me adapt? ? l'identit? de la marque. Impl?mentation du support multilingue pour les clients internationaux, int?gration de passerelles de paiement locales et internationales, et optimisation de chaque page pour le SEO incluant les balises meta, les donn?es structur?es et la vitesse de chargement.",
        "results": "La boutique a ?t? lanc?e avec succ?s avec une am?lioration de 40% des temps de chargement par rapport au template original. Les optimisations SEO ont conduit ? des classements en premi?re page Google pour les termes produits cl?s dans les 3 mois suivant le lancement."
      },
      "banking": {
        "challenge": "Une application bancaire majeure fonctionnait sur Angular v11, qui approchait de sa fin de vie. La base de code avait accumul? de la dette technique, des th?mes personnalis?s incompatibles avec les nouvelles versions d'Angular, et l'?quipe devait moderniser sans perturber le d?veloppement en cours.",
        "solution": "Direction d'une strat?gie de migration par phases permettant ? l'?quipe de continuer le d?veloppement de fonctionnalit?s tout en effectuant la mise ? niveau. Refactorisation des modules legacy pour utiliser les patterns Angular modernes, migration du syst?me de th?mes personnalis?s vers des variables CSS pour une meilleure maintenabilit?, et mise ? jour syst?matique de toutes les d?pendances.",
        "results": "Mise ? niveau r?ussie vers Angular v16 avec z?ro incident en production. Les temps de build ont ?t? am?lior?s de 45%, et la base de code modernis?e a permis ? l'?quipe d'impl?menter de nouvelles fonctionnalit?s 30% plus rapidement. La migration a ?galement r?solu plus de 50 bugs de longue date li?s au framework obsol?te."
      }
    }
  }
  
  ```

  #### ✏️ `page.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\projects\veggo\page.tsx`

  **🟢 New:**

  ```
  import { ProjectDetail } from '@/components/project-detail';
  import { getTranslations } from 'next-intl/server';
  
  export async function generateMetadata({
    params: { locale },
  }: {
    params: { locale: string };
  }) {
    const t = await getTranslations({ locale, namespace: 'projects.items.veggo' });
    
    return {
      title: `${t('title')} | Khalil Khaled`,
      description: t('description'),
    };
  }
  
  export default function VeggoProjectPage() {
    const images = [
      { src: 'veggo-dashboard.png', alt: 'VEGGO Dashboard', caption: 'Main dashboard with widget library' },
      { src: 'veggo-builder.png', alt: 'VEGGO Builder', caption: 'Drag-and-drop application builder' },
      { src: 'veggo-components.png', alt: 'VEGGO Components', caption: 'Component library showcase' },
      { src: 'veggo-preview.png', alt: 'VEGGO Preview', caption: 'Live application preview' },
    ];
  
    const technologies = [
      'Angular',
      'TypeScript',
      'RxJS',
      'NgRx',
      'SASS',
      'Storybook',
      'Jest',
      'Cypress',
      'GitLab CI/CD',
      'Docker',
    ];
  
    const highlights = [
      'Designed and developed 75+ reusable Angular widgets from scratch',
      'Established component architecture patterns adopted across the organization',
      'Mentored 2 junior developers, improving team velocity by 25%',
      'Achieved 95% test coverage with comprehensive unit and E2E tests',
      'Migrated CI/CD pipelines to cloud, reducing build times by 65%',
      'Created extensive documentation and Storybook stories for all components',
    ];
  
    return (
      <ProjectDetail
        projectKey="veggo"
        images={images}
        technologies={technologies}
        role="Lead Frontend Developer"
        duration="Jan 2024 - Present"
        highlights={highlights}
      />
    );
  }
  
  ```

  #### ✏️ `page.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\projects\pijiz\page.tsx`

  **🟢 New:**

  ```
  import { ProjectDetail } from '@/components/project-detail';
  import { getTranslations } from 'next-intl/server';
  
  export async function generateMetadata({
    params: { locale },
  }: {
    params: { locale: string };
  }) {
    const t = await getTranslations({ locale, namespace: 'projects.items.pijiz' });
    
    return {
      title: `${t('title')} | Khalil Khaled`,
      description: t('description'),
    };
  }
  
  export default function PijizProjectPage() {
    const images = [
      { src: 'pijiz-home.png', alt: 'Pijiz Homepage', caption: 'Homepage with featured products' },
      { src: 'pijiz-product.png', alt: 'Pijiz Product Page', caption: 'Product detail page' },
      { src: 'pijiz-cart.png', alt: 'Pijiz Cart', caption: 'Shopping cart experience' },
      { src: 'pijiz-checkout.png', alt: 'Pijiz Checkout', caption: 'Streamlined checkout flow' },
    ];
  
    const technologies = [
      'Shopify',
      'Liquid',
      'JavaScript',
      'CSS3',
      'SEO',
      'Google Analytics',
    ];
  
    const highlights = [
      'Built custom Shopify theme matching brand identity',
      'Implemented multi-language support (Arabic, English, French)',
      'Integrated multiple payment gateways including local options',
      'Optimized page speed scoring 90+ on Google PageSpeed',
      'Set up Google Analytics and conversion tracking',
      'Configured custom domain and professional email',
    ];
  
    return (
      <ProjectDetail
        projectKey="pijiz"
        images={images}
        technologies={technologies}
        liveUrl="https://pijiz.com"
        role="Full Stack Developer"
        duration="May 2024"
        highlights={highlights}
      />
    );
  }
  
  ```

  #### ✏️ `page.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\projects\banking\page.tsx`

  **🟢 New:**

  ```
  import { ProjectDetail } from '@/components/project-detail';
  import { getTranslations } from 'next-intl/server';
  
  export async function generateMetadata({
    params: { locale },
  }: {
    params: { locale: string };
  }) {
    const t = await getTranslations({ locale, namespace: 'projects.items.banking' });
    
    return {
      title: `${t('title')} | Khalil Khaled`,
      description: t('description'),
    };
  }
  
  export default function BankingProjectPage() {
    const images = [
      { src: 'banking-dashboard.png', alt: 'Banking Dashboard', caption: 'Main account dashboard' },
      { src: 'banking-transactions.png', alt: 'Banking Transactions', caption: 'Transaction history view' },
      { src: 'banking-transfers.png', alt: 'Banking Transfers', caption: 'Money transfer interface' },
      { src: 'banking-mobile.png', alt: 'Banking Mobile', caption: 'Responsive mobile view' },
    ];
  
    const technologies = [
      'Angular 16',
      'TypeScript',
      'RxJS',
      'NgRx',
      'Jest',
      'Cypress',
      'SASS',
      'CSS Variables',
    ];
  
    const highlights = [
      'Led full framework migration from Angular v11 to v16',
      'Refactored legacy modules to modern Angular patterns',
      'Migrated custom theme system to CSS variables',
      'Achieved zero production incidents during migration',
      'Improved build times by 45%',
      'Resolved 50+ long-standing framework-related bugs',
    ];
  
    return (
      <ProjectDetail
        projectKey="banking"
        images={images}
        technologies={technologies}
        role="Lead Frontend Developer"
        duration="Nov 2023 - Jan 2024"
        highlights={highlights}
      />
    );
  }
  
  ```

  #### ✏️ `projects.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\projects.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { ExternalLink, Github, Star, Folder } from 'lucide-react';
  
  interface ProjectData {
    key: string;
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    featured?: boolean;
  }
  
  const projectsData: ProjectData[] = [
    {
      key: 'veggo',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'SASS', 'Storybook'],
      featured: true,
    },
    {
      key: 'pijiz',
      technologies: ['Shopify', 'Liquid', 'JavaScript', 'CSS'],
      liveUrl: 'https://pijiz.com',
    },
    {
      key: 'dubai',
      technologies: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS'],
    },
    {
      key: 'banking',
      technologies: ['Angular', 'TypeScript', 'Jest', 'Cypress'],
    },
    {
      key: 'nrg',
      technologies: ['WordPress', 'PHP', 'CSS', 'SEO'],
      liveUrl: 'https://nrgglobalpower.us',
    },
  ];
  
  function ProjectCard({ project, index }: { project: ProjectData; index: number }) {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
    const [isHovered, setIsHovered] = useState(false);
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className={`group ${project.featured ? 'md:col-span-2' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <motion.div
          className="bento-card h-full relative overflow-hidden"
          whileHover={{ y: -5 }}
          style={{
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Featured Badge */}
          {project.featured && (
            <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-day-accent/10 dark:bg-night-cyan/10 rounded-full text-day-accent dark:text-night-cyan text-xs font-mono">
              <Star className="w-3 h-3" />
              {t('featured')}
            </div>
          )}
  
          {/* Image Placeholder */}
          <div className="relative mb-4 rounded-lg overflow-hidden bg-day-bg-highlight dark:bg-night-bg-highlight aspect-video">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Folder className="w-12 h-12 mx-auto mb-2 text-day-accent/40 dark:text-night-cyan/40" />
                <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                  {t('screenshotPlaceholder')}
                </p>
              </div>
            </div>
            
            {/* Hover Overlay */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-t from-day-accent/80 dark:from-night-cyan/80 to-transparent flex items-end justify-center p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex gap-3">
                {project.liveUrl && (
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View live site"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </a>
                )}
                {project.githubUrl && (
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View source code"
                  >
                    <Github className="w-5 h-5" />
                  </a>
                )}
              </div>
            </motion.div>
          </div>
  
          {/* Content */}
          <div>
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors">
                {t(`items.${project.key}.title`)}
              </h3>
              <span className="text-xs font-mono text-day-comment dark:text-night-comment whitespace-nowrap">
                {t(`items.${project.key}.period`)}
              </span>
            </div>
            
            <p className="text-sm text-day-text/70 dark:text-night-text/70 mb-4 leading-relaxed">
              {t(`items.${project.key}.description`)}
            </p>
  
            {/* Technologies */}
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
  
          {/* Links for non-hovered state */}
          <div className="mt-4 flex gap-4">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <ExternalLink className="w-4 h-4" />
                {t('viewLive')}
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <Github className="w-4 h-4" />
                {t('viewCode')}
              </a>
            )}
          </div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Projects() {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="projects" className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {projectsData.map((project, index) => (
                <ProjectCard key={project.key} project={project} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import Link from 'next/link';
  import { ExternalLink, Github, Star, Folder, ArrowRight } from 'lucide-react';
  
  interface ProjectData {
    key: string;
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    featured?: boolean;
    detailPage?: string; // Path to detail page
  }
  
  const projectsData: ProjectData[] = [
    {
      key: 'veggo',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'SASS', 'Storybook'],
      featured: true,
      detailPage: '/projects/veggo',
    },
    {
      key: 'pijiz',
      technologies: ['Shopify', 'Liquid', 'JavaScript', 'CSS'],
      liveUrl: 'https://pijiz.com',
      detailPage: '/projects/pijiz',
    },
    {
      key: 'dubai',
      technologies: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS'],
    },
    {
      key: 'banking',
      technologies: ['Angular', 'TypeScript', 'Jest', 'Cypress'],
      detailPage: '/projects/banking',
    },
    {
      key: 'nrg',
      technologies: ['WordPress', 'PHP', 'CSS', 'SEO'],
      liveUrl: 'https://nrgglobalpower.us',
    },
  ];
  
  function ProjectCard({ project, index }: { project: ProjectData; index: number }) {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
    const [isHovered, setIsHovered] = useState(false);
  
    const CardWrapper = project.detailPage ? Link : 'div';
    const cardProps = project.detailPage
      ? { href: project.detailPage }
      : {};
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className={`group ${project.featured ? 'md:col-span-2' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardWrapper
          {...cardProps}
          className={`block ${project.detailPage ? 'cursor-pointer' : ''}`}
        >
          <motion.div
            className="bento-card h-full relative overflow-hidden"
            whileHover={{ y: -5 }}
            style={{
              transformStyle: 'preserve-3d',
            }}
          >
            {/* Featured Badge */}
            {project.featured && (
              <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-day-accent/10 dark:bg-night-cyan/10 rounded-full text-day-accent dark:text-night-cyan text-xs font-mono z-10">
                <Star className="w-3 h-3" />
                {t('featured')}
              </div>
            )}
  
            {/* Image Placeholder */}
            <div className="relative mb-4 rounded-lg overflow-hidden bg-day-bg-highlight dark:bg-night-bg-highlight aspect-video">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Folder className="w-12 h-12 mx-auto mb-2 text-day-accent/40 dark:text-night-cyan/40" />
                  <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                    {t('screenshotPlaceholder')}
                  </p>
                </div>
              </div>
              
              {/* Hover Overlay */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-day-accent/80 dark:from-night-cyan/80 to-transparent flex items-end justify-center p-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: isHovered ? 1 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex gap-3">
                  {project.detailPage && (
                    <span className="px-4 py-2 rounded-full bg-white/90 text-day-accent font-medium text-sm flex items-center gap-2">
                      {t('viewDetails')}
                      <ArrowRight className="w-4 h-4" />
                    </span>
                  )}
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                      aria-label="View live site"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  )}
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                      aria-label="View source code"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Github className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </motion.div>
            </div>
  
            {/* Content */}
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="text-lg font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors">
                  {t(`items.${project.key}.title`)}
                </h3>
                <span className="text-xs font-mono text-day-comment dark:text-night-comment whitespace-nowrap">
                  {t(`items.${project.key}.period`)}
                </span>
              </div>
              
              <p className="text-sm text-day-text/70 dark:text-night-text/70 mb-4 leading-relaxed">
                {t(`items.${project.key}.description`)}
              </p>
  
              {/* Technologies */}
              <div className="flex flex-wrap gap-2">
                {project.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
  
            {/* Links for non-hovered state */}
            <div className="mt-4 flex gap-4">
              {project.detailPage && (
                <span className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan font-medium">
                  {t('viewDetails')}
                  <ArrowRight className="w-4 h-4" />
                </span>
              )}
              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
                  onClick={(e) => e.stopPropagation()}
                >
                  <ExternalLink className="w-4 h-4" />
                  {t('viewLive')}
                </a>
              )}
              {project.githubUrl && (
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
                  onClick={(e) => e.stopPropagation()}
                >
                  <Github className="w-4 h-4" />
                  {t('viewCode')}
                </a>
              )}
            </div>
          </motion.div>
        </CardWrapper>
      </motion.div>
    );
  }
  
  export function Projects() {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="projects" className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {projectsData.map((project, index) => (
                <ProjectCard key={project.key} project={project} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `en.json`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\en.json`

  **🔴 Old:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Frontend Engineer",
      "description": "Frontend engineer with 5+ years of experience building scalable, modern web applications using Angular, React, and TypeScript."
    },
    "nav": {
      "about": "About",
      "experience": "Experience",
      "projects": "Projects",
      "skills": "Skills",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Available for opportunities",
      "greeting": "Hi, I'm",
      "title": "Frontend Engineer",
      "titleSeparator": "|",
      "subtitle": "Angular Expert",
      "location": "Tunis, Tunisia ? Open to relocation",
      "description": "Building scalable, modern web applications with {years} of experience. Passionate about UI performance, developer experience, and clean architecture.",
      "yearsExperience": "5+ years",
      "cta": {
        "contact": "Get in Touch",
        "projects": "View Projects"
      },
      "scroll": "scroll"
    },
    "about": {
      "sectionNumber": "01",
      "title": "About Me",
      "paragraph1": "I'm a frontend engineer passionate about building <accent>scalable, modern web applications</accent> that deliver exceptional user experiences. With expertise in Angular and a strong foundation in React and TypeScript, I bring ideas to life with clean, maintainable code.",
      "paragraph2": "Currently at <company>VERMEG</company>, I lead frontend development for a low-code platform, where I've designed a <accent>reusable component library of 75+ widgets</accent> and mentored junior developers. I'm always exploring new technologies and best practices to level up my craft.",
      "paragraph3": "When I'm not coding, you'll find me contributing to open-source, exploring AI/ML certifications, or planning my next adventure. I'm open to international relocation and excited about new challenges in dynamic, product-driven teams.",
      "techTitle": "Technologies I work with daily:",
      "stats": {
        "years": "Years Experience",
        "components": "Components Built",
        "bugs": "Bugs Squashed",
        "languages": "Languages Spoken"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Experience",
      "jobs": {
        "vermeg_lead": {
          "title": "Software Engineer ? Frontend (Low-Code Platform)",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Jan 2024 ? Present",
          "description": [
            "Led code reviews and mentored 2 junior developers, improving code quality and onboarding efficiency.",
            "Designed and developed a reusable Angular component library (75+ widgets), reducing duplication by 35%.",
            "Migrated GitLab CI/CD pipelines to cloud, achieving 65% faster build times and 30% fewer failures.",
            "Contributed to functional design and actively participated in Agile ceremonies."
          ]
        },
        "vermeg_dev": {
          "title": "Frontend Developer ? Financial Products",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Fixed 160+ bugs and delivered high-impact features across multiple Angular-based financial apps.",
            "Refactored legacy modules and contributed to Angular version upgrades (v11 to v16).",
            "Achieved 95% test coverage with unit and E2E testing (Jest, Cypress).",
            "Collaborated with UI/UX teams to convert Figma prototypes into scalable, responsive interfaces."
          ]
        },
        "transcom": {
          "title": "Customer Service Representative ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisia",
          "period": "Oct 2017 ? Apr 2020",
          "description": [
            "Handled customer calls and support inquiries in English and French.",
            "Managed PayPal claims, disputes, and technical issues related to e-commerce integrations.",
            "Assisted in onboarding new hires through peer mentoring and training.",
            "Achieved 90%+ in KPIs related to resolution time, empathy, and customer satisfaction."
          ]
        },
        "stellar": {
          "title": "Software Developer Intern ? Game Development",
          "company": "Stellar VFX",
          "location": "Tunisia",
          "period": "Feb 2017 ? Jul 2017",
          "description": [
            "Built interactive game mechanics and UI with performance optimizations.",
            "Integrated assets and performed functional testing based on gameplay feedback."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projects",
      "featured": "Featured",
      "viewLive": "Live",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Low-Code Platform",
          "description": "Enterprise low-code platform for building financial applications. Led frontend development, designed 75+ reusable Angular widgets, and established component architecture patterns.",
          "period": "2024 - Present"
        },
        "pijiz": {
          "title": "E-commerce Store ? Pijiz",
          "description": "Shopify-based e-commerce platform with custom theme development, multi-language support, payment integration, and SEO optimization.",
          "period": "May 2024"
        },
        "dubai": {
          "title": "Visit Dubai UI Redesign",
          "description": "Freelance project to improve the UI/UX of Visit Dubai website. Enhanced page structure, navigation, and implemented responsive design fixes.",
          "period": "Jan 2024 - Feb 2024"
        },
        "banking": {
          "title": "Banking App Migration",
          "description": "Led the full framework upgrade from Angular v11 to v16 for a banking application. Refactored UI components and migrated custom themes.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Corporate Website",
          "description": "Built and deployed a corporate WordPress website with business email setup, SEO optimization, and GoDaddy hosting configuration.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Skills",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Testing",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "Security"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["Problem-solving", "Adaptability", "Team collaboration", "Communication", "Creativity", "Decision-making", "Mentoring"]
      },
      "languages": {
        "title": "Languages",
        "arabic": "Arabic",
        "arabicLevel": "Native",
        "english": "English",
        "englishLevel": "Fluent (B2)",
        "french": "French",
        "frenchLevel": "Fluent (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Education",
      "certificationsTitle": "Certifications",
      "educationTitle": "Education",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "July 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Engineering Degree ? Software Engineering",
          "institution": "ESPRIT University",
          "location": "Tunisia",
          "year": "2024"
        },
        "isamm": {
          "degree": "Bachelor's Degree in Computer Science",
          "institution": "Higher Institute of Multimedia Arts",
          "location": "Tunisia",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Get in Touch",
      "subtitle": "Let's Work Together",
      "description": "I'm currently open to new opportunities and exciting projects. Whether you have a question, want to discuss a potential collaboration, or just want to say hi, my inbox is always open!",
      "email": "Email",
      "phone": "Phone",
      "location": "Location",
      "findOnline": "Find me online:",
      "readyTitle": "Ready to Chat?",
      "readyDescription": "I typically respond within 24 hours. Looking forward to hearing from you!",
      "sendEmail": "Send Email",
      "orReachOut": "Or reach out on"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. All rights reserved.",
      "builtWith": "Built with",
      "using": "using"
    },
    "theme": {
      "switchToLight": "Switch to light mode",
      "switchToDark": "Switch to dark mode"
    },
    "language": {
      "switchTo": "Fran?ais",
      "current": "EN"
    },
    "projectDetails": {
      "backToProjects": "Back to Projects",
      "challenge": "The Challenge",
      "solution": "The Solution",
      "highlights": "Key Highlights",
      "results": "Results & Impact",
      "role": "My Role",
      "duration": "Duration",
      "techStack": "Tech Stack",
      "viewLive": "View Live Site",
      "viewCode": "View Source Code",
      "veggo": {
        "challenge": "VERMEG needed a modern low-code platform that would allow business users to build financial applications without deep technical knowledge. The existing tools were outdated, hard to maintain, and lacked the flexibility required for complex financial workflows.",
        "solution": "I led the frontend development of VEGGO, designing and implementing a comprehensive component library from scratch. The architecture focused on reusability, accessibility, and performance, allowing users to drag-and-drop pre-built widgets to create sophisticated applications.",
        "results": "The platform now powers multiple enterprise clients, reducing application development time by 60%. The component library has grown to 75+ widgets with 95% test coverage, and the team has expanded while maintaining code quality through the patterns and documentation I established."
      },
      "pijiz": {
        "challenge": "The client needed a professional e-commerce store that could handle multiple languages, integrate various payment methods, and rank well on search engines. The store had to be easy to manage and reflect the brand's modern aesthetic.",
        "solution": "Built a custom Shopify store with a tailored theme that matched the brand identity. Implemented multi-language support for international customers, integrated local and international payment gateways, and optimized every page for SEO including meta tags, structured data, and page speed.",
        "results": "The store launched successfully with a 40% improvement in page load times compared to the original template. The SEO optimizations led to first-page Google rankings for key product terms within 3 months of launch."
      },
      "banking": {
        "challenge": "A major banking application was running on Angular v11, which was approaching end-of-life. The codebase had accumulated technical debt, custom themes that weren't compatible with newer Angular versions, and the team needed to modernize without disrupting ongoing development.",
        "solution": "Led a phased migration strategy that allowed the team to continue feature development while upgrading. Refactored legacy modules to use modern Angular patterns, migrated the custom theme system to CSS variables for better maintainability, and updated all dependencies systematically.",
        "results": "Successfully upgraded to Angular v16 with zero production incidents. Build times improved by 45%, and the modernized codebase enabled the team to implement new features 30% faster. The migration also resolved 50+ long-standing bugs related to the outdated framework."
      }
    }
  }
  
  ```

  **🟢 New:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Frontend Engineer",
      "description": "Frontend engineer with 5+ years of experience building scalable, modern web applications using Angular, React, and TypeScript."
    },
    "nav": {
      "about": "About",
      "experience": "Experience",
      "projects": "Projects",
      "skills": "Skills",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Available for opportunities",
      "greeting": "Hi, I'm",
      "title": "Frontend Engineer",
      "titleSeparator": "|",
      "subtitle": "Angular Expert",
      "location": "Tunis, Tunisia ? Open to relocation",
      "description": "Building scalable, modern web applications with {years} of experience. Passionate about UI performance, developer experience, and clean architecture.",
      "yearsExperience": "5+ years",
      "cta": {
        "contact": "Get in Touch",
        "projects": "View Projects"
      },
      "scroll": "scroll"
    },
    "about": {
      "sectionNumber": "01",
      "title": "About Me",
      "paragraph1": "I'm a frontend engineer passionate about building <accent>scalable, modern web applications</accent> that deliver exceptional user experiences. With expertise in Angular and a strong foundation in React and TypeScript, I bring ideas to life with clean, maintainable code.",
      "paragraph2": "Currently at <company>VERMEG</company>, I lead frontend development for a low-code platform, where I've designed a <accent>reusable component library of 75+ widgets</accent> and mentored junior developers. I'm always exploring new technologies and best practices to level up my craft.",
      "paragraph3": "When I'm not coding, you'll find me contributing to open-source, exploring AI/ML certifications, or planning my next adventure. I'm open to international relocation and excited about new challenges in dynamic, product-driven teams.",
      "techTitle": "Technologies I work with daily:",
      "stats": {
        "years": "Years Experience",
        "components": "Components Built",
        "bugs": "Bugs Squashed",
        "languages": "Languages Spoken"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Experience",
      "jobs": {
        "vermeg_lead": {
          "title": "Software Engineer ? Frontend (Low-Code Platform)",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Jan 2024 ? Present",
          "description": [
            "Led code reviews and mentored 2 junior developers, improving code quality and onboarding efficiency.",
            "Designed and developed a reusable Angular component library (75+ widgets), reducing duplication by 35%.",
            "Migrated GitLab CI/CD pipelines to cloud, achieving 65% faster build times and 30% fewer failures.",
            "Contributed to functional design and actively participated in Agile ceremonies."
          ]
        },
        "vermeg_dev": {
          "title": "Frontend Developer ? Financial Products",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Fixed 160+ bugs and delivered high-impact features across multiple Angular-based financial apps.",
            "Refactored legacy modules and contributed to Angular version upgrades (v11 to v16).",
            "Achieved 95% test coverage with unit and E2E testing (Jest, Cypress).",
            "Collaborated with UI/UX teams to convert Figma prototypes into scalable, responsive interfaces."
          ]
        },
        "transcom": {
          "title": "Customer Service Representative ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisia",
          "period": "Oct 2017 ? Apr 2020",
          "description": [
            "Handled customer calls and support inquiries in English and French.",
            "Managed PayPal claims, disputes, and technical issues related to e-commerce integrations.",
            "Assisted in onboarding new hires through peer mentoring and training.",
            "Achieved 90%+ in KPIs related to resolution time, empathy, and customer satisfaction."
          ]
        },
        "stellar": {
          "title": "Software Developer Intern ? Game Development",
          "company": "Stellar VFX",
          "location": "Tunisia",
          "period": "Feb 2017 ? Jul 2017",
          "description": [
            "Built interactive game mechanics and UI with performance optimizations.",
            "Integrated assets and performed functional testing based on gameplay feedback."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projects",
      "featured": "Featured",
      "viewLive": "Live",
      "viewCode": "Code",
      "viewDetails": "View Details",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Low-Code Platform",
          "description": "Enterprise low-code platform for building financial applications. Led frontend development, designed 75+ reusable Angular widgets, and established component architecture patterns.",
          "period": "2024 - Present"
        },
        "pijiz": {
          "title": "E-commerce Store ? Pijiz",
          "description": "Shopify-based e-commerce platform with custom theme development, multi-language support, payment integration, and SEO optimization.",
          "period": "May 2024"
        },
        "dubai": {
          "title": "Visit Dubai UI Redesign",
          "description": "Freelance project to improve the UI/UX of Visit Dubai website. Enhanced page structure, navigation, and implemented responsive design fixes.",
          "period": "Jan 2024 - Feb 2024"
        },
        "banking": {
          "title": "Banking App Migration",
          "description": "Led the full framework upgrade from Angular v11 to v16 for a banking application. Refactored UI components and migrated custom themes.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Corporate Website",
          "description": "Built and deployed a corporate WordPress website with business email setup, SEO optimization, and GoDaddy hosting configuration.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Skills",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Testing",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "Security"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["Problem-solving", "Adaptability", "Team collaboration", "Communication", "Creativity", "Decision-making", "Mentoring"]
      },
      "languages": {
        "title": "Languages",
        "arabic": "Arabic",
        "arabicLevel": "Native",
        "english": "English",
        "englishLevel": "Fluent (B2)",
        "french": "French",
        "frenchLevel": "Fluent (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Education",
      "certificationsTitle": "Certifications",
      "educationTitle": "Education",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "July 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Engineering Degree ? Software Engineering",
          "institution": "ESPRIT University",
          "location": "Tunisia",
          "year": "2024"
        },
        "isamm": {
          "degree": "Bachelor's Degree in Computer Science",
          "institution": "Higher Institute of Multimedia Arts",
          "location": "Tunisia",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Get in Touch",
      "subtitle": "Let's Work Together",
      "description": "I'm currently open to new opportunities and exciting projects. Whether you have a question, want to discuss a potential collaboration, or just want to say hi, my inbox is always open!",
      "email": "Email",
      "phone": "Phone",
      "location": "Location",
      "findOnline": "Find me online:",
      "readyTitle": "Ready to Chat?",
      "readyDescription": "I typically respond within 24 hours. Looking forward to hearing from you!",
      "sendEmail": "Send Email",
      "orReachOut": "Or reach out on"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. All rights reserved.",
      "builtWith": "Built with",
      "using": "using"
    },
    "theme": {
      "switchToLight": "Switch to light mode",
      "switchToDark": "Switch to dark mode"
    },
    "language": {
      "switchTo": "Fran?ais",
      "current": "EN"
    },
    "projectDetails": {
      "backToProjects": "Back to Projects",
      "challenge": "The Challenge",
      "solution": "The Solution",
      "highlights": "Key Highlights",
      "results": "Results & Impact",
      "role": "My Role",
      "duration": "Duration",
      "techStack": "Tech Stack",
      "viewLive": "View Live Site",
      "viewCode": "View Source Code",
      "veggo": {
        "challenge": "VERMEG needed a modern low-code platform that would allow business users to build financial applications without deep technical knowledge. The existing tools were outdated, hard to maintain, and lacked the flexibility required for complex financial workflows.",
        "solution": "I led the frontend development of VEGGO, designing and implementing a comprehensive component library from scratch. The architecture focused on reusability, accessibility, and performance, allowing users to drag-and-drop pre-built widgets to create sophisticated applications.",
        "results": "The platform now powers multiple enterprise clients, reducing application development time by 60%. The component library has grown to 75+ widgets with 95% test coverage, and the team has expanded while maintaining code quality through the patterns and documentation I established."
      },
      "pijiz": {
        "challenge": "The client needed a professional e-commerce store that could handle multiple languages, integrate various payment methods, and rank well on search engines. The store had to be easy to manage and reflect the brand's modern aesthetic.",
        "solution": "Built a custom Shopify store with a tailored theme that matched the brand identity. Implemented multi-language support for international customers, integrated local and international payment gateways, and optimized every page for SEO including meta tags, structured data, and page speed.",
        "results": "The store launched successfully with a 40% improvement in page load times compared to the original template. The SEO optimizations led to first-page Google rankings for key product terms within 3 months of launch."
      },
      "banking": {
        "challenge": "A major banking application was running on Angular v11, which was approaching end-of-life. The codebase had accumulated technical debt, custom themes that weren't compatible with newer Angular versions, and the team needed to modernize without disrupting ongoing development.",
        "solution": "Led a phased migration strategy that allowed the team to continue feature development while upgrading. Refactored legacy modules to use modern Angular patterns, migrated the custom theme system to CSS variables for better maintainability, and updated all dependencies systematically.",
        "results": "Successfully upgraded to Angular v16 with zero production incidents. Build times improved by 45%, and the modernized codebase enabled the team to implement new features 30% faster. The migration also resolved 50+ long-standing bugs related to the outdated framework."
      }
    }
  }
  
  ```

  #### ✏️ `fr.json`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\fr.json`

  **🔴 Old:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Ing?nieur Frontend",
      "description": "Ing?nieur frontend avec plus de 5 ans d'exp?rience dans la cr?ation d'applications web modernes et ?volutives avec Angular, React et TypeScript."
    },
    "nav": {
      "about": "? propos",
      "experience": "Exp?rience",
      "projects": "Projets",
      "skills": "Comp?tences",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Disponible pour de nouvelles opportunit?s",
      "greeting": "Bonjour, je suis",
      "title": "Ing?nieur Frontend",
      "titleSeparator": "|",
      "subtitle": "Expert Angular",
      "location": "Tunis, Tunisie ? Ouvert ? la relocalisation",
      "description": "Cr?ation d'applications web modernes et ?volutives avec {years} d'exp?rience. Passionn? par la performance UI, l'exp?rience d?veloppeur et l'architecture propre.",
      "yearsExperience": "5+ ans",
      "cta": {
        "contact": "Me Contacter",
        "projects": "Voir les Projets"
      },
      "scroll": "d?filer"
    },
    "about": {
      "sectionNumber": "01",
      "title": "? Propos de Moi",
      "paragraph1": "Je suis un ing?nieur frontend passionn? par la cr?ation d'<accent>applications web modernes et ?volutives</accent> qui offrent des exp?riences utilisateur exceptionnelles. Avec une expertise en Angular et une solide base en React et TypeScript, je donne vie aux id?es avec un code propre et maintenable.",
      "paragraph2": "Actuellement chez <company>VERMEG</company>, je dirige le d?veloppement frontend d'une plateforme low-code, o? j'ai con?u une <accent>biblioth?que de composants r?utilisables de 75+ widgets</accent> et mentor? des d?veloppeurs juniors. J'explore constamment de nouvelles technologies et bonnes pratiques pour am?liorer mes comp?tences.",
      "paragraph3": "Quand je ne code pas, vous me trouverez en train de contribuer ? l'open-source, d'explorer des certifications AI/ML, ou de planifier ma prochaine aventure. Je suis ouvert ? la relocalisation internationale et enthousiaste face aux nouveaux d?fis dans des ?quipes dynamiques orient?es produit.",
      "techTitle": "Technologies que j'utilise quotidiennement :",
      "stats": {
        "years": "Ans d'Exp?rience",
        "components": "Composants Cr??s",
        "bugs": "Bugs R?solus",
        "languages": "Langues Parl?es"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Exp?rience",
      "jobs": {
        "vermeg_lead": {
          "title": "Ing?nieur Logiciel ? Frontend (Plateforme Low-Code)",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Jan 2024 ? Pr?sent",
          "description": [
            "Direction des revues de code et mentorat de 2 d?veloppeurs juniors, am?liorant la qualit? du code et l'efficacit? de l'int?gration.",
            "Conception et d?veloppement d'une biblioth?que de composants Angular r?utilisables (75+ widgets), r?duisant la duplication de 35%.",
            "Migration des pipelines GitLab CI/CD vers le cloud, atteignant 65% de temps de build plus rapides et 30% moins d'?checs.",
            "Contribution ? la conception fonctionnelle et participation active aux c?r?monies Agile."
          ]
        },
        "vermeg_dev": {
          "title": "D?veloppeur Frontend ? Produits Financiers",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Correction de 160+ bugs et livraison de fonctionnalit?s ? fort impact sur plusieurs applications financi?res Angular.",
            "Refactorisation de modules legacy et contribution aux mises ? niveau Angular (v11 ? v16).",
            "Atteinte de 95% de couverture de tests avec tests unitaires et E2E (Jest, Cypress).",
            "Collaboration avec les ?quipes UI/UX pour convertir les prototypes Figma en interfaces r?actives et ?volutives."
          ]
        },
        "transcom": {
          "title": "Repr?sentant Service Client ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisie",
          "period": "Oct 2017 ? Avr 2020",
          "description": [
            "Gestion des appels clients et demandes de support en anglais et fran?ais.",
            "Gestion des r?clamations PayPal, litiges et probl?mes techniques li?s aux int?grations e-commerce.",
            "Assistance ? l'int?gration des nouvelles recrues par le mentorat et la formation.",
            "Atteinte de 90%+ dans les KPIs li?s au temps de r?solution, l'empathie et la satisfaction client."
          ]
        },
        "stellar": {
          "title": "D?veloppeur Logiciel Stagiaire ? D?veloppement de Jeux",
          "company": "Stellar VFX",
          "location": "Tunisie",
          "period": "F?v 2017 ? Juil 2017",
          "description": [
            "Cr?ation de m?caniques de jeu interactives et d'UI avec optimisations de performance.",
            "Int?gration d'assets et tests fonctionnels bas?s sur les retours de gameplay."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projets",
      "featured": "En vedette",
      "viewLive": "Voir",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Plateforme Low-Code",
          "description": "Plateforme low-code d'entreprise pour cr?er des applications financi?res. Direction du d?veloppement frontend, conception de 75+ widgets Angular r?utilisables et ?tablissement de patterns d'architecture de composants.",
          "period": "2024 - Pr?sent"
        },
        "pijiz": {
          "title": "Boutique E-commerce ? Pijiz",
          "description": "Plateforme e-commerce bas?e sur Shopify avec d?veloppement de th?me personnalis?, support multilingue, int?gration de paiement et optimisation SEO.",
          "period": "Mai 2024"
        },
        "dubai": {
          "title": "Refonte UI Visit Dubai",
          "description": "Projet freelance pour am?liorer l'UI/UX du site Visit Dubai. Am?lioration de la structure des pages, navigation et impl?mentation de corrections de design responsive.",
          "period": "Jan 2024 - F?v 2024"
        },
        "banking": {
          "title": "Migration App Bancaire",
          "description": "Direction de la mise ? niveau compl?te du framework d'Angular v11 ? v16 pour une application bancaire. Refactorisation des composants UI et migration des th?mes personnalis?s.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Site Corporate",
          "description": "Cr?ation et d?ploiement d'un site WordPress corporate avec configuration d'email professionnel, optimisation SEO et configuration d'h?bergement GoDaddy.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Comp?tences",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Tests",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "S?curit?"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["R?solution de probl?mes", "Adaptabilit?", "Travail d'?quipe", "Communication", "Cr?ativit?", "Prise de d?cision", "Mentorat"]
      },
      "languages": {
        "title": "Langues",
        "arabic": "Arabe",
        "arabicLevel": "Natif",
        "english": "Anglais",
        "englishLevel": "Courant (B2)",
        "french": "Fran?ais",
        "frenchLevel": "Courant (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Formation",
      "certificationsTitle": "Certifications",
      "educationTitle": "Formation",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "Juillet 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Dipl?me d'Ing?nieur ? G?nie Logiciel",
          "institution": "ESPRIT University",
          "location": "Tunisie",
          "year": "2024"
        },
        "isamm": {
          "degree": "Licence en Informatique",
          "institution": "Institut Sup?rieur des Arts Multim?dia",
          "location": "Tunisie",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Me Contacter",
      "subtitle": "Travaillons Ensemble",
      "description": "Je suis actuellement ouvert aux nouvelles opportunit?s et projets passionnants. Que vous ayez une question, souhaitiez discuter d'une collaboration potentielle, ou simplement dire bonjour, ma bo?te de r?ception est toujours ouverte !",
      "email": "Email",
      "phone": "T?l?phone",
      "location": "Localisation",
      "findOnline": "Retrouvez-moi en ligne :",
      "readyTitle": "Pr?t ? Discuter ?",
      "readyDescription": "Je r?ponds g?n?ralement sous 24 heures. Au plaisir de vous lire !",
      "sendEmail": "Envoyer un Email",
      "orReachOut": "Ou contactez-moi sur"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. Tous droits r?serv?s.",
      "builtWith": "Construit avec",
      "using": "avec"
    },
    "theme": {
      "switchToLight": "Passer en mode clair",
      "switchToDark": "Passer en mode sombre"
    },
    "language": {
      "switchTo": "English",
      "current": "FR"
    },
    "projectDetails": {
      "backToProjects": "Retour aux Projets",
      "challenge": "Le D?fi",
      "solution": "La Solution",
      "highlights": "Points Cl?s",
      "results": "R?sultats & Impact",
      "role": "Mon R?le",
      "duration": "Dur?e",
      "techStack": "Technologies",
      "viewLive": "Voir le Site",
      "viewCode": "Voir le Code",
      "veggo": {
        "challenge": "VERMEG avait besoin d'une plateforme low-code moderne permettant aux utilisateurs m?tier de cr?er des applications financi?res sans connaissances techniques approfondies. Les outils existants ?taient obsol?tes, difficiles ? maintenir et manquaient de flexibilit? pour les workflows financiers complexes.",
        "solution": "J'ai dirig? le d?veloppement frontend de VEGGO, concevant et impl?mentant une biblioth?que de composants compl?te. L'architecture s'est concentr?e sur la r?utilisabilit?, l'accessibilit? et la performance, permettant aux utilisateurs de glisser-d?poser des widgets pr?-construits pour cr?er des applications sophistiqu?es.",
        "results": "La plateforme alimente maintenant plusieurs clients entreprise, r?duisant le temps de d?veloppement d'applications de 60%. La biblioth?que de composants compte plus de 75 widgets avec 95% de couverture de tests, et l'?quipe s'est agrandie tout en maintenant la qualit? du code gr?ce aux patterns et ? la documentation que j'ai ?tablis."
      },
      "pijiz": {
        "challenge": "Le client avait besoin d'une boutique e-commerce professionnelle capable de g?rer plusieurs langues, d'int?grer diff?rents modes de paiement et de bien se positionner sur les moteurs de recherche. La boutique devait ?tre facile ? g?rer et refl?ter l'esth?tique moderne de la marque.",
        "solution": "Construction d'une boutique Shopify personnalis?e avec un th?me adapt? ? l'identit? de la marque. Impl?mentation du support multilingue pour les clients internationaux, int?gration de passerelles de paiement locales et internationales, et optimisation de chaque page pour le SEO incluant les balises meta, les donn?es structur?es et la vitesse de chargement.",
        "results": "La boutique a ?t? lanc?e avec succ?s avec une am?lioration de 40% des temps de chargement par rapport au template original. Les optimisations SEO ont conduit ? des classements en premi?re page Google pour les termes produits cl?s dans les 3 mois suivant le lancement."
      },
      "banking": {
        "challenge": "Une application bancaire majeure fonctionnait sur Angular v11, qui approchait de sa fin de vie. La base de code avait accumul? de la dette technique, des th?mes personnalis?s incompatibles avec les nouvelles versions d'Angular, et l'?quipe devait moderniser sans perturber le d?veloppement en cours.",
        "solution": "Direction d'une strat?gie de migration par phases permettant ? l'?quipe de continuer le d?veloppement de fonctionnalit?s tout en effectuant la mise ? niveau. Refactorisation des modules legacy pour utiliser les patterns Angular modernes, migration du syst?me de th?mes personnalis?s vers des variables CSS pour une meilleure maintenabilit?, et mise ? jour syst?matique de toutes les d?pendances.",
        "results": "Mise ? niveau r?ussie vers Angular v16 avec z?ro incident en production. Les temps de build ont ?t? am?lior?s de 45%, et la base de code modernis?e a permis ? l'?quipe d'impl?menter de nouvelles fonctionnalit?s 30% plus rapidement. La migration a ?galement r?solu plus de 50 bugs de longue date li?s au framework obsol?te."
      }
    }
  }
  
  ```

  **🟢 New:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Ing?nieur Frontend",
      "description": "Ing?nieur frontend avec plus de 5 ans d'exp?rience dans la cr?ation d'applications web modernes et ?volutives avec Angular, React et TypeScript."
    },
    "nav": {
      "about": "? propos",
      "experience": "Exp?rience",
      "projects": "Projets",
      "skills": "Comp?tences",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Disponible pour de nouvelles opportunit?s",
      "greeting": "Bonjour, je suis",
      "title": "Ing?nieur Frontend",
      "titleSeparator": "|",
      "subtitle": "Expert Angular",
      "location": "Tunis, Tunisie ? Ouvert ? la relocalisation",
      "description": "Cr?ation d'applications web modernes et ?volutives avec {years} d'exp?rience. Passionn? par la performance UI, l'exp?rience d?veloppeur et l'architecture propre.",
      "yearsExperience": "5+ ans",
      "cta": {
        "contact": "Me Contacter",
        "projects": "Voir les Projets"
      },
      "scroll": "d?filer"
    },
    "about": {
      "sectionNumber": "01",
      "title": "? Propos de Moi",
      "paragraph1": "Je suis un ing?nieur frontend passionn? par la cr?ation d'<accent>applications web modernes et ?volutives</accent> qui offrent des exp?riences utilisateur exceptionnelles. Avec une expertise en Angular et une solide base en React et TypeScript, je donne vie aux id?es avec un code propre et maintenable.",
      "paragraph2": "Actuellement chez <company>VERMEG</company>, je dirige le d?veloppement frontend d'une plateforme low-code, o? j'ai con?u une <accent>biblioth?que de composants r?utilisables de 75+ widgets</accent> et mentor? des d?veloppeurs juniors. J'explore constamment de nouvelles technologies et bonnes pratiques pour am?liorer mes comp?tences.",
      "paragraph3": "Quand je ne code pas, vous me trouverez en train de contribuer ? l'open-source, d'explorer des certifications AI/ML, ou de planifier ma prochaine aventure. Je suis ouvert ? la relocalisation internationale et enthousiaste face aux nouveaux d?fis dans des ?quipes dynamiques orient?es produit.",
      "techTitle": "Technologies que j'utilise quotidiennement :",
      "stats": {
        "years": "Ans d'Exp?rience",
        "components": "Composants Cr??s",
        "bugs": "Bugs R?solus",
        "languages": "Langues Parl?es"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Exp?rience",
      "jobs": {
        "vermeg_lead": {
          "title": "Ing?nieur Logiciel ? Frontend (Plateforme Low-Code)",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Jan 2024 ? Pr?sent",
          "description": [
            "Direction des revues de code et mentorat de 2 d?veloppeurs juniors, am?liorant la qualit? du code et l'efficacit? de l'int?gration.",
            "Conception et d?veloppement d'une biblioth?que de composants Angular r?utilisables (75+ widgets), r?duisant la duplication de 35%.",
            "Migration des pipelines GitLab CI/CD vers le cloud, atteignant 65% de temps de build plus rapides et 30% moins d'?checs.",
            "Contribution ? la conception fonctionnelle et participation active aux c?r?monies Agile."
          ]
        },
        "vermeg_dev": {
          "title": "D?veloppeur Frontend ? Produits Financiers",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Correction de 160+ bugs et livraison de fonctionnalit?s ? fort impact sur plusieurs applications financi?res Angular.",
            "Refactorisation de modules legacy et contribution aux mises ? niveau Angular (v11 ? v16).",
            "Atteinte de 95% de couverture de tests avec tests unitaires et E2E (Jest, Cypress).",
            "Collaboration avec les ?quipes UI/UX pour convertir les prototypes Figma en interfaces r?actives et ?volutives."
          ]
        },
        "transcom": {
          "title": "Repr?sentant Service Client ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisie",
          "period": "Oct 2017 ? Avr 2020",
          "description": [
            "Gestion des appels clients et demandes de support en anglais et fran?ais.",
            "Gestion des r?clamations PayPal, litiges et probl?mes techniques li?s aux int?grations e-commerce.",
            "Assistance ? l'int?gration des nouvelles recrues par le mentorat et la formation.",
            "Atteinte de 90%+ dans les KPIs li?s au temps de r?solution, l'empathie et la satisfaction client."
          ]
        },
        "stellar": {
          "title": "D?veloppeur Logiciel Stagiaire ? D?veloppement de Jeux",
          "company": "Stellar VFX",
          "location": "Tunisie",
          "period": "F?v 2017 ? Juil 2017",
          "description": [
            "Cr?ation de m?caniques de jeu interactives et d'UI avec optimisations de performance.",
            "Int?gration d'assets et tests fonctionnels bas?s sur les retours de gameplay."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projets",
      "featured": "En vedette",
      "viewLive": "Voir",
      "viewCode": "Code",
      "viewDetails": "Voir D?tails",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Plateforme Low-Code",
          "description": "Plateforme low-code d'entreprise pour cr?er des applications financi?res. Direction du d?veloppement frontend, conception de 75+ widgets Angular r?utilisables et ?tablissement de patterns d'architecture de composants.",
          "period": "2024 - Pr?sent"
        },
        "pijiz": {
          "title": "Boutique E-commerce ? Pijiz",
          "description": "Plateforme e-commerce bas?e sur Shopify avec d?veloppement de th?me personnalis?, support multilingue, int?gration de paiement et optimisation SEO.",
          "period": "Mai 2024"
        },
        "dubai": {
          "title": "Refonte UI Visit Dubai",
          "description": "Projet freelance pour am?liorer l'UI/UX du site Visit Dubai. Am?lioration de la structure des pages, navigation et impl?mentation de corrections de design responsive.",
          "period": "Jan 2024 - F?v 2024"
        },
        "banking": {
          "title": "Migration App Bancaire",
          "description": "Direction de la mise ? niveau compl?te du framework d'Angular v11 ? v16 pour une application bancaire. Refactorisation des composants UI et migration des th?mes personnalis?s.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Site Corporate",
          "description": "Cr?ation et d?ploiement d'un site WordPress corporate avec configuration d'email professionnel, optimisation SEO et configuration d'h?bergement GoDaddy.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Comp?tences",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Tests",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "S?curit?"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["R?solution de probl?mes", "Adaptabilit?", "Travail d'?quipe", "Communication", "Cr?ativit?", "Prise de d?cision", "Mentorat"]
      },
      "languages": {
        "title": "Langues",
        "arabic": "Arabe",
        "arabicLevel": "Natif",
        "english": "Anglais",
        "englishLevel": "Courant (B2)",
        "french": "Fran?ais",
        "frenchLevel": "Courant (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Formation",
      "certificationsTitle": "Certifications",
      "educationTitle": "Formation",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "Juillet 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Dipl?me d'Ing?nieur ? G?nie Logiciel",
          "institution": "ESPRIT University",
          "location": "Tunisie",
          "year": "2024"
        },
        "isamm": {
          "degree": "Licence en Informatique",
          "institution": "Institut Sup?rieur des Arts Multim?dia",
          "location": "Tunisie",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Me Contacter",
      "subtitle": "Travaillons Ensemble",
      "description": "Je suis actuellement ouvert aux nouvelles opportunit?s et projets passionnants. Que vous ayez une question, souhaitiez discuter d'une collaboration potentielle, ou simplement dire bonjour, ma bo?te de r?ception est toujours ouverte !",
      "email": "Email",
      "phone": "T?l?phone",
      "location": "Localisation",
      "findOnline": "Retrouvez-moi en ligne :",
      "readyTitle": "Pr?t ? Discuter ?",
      "readyDescription": "Je r?ponds g?n?ralement sous 24 heures. Au plaisir de vous lire !",
      "sendEmail": "Envoyer un Email",
      "orReachOut": "Ou contactez-moi sur"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. Tous droits r?serv?s.",
      "builtWith": "Construit avec",
      "using": "avec"
    },
    "theme": {
      "switchToLight": "Passer en mode clair",
      "switchToDark": "Passer en mode sombre"
    },
    "language": {
      "switchTo": "English",
      "current": "FR"
    },
    "projectDetails": {
      "backToProjects": "Retour aux Projets",
      "challenge": "Le D?fi",
      "solution": "La Solution",
      "highlights": "Points Cl?s",
      "results": "R?sultats & Impact",
      "role": "Mon R?le",
      "duration": "Dur?e",
      "techStack": "Technologies",
      "viewLive": "Voir le Site",
      "viewCode": "Voir le Code",
      "veggo": {
        "challenge": "VERMEG avait besoin d'une plateforme low-code moderne permettant aux utilisateurs m?tier de cr?er des applications financi?res sans connaissances techniques approfondies. Les outils existants ?taient obsol?tes, difficiles ? maintenir et manquaient de flexibilit? pour les workflows financiers complexes.",
        "solution": "J'ai dirig? le d?veloppement frontend de VEGGO, concevant et impl?mentant une biblioth?que de composants compl?te. L'architecture s'est concentr?e sur la r?utilisabilit?, l'accessibilit? et la performance, permettant aux utilisateurs de glisser-d?poser des widgets pr?-construits pour cr?er des applications sophistiqu?es.",
        "results": "La plateforme alimente maintenant plusieurs clients entreprise, r?duisant le temps de d?veloppement d'applications de 60%. La biblioth?que de composants compte plus de 75 widgets avec 95% de couverture de tests, et l'?quipe s'est agrandie tout en maintenant la qualit? du code gr?ce aux patterns et ? la documentation que j'ai ?tablis."
      },
      "pijiz": {
        "challenge": "Le client avait besoin d'une boutique e-commerce professionnelle capable de g?rer plusieurs langues, d'int?grer diff?rents modes de paiement et de bien se positionner sur les moteurs de recherche. La boutique devait ?tre facile ? g?rer et refl?ter l'esth?tique moderne de la marque.",
        "solution": "Construction d'une boutique Shopify personnalis?e avec un th?me adapt? ? l'identit? de la marque. Impl?mentation du support multilingue pour les clients internationaux, int?gration de passerelles de paiement locales et internationales, et optimisation de chaque page pour le SEO incluant les balises meta, les donn?es structur?es et la vitesse de chargement.",
        "results": "La boutique a ?t? lanc?e avec succ?s avec une am?lioration de 40% des temps de chargement par rapport au template original. Les optimisations SEO ont conduit ? des classements en premi?re page Google pour les termes produits cl?s dans les 3 mois suivant le lancement."
      },
      "banking": {
        "challenge": "Une application bancaire majeure fonctionnait sur Angular v11, qui approchait de sa fin de vie. La base de code avait accumul? de la dette technique, des th?mes personnalis?s incompatibles avec les nouvelles versions d'Angular, et l'?quipe devait moderniser sans perturber le d?veloppement en cours.",
        "solution": "Direction d'une strat?gie de migration par phases permettant ? l'?quipe de continuer le d?veloppement de fonctionnalit?s tout en effectuant la mise ? niveau. Refactorisation des modules legacy pour utiliser les patterns Angular modernes, migration du syst?me de th?mes personnalis?s vers des variables CSS pour une meilleure maintenabilit?, et mise ? jour syst?matique de toutes les d?pendances.",
        "results": "Mise ? niveau r?ussie vers Angular v16 avec z?ro incident en production. Les temps de build ont ?t? am?lior?s de 45%, et la base de code modernis?e a permis ? l'?quipe d'impl?menter de nouvelles fonctionnalit?s 30% plus rapidement. La migration a ?galement r?solu plus de 50 bugs de longue date li?s au framework obsol?te."
      }
    }
  }
  
  ```


---

## 👤 User Prompt #2

  **🕐 Timestamp:** 2026-01-11T18:34:48.468Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 📝 Prompt

  there's console errors in home page. can you read them directly?

  ### 📎 Attachments

  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\project-gallery.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\project-detail.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\en.json`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\fr.json`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\projects\veggo\page.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\projects\pijiz\page.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\projects\banking\page.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\projects.tsx`
  - **[file]** `c:\Users\kkhaled\.cursor\projects\c-Users-kkhaled-Desktop-Personal-portfolio\terminals\3.txt`

  ### 📋 Team Rules

  <details>
  <summary>View Team Rules</summary>

  **Angular Standard Rules**

  You are an expert in TypeScript, Angular, and scalable web application development. You write functional, maintainable, performant, and accessible code following Angular and TypeScript best practices.
  ## TypeScript Best Practices
  - Use strict type checking
  - Prefer type inference when the type is obvious
  - Avoid the `any` type; use `unknown` when type is uncertain
  ## Angular Best Practices
  - Always use standalone components over NgModules
  - Must NOT set `standalone: true` inside Angular decorators. It's the default in Angular v20+.
  - Use signals for state management
  - Implement lazy loading for feature routes
  - Do NOT use the `@HostBinding` and `@HostListener` decorators. Put host bindings inside the `host` object of the `@Component` or `@Directive` decorator instead
  - Use `NgOptimizedImage` for all static images.
    - `NgOptimizedImage` does not work for inline base64 images.
  ## Accessibility Requirements
  - It MUST pass all AXE checks.
  - It MUST follow all WCAG AA minimums, including focus management, color contrast, and ARIA attributes.
  ### Components
  - Keep components small and focused on a single responsibility
  - Use `input()` and `output()` functions instead of decorators
  - Use `computed()` for derived state
  - Set `changeDetection: ChangeDetectionStrategy.OnPush` in `@Component` decorator
  - Prefer inline templates for small components
  - Prefer Reactive forms instead of Template-driven ones
  - Do NOT use `ngClass`, use `class` bindings instead
  - Do NOT use `ngStyle`, use `style` bindings instead
  - When using external templates/styles, use paths relative to the component TS file.
  ## State Management
  - Use signals for local component state
  - Use `computed()` for derived state
  - Keep state transformations pure and predictable
  - Do NOT use `mutate` on signals, use `update` or `set` instead
  ## Templates
  - Keep templates simple and avoid complex logic
  - Use native control flow (`@if`, `@for`, `@switch`) instead of `*ngIf`, `*ngFor`, `*ngSwitch`
  - Use the async pipe to handle observables
  - Do not assume globals like (`new Date()`) are available. 
  - Do not write arrow functions in templates (they are not supported).
  - Do not write Regular expressions in templates (they are not supported).
  ## Services
  - Design services around a single responsibility
  - Use the `providedIn: 'root'` option for singleton services
  - Use the `inject()` function instead of constructor injection 
  �
  


  ---

  **Java Design & Quality Rules**

  ### **Best Practices to Follow**
  1. **File Length & Structure**
     * Never exceed 500 lines per file.
     * Organize code using folders and logical naming conventions.
  2. **OOP & Design Principles**
     * Encapsulate functionality in dedicated classes, structs, or protocols.
     * Favor composition over inheritance.
     * Follow Single Responsibility Principle (one class/function does one thing).
     * Use modular design: components should be interchangeable, testable, and loosely coupled.
  4. **Function & Class Size**
     * Keep functions under 30–40 lines.
     * If a class exceeds 200 lines, consider splitting into helper classes.
  5. **Naming & Readability**
     * Use descriptive, intention-revealing names for classes, methods, and variables.
     * Avoid vague names like data, info, helper, or temp.
  6. **Scalability Mindset**
     * Code as if others will scale it.
     * Include extension points and consider dependency injection from day one.
  7. **Avoid “God” Classes**
     * Don’t let one file or class hold everything. 



  </details>

  ### 🧠 User Rules & Memories

  <details>
  <summary>View User Rules & Memories</summary>

  **dependent files before claiming completion
Untitled**

  �
  Rule 1: Angular Component Development
  When working on ANY Angular component (features, bugs, refactoring, migrations):
  1. ALWAYS read BOTH .ts AND .html files before making changes
  2. Apply changes to BOTH TypeScript and HTML in the same session
  3. Never modify TypeScript without verifying HTML impact (and vice versa)
  4. An Angular component is a UNIT (TS + HTML + potentially CSS/spec) - treat it as such
  5. Missing signal parentheses () in templates can cause ngtsc errors without linter warnings
  
  Rule 2: Systematic Work Process
  For ANY development task (features, bugs, debugging, refactoring, migrations):
  1. Work on ONE component/file/issue at a time
  2. Read relevant files completely before making changes
  3. Report what was changed clearly after completion
  4. Wait for user approval before proceeding to next item in multi-step work
  5. Never batch multiple components/issues without explicit approval
  
  Rule 3: Verification Over Assumption
  When encountering ANY uncertainty (features, debugging, dependencies, APIs):
  1. NEVER guess or assume - verify by reading source code/docs
  2. For library defaults: check actual implementation files (.mjs, source code), not just type definitions
  3. If a solution doesn't match established patterns, ask before applying
  4. Report what cannot be verified and request guidance
  5. Check related

  *Created: 30/10/2025, 17:30:14*


  </details>

## 🤖 Agent Response #2

  **🕐 Timestamp:** 2026-01-11T18:36:20.097Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 💬 Response

  ? **Console errors fixed!**
  
  The only remaining message is the React DevTools recommendation (expected in dev mode). All the actual errors are gone:
  
  ### Fixes Applied:
  
  1. **Missing translations fix** (`experience.tsx`)
     - Changed from trying all indices [0,1,2,3] to using a mapping of how many descriptions each job has
     - Stellar now correctly loads only 2 descriptions
  
  2. **Hydration error fix** (`projects.tsx`)
     - Replaced nested `<a>` tags with `<button>` elements + `onClick` handlers
     - Card navigation now uses `router.push()` instead of wrapping with `<Link>`
     - External links use `window.open()` with `stopPropagation()`
  
  ---
  
  **Now, about those visual issues you mentioned earlier** - go ahead and share screenshots or describe them, and I'll fix those too! ??

  ### 📝 File Changes

  #### ✏️ `experience.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\experience.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { Briefcase, Calendar, ChevronDown } from 'lucide-react';
  
  interface ExperienceData {
    key: string;
    technologies?: string[];
  }
  
  const experienceData: ExperienceData[] = [
    {
      key: 'vermeg_lead',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'GitLab CI/CD', 'Docker'],
    },
    {
      key: 'vermeg_dev',
      technologies: ['Angular', 'Jest', 'Cypress', 'Figma', 'SASS', 'REST APIs'],
    },
    {
      key: 'transcom',
    },
    {
      key: 'stellar',
    },
  ];
  
  function ExperienceCard({
    expKey,
    technologies,
    index,
  }: {
    expKey: string;
    technologies?: string[];
    index: number;
  }) {
    const t = useTranslations('experience.jobs');
    const [isExpanded, setIsExpanded] = useState(index === 0);
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
  
    // Get description array from translations
    const descriptionKeys = [0, 1, 2, 3];
    const descriptions: string[] = [];
    descriptionKeys.forEach((i) => {
      try {
        const desc = t(`${expKey}.description.${i}`);
        if (desc && !desc.includes('description')) {
          descriptions.push(desc);
        }
      } catch {
        // Key doesn't exist
      }
    });
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, x: -50 }}
        animate={isInView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="relative pl-8 pb-8 last:pb-0"
      >
        {/* Timeline Line */}
        <div className="absolute left-0 top-0 bottom-0 w-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
        
        {/* Timeline Dot */}
        <motion.div
          className="absolute left-0 top-0 w-4 h-4 -translate-x-1/2 rounded-full bg-day-accent dark:bg-night-cyan"
          initial={{ scale: 0 }}
          animate={isInView ? { scale: 1 } : {}}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
        >
          <div className="absolute inset-0 rounded-full bg-day-accent dark:bg-night-cyan animate-ping opacity-20" />
        </motion.div>
  
        {/* Card */}
        <motion.div
          className="bento-card cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
          whileHover={{ x: 5 }}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text mb-1">
                {t(`${expKey}.title`)}
              </h3>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="flex items-center gap-1 text-day-accent dark:text-night-cyan font-medium">
                  <Briefcase className="w-4 h-4" />
                  {t(`${expKey}.company`)}
                </span>
                <span className="text-day-comment dark:text-night-comment">
                  {t(`${expKey}.location`)}
                </span>
                <span className="flex items-center gap-1 text-day-comment dark:text-night-comment font-mono text-xs">
                  <Calendar className="w-3 h-3" />
                  {t(`${expKey}.period`)}
                </span>
              </div>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="text-day-comment dark:text-night-comment"
            >
              <ChevronDown className="w-5 h-5" />
            </motion.div>
          </div>
  
          {/* Expanded Content */}
          <motion.div
            initial={false}
            animate={{
              height: isExpanded ? 'auto' : 0,
              opacity: isExpanded ? 1 : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <ul className="mt-4 space-y-2">
              {descriptions.map((item, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2 text-day-text/80 dark:text-night-text/80 text-sm"
                >
                  <span className="text-day-accent dark:text-night-cyan mt-1">?</span>
                  {item}
                </li>
              ))}
            </ul>
  
            {technologies && (
              <div className="mt-4 flex flex-wrap gap-2">
                {technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Experience() {
    const t = useTranslations('experience');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="experience" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Timeline */}
            <div className="max-w-3xl">
              {experienceData.map((exp, index) => (
                <ExperienceCard
                  key={exp.key}
                  expKey={exp.key}
                  technologies={exp.technologies}
                  index={index}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { Briefcase, Calendar, ChevronDown } from 'lucide-react';
  
  interface ExperienceData {
    key: string;
    technologies?: string[];
  }
  
  const experienceData: ExperienceData[] = [
    {
      key: 'vermeg_lead',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'GitLab CI/CD', 'Docker'],
    },
    {
      key: 'vermeg_dev',
      technologies: ['Angular', 'Jest', 'Cypress', 'Figma', 'SASS', 'REST APIs'],
    },
    {
      key: 'transcom',
    },
    {
      key: 'stellar',
    },
  ];
  
  function ExperienceCard({
    expKey,
    technologies,
    index,
  }: {
    expKey: string;
    technologies?: string[];
    index: number;
  }) {
    const t = useTranslations('experience.jobs');
    const [isExpanded, setIsExpanded] = useState(index === 0);
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
  
    // Get description array from translations based on job
    const descriptionCounts: Record<string, number> = {
      vermeg_lead: 4,
      vermeg_dev: 4,
      transcom: 4,
      stellar: 2,
    };
    
    const count = descriptionCounts[expKey] || 0;
    const descriptions: string[] = [];
    for (let i = 0; i < count; i++) {
      descriptions.push(t(`${expKey}.description.${i}`));
    }
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, x: -50 }}
        animate={isInView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="relative pl-8 pb-8 last:pb-0"
      >
        {/* Timeline Line */}
        <div className="absolute left-0 top-0 bottom-0 w-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
        
        {/* Timeline Dot */}
        <motion.div
          className="absolute left-0 top-0 w-4 h-4 -translate-x-1/2 rounded-full bg-day-accent dark:bg-night-cyan"
          initial={{ scale: 0 }}
          animate={isInView ? { scale: 1 } : {}}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
        >
          <div className="absolute inset-0 rounded-full bg-day-accent dark:bg-night-cyan animate-ping opacity-20" />
        </motion.div>
  
        {/* Card */}
        <motion.div
          className="bento-card cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
          whileHover={{ x: 5 }}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text mb-1">
                {t(`${expKey}.title`)}
              </h3>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="flex items-center gap-1 text-day-accent dark:text-night-cyan font-medium">
                  <Briefcase className="w-4 h-4" />
                  {t(`${expKey}.company`)}
                </span>
                <span className="text-day-comment dark:text-night-comment">
                  {t(`${expKey}.location`)}
                </span>
                <span className="flex items-center gap-1 text-day-comment dark:text-night-comment font-mono text-xs">
                  <Calendar className="w-3 h-3" />
                  {t(`${expKey}.period`)}
                </span>
              </div>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="text-day-comment dark:text-night-comment"
            >
              <ChevronDown className="w-5 h-5" />
            </motion.div>
          </div>
  
          {/* Expanded Content */}
          <motion.div
            initial={false}
            animate={{
              height: isExpanded ? 'auto' : 0,
              opacity: isExpanded ? 1 : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <ul className="mt-4 space-y-2">
              {descriptions.map((item, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2 text-day-text/80 dark:text-night-text/80 text-sm"
                >
                  <span className="text-day-accent dark:text-night-cyan mt-1">?</span>
                  {item}
                </li>
              ))}
            </ul>
  
            {technologies && (
              <div className="mt-4 flex flex-wrap gap-2">
                {technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Experience() {
    const t = useTranslations('experience');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="experience" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Timeline */}
            <div className="max-w-3xl">
              {experienceData.map((exp, index) => (
                <ExperienceCard
                  key={exp.key}
                  expKey={exp.key}
                  technologies={exp.technologies}
                  index={index}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `projects.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\projects.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import Link from 'next/link';
  import { ExternalLink, Github, Star, Folder, ArrowRight } from 'lucide-react';
  
  interface ProjectData {
    key: string;
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    featured?: boolean;
    detailPage?: string; // Path to detail page
  }
  
  const projectsData: ProjectData[] = [
    {
      key: 'veggo',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'SASS', 'Storybook'],
      featured: true,
      detailPage: '/projects/veggo',
    },
    {
      key: 'pijiz',
      technologies: ['Shopify', 'Liquid', 'JavaScript', 'CSS'],
      liveUrl: 'https://pijiz.com',
      detailPage: '/projects/pijiz',
    },
    {
      key: 'dubai',
      technologies: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS'],
    },
    {
      key: 'banking',
      technologies: ['Angular', 'TypeScript', 'Jest', 'Cypress'],
      detailPage: '/projects/banking',
    },
    {
      key: 'nrg',
      technologies: ['WordPress', 'PHP', 'CSS', 'SEO'],
      liveUrl: 'https://nrgglobalpower.us',
    },
  ];
  
  function ProjectCard({ project, index }: { project: ProjectData; index: number }) {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
    const [isHovered, setIsHovered] = useState(false);
  
    const CardWrapper = project.detailPage ? Link : 'div';
    const cardProps = project.detailPage
      ? { href: project.detailPage }
      : {};
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className={`group ${project.featured ? 'md:col-span-2' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardWrapper
          {...cardProps}
          className={`block ${project.detailPage ? 'cursor-pointer' : ''}`}
        >
          <motion.div
            className="bento-card h-full relative overflow-hidden"
            whileHover={{ y: -5 }}
            style={{
              transformStyle: 'preserve-3d',
            }}
          >
            {/* Featured Badge */}
            {project.featured && (
              <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-day-accent/10 dark:bg-night-cyan/10 rounded-full text-day-accent dark:text-night-cyan text-xs font-mono z-10">
                <Star className="w-3 h-3" />
                {t('featured')}
              </div>
            )}
  
            {/* Image Placeholder */}
            <div className="relative mb-4 rounded-lg overflow-hidden bg-day-bg-highlight dark:bg-night-bg-highlight aspect-video">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Folder className="w-12 h-12 mx-auto mb-2 text-day-accent/40 dark:text-night-cyan/40" />
                  <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                    {t('screenshotPlaceholder')}
                  </p>
                </div>
              </div>
              
              {/* Hover Overlay */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-day-accent/80 dark:from-night-cyan/80 to-transparent flex items-end justify-center p-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: isHovered ? 1 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex gap-3">
                  {project.detailPage && (
                    <span className="px-4 py-2 rounded-full bg-white/90 text-day-accent font-medium text-sm flex items-center gap-2">
                      {t('viewDetails')}
                      <ArrowRight className="w-4 h-4" />
                    </span>
                  )}
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                      aria-label="View live site"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  )}
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                      aria-label="View source code"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Github className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </motion.div>
            </div>
  
            {/* Content */}
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="text-lg font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors">
                  {t(`items.${project.key}.title`)}
                </h3>
                <span className="text-xs font-mono text-day-comment dark:text-night-comment whitespace-nowrap">
                  {t(`items.${project.key}.period`)}
                </span>
              </div>
              
              <p className="text-sm text-day-text/70 dark:text-night-text/70 mb-4 leading-relaxed">
                {t(`items.${project.key}.description`)}
              </p>
  
              {/* Technologies */}
              <div className="flex flex-wrap gap-2">
                {project.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
  
            {/* Links for non-hovered state */}
            <div className="mt-4 flex gap-4">
              {project.detailPage && (
                <span className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan font-medium">
                  {t('viewDetails')}
                  <ArrowRight className="w-4 h-4" />
                </span>
              )}
              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
                  onClick={(e) => e.stopPropagation()}
                >
                  <ExternalLink className="w-4 h-4" />
                  {t('viewLive')}
                </a>
              )}
              {project.githubUrl && (
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
                  onClick={(e) => e.stopPropagation()}
                >
                  <Github className="w-4 h-4" />
                  {t('viewCode')}
                </a>
              )}
            </div>
          </motion.div>
        </CardWrapper>
      </motion.div>
    );
  }
  
  export function Projects() {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="projects" className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {projectsData.map((project, index) => (
                <ProjectCard key={project.key} project={project} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { useRouter } from 'next/navigation';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { ExternalLink, Github, Star, Folder, ArrowRight } from 'lucide-react';
  
  interface ProjectData {
    key: string;
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    featured?: boolean;
    detailPage?: string;
  }
  
  const projectsData: ProjectData[] = [
    {
      key: 'veggo',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'SASS', 'Storybook'],
      featured: true,
      detailPage: '/projects/veggo',
    },
    {
      key: 'pijiz',
      technologies: ['Shopify', 'Liquid', 'JavaScript', 'CSS'],
      liveUrl: 'https://pijiz.com',
      detailPage: '/projects/pijiz',
    },
    {
      key: 'dubai',
      technologies: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS'],
    },
    {
      key: 'banking',
      technologies: ['Angular', 'TypeScript', 'Jest', 'Cypress'],
      detailPage: '/projects/banking',
    },
    {
      key: 'nrg',
      technologies: ['WordPress', 'PHP', 'CSS', 'SEO'],
      liveUrl: 'https://nrgglobalpower.us',
    },
  ];
  
  function ProjectCard({ project, index }: { project: ProjectData; index: number }) {
    const t = useTranslations('projects');
    const router = useRouter();
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
    const [isHovered, setIsHovered] = useState(false);
  
    const handleCardClick = () => {
      if (project.detailPage) {
        router.push(project.detailPage);
      }
    };
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className={`group ${project.featured ? 'md:col-span-2' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <motion.div
          className={`bento-card h-full relative overflow-hidden ${project.detailPage ? 'cursor-pointer' : ''}`}
          whileHover={{ y: -5 }}
          onClick={handleCardClick}
          style={{
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Featured Badge */}
          {project.featured && (
            <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-day-accent/10 dark:bg-night-cyan/10 rounded-full text-day-accent dark:text-night-cyan text-xs font-mono z-10">
              <Star className="w-3 h-3" />
              {t('featured')}
            </div>
          )}
  
          {/* Image Placeholder */}
          <div className="relative mb-4 rounded-lg overflow-hidden bg-day-bg-highlight dark:bg-night-bg-highlight aspect-video">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Folder className="w-12 h-12 mx-auto mb-2 text-day-accent/40 dark:text-night-cyan/40" />
                <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                  {t('screenshotPlaceholder')}
                </p>
              </div>
            </div>
            
            {/* Hover Overlay */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-t from-day-accent/80 dark:from-night-cyan/80 to-transparent flex items-end justify-center p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex gap-3">
                {project.detailPage && (
                  <span className="px-4 py-2 rounded-full bg-white/90 text-day-accent font-medium text-sm flex items-center gap-2">
                    {t('viewDetails')}
                    <ArrowRight className="w-4 h-4" />
                  </span>
                )}
                {project.liveUrl && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(project.liveUrl, '_blank', 'noopener,noreferrer');
                    }}
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View live site"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </button>
                )}
                {project.githubUrl && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(project.githubUrl, '_blank', 'noopener,noreferrer');
                    }}
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View source code"
                  >
                    <Github className="w-5 h-5" />
                  </button>
                )}
              </div>
            </motion.div>
          </div>
  
          {/* Content */}
          <div>
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors">
                {t(`items.${project.key}.title`)}
              </h3>
              <span className="text-xs font-mono text-day-comment dark:text-night-comment whitespace-nowrap">
                {t(`items.${project.key}.period`)}
              </span>
            </div>
            
            <p className="text-sm text-day-text/70 dark:text-night-text/70 mb-4 leading-relaxed">
              {t(`items.${project.key}.description`)}
            </p>
  
            {/* Technologies */}
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
  
          {/* Links for non-hovered state */}
          <div className="mt-4 flex gap-4">
            {project.detailPage && (
              <span className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan font-medium">
                {t('viewDetails')}
                <ArrowRight className="w-4 h-4" />
              </span>
            )}
            {project.liveUrl && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(project.liveUrl, '_blank', 'noopener,noreferrer');
                }}
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <ExternalLink className="w-4 h-4" />
                {t('viewLive')}
              </button>
            )}
            {project.githubUrl && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(project.githubUrl, '_blank', 'noopener,noreferrer');
                }}
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <Github className="w-4 h-4" />
                {t('viewCode')}
              </button>
            )}
          </div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Projects() {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="projects" className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {projectsData.map((project, index) => (
                <ProjectCard key={project.key} project={project} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

