
---

## 👤 User Prompt #1

  **🕐 Timestamp:** 2026-01-11T18:05:02.838Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 📝 Prompt

  add internationalization with french/english switcher.

  ### 📎 Attachments

  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\package.json`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\tsconfig.json`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\next.config.js`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\postcss.config.js`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\tailwind.config.ts`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\.gitignore`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\globals.css`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\theme-provider.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\theme-toggle.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\navigation.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\hero.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\about.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\experience.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\projects.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\skills.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\certifications.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\contact.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\footer.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\index.ts`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\layout.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\page.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\README.md`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\public\.gitkeep`
  - **[file]** `c:\Users\kkhaled\.cursor\projects\c-Users-kkhaled-Desktop-Personal-portfolio\terminals\2.txt`

  ### 📋 Team Rules

  <details>
  <summary>View Team Rules</summary>

  **Angular Standard Rules**

  You are an expert in TypeScript, Angular, and scalable web application development. You write functional, maintainable, performant, and accessible code following Angular and TypeScript best practices.
  ## TypeScript Best Practices
  - Use strict type checking
  - Prefer type inference when the type is obvious
  - Avoid the `any` type; use `unknown` when type is uncertain
  ## Angular Best Practices
  - Always use standalone components over NgModules
  - Must NOT set `standalone: true` inside Angular decorators. It's the default in Angular v20+.
  - Use signals for state management
  - Implement lazy loading for feature routes
  - Do NOT use the `@HostBinding` and `@HostListener` decorators. Put host bindings inside the `host` object of the `@Component` or `@Directive` decorator instead
  - Use `NgOptimizedImage` for all static images.
    - `NgOptimizedImage` does not work for inline base64 images.
  ## Accessibility Requirements
  - It MUST pass all AXE checks.
  - It MUST follow all WCAG AA minimums, including focus management, color contrast, and ARIA attributes.
  ### Components
  - Keep components small and focused on a single responsibility
  - Use `input()` and `output()` functions instead of decorators
  - Use `computed()` for derived state
  - Set `changeDetection: ChangeDetectionStrategy.OnPush` in `@Component` decorator
  - Prefer inline templates for small components
  - Prefer Reactive forms instead of Template-driven ones
  - Do NOT use `ngClass`, use `class` bindings instead
  - Do NOT use `ngStyle`, use `style` bindings instead
  - When using external templates/styles, use paths relative to the component TS file.
  ## State Management
  - Use signals for local component state
  - Use `computed()` for derived state
  - Keep state transformations pure and predictable
  - Do NOT use `mutate` on signals, use `update` or `set` instead
  ## Templates
  - Keep templates simple and avoid complex logic
  - Use native control flow (`@if`, `@for`, `@switch`) instead of `*ngIf`, `*ngFor`, `*ngSwitch`
  - Use the async pipe to handle observables
  - Do not assume globals like (`new Date()`) are available. 
  - Do not write arrow functions in templates (they are not supported).
  - Do not write Regular expressions in templates (they are not supported).
  ## Services
  - Design services around a single responsibility
  - Use the `providedIn: 'root'` option for singleton services
  - Use the `inject()` function instead of constructor injection 
  �
  


  ---

  **Java Design & Quality Rules**

  ### **Best Practices to Follow**
  1. **File Length & Structure**
     * Never exceed 500 lines per file.
     * Organize code using folders and logical naming conventions.
  2. **OOP & Design Principles**
     * Encapsulate functionality in dedicated classes, structs, or protocols.
     * Favor composition over inheritance.
     * Follow Single Responsibility Principle (one class/function does one thing).
     * Use modular design: components should be interchangeable, testable, and loosely coupled.
  4. **Function & Class Size**
     * Keep functions under 30–40 lines.
     * If a class exceeds 200 lines, consider splitting into helper classes.
  5. **Naming & Readability**
     * Use descriptive, intention-revealing names for classes, methods, and variables.
     * Avoid vague names like data, info, helper, or temp.
  6. **Scalability Mindset**
     * Code as if others will scale it.
     * Include extension points and consider dependency injection from day one.
  7. **Avoid “God” Classes**
     * Don’t let one file or class hold everything. 



  </details>

  ### 🧠 User Rules & Memories

  <details>
  <summary>View User Rules & Memories</summary>

  **dependent files before claiming completion
Untitled**

  �
  Rule 1: Angular Component Development
  When working on ANY Angular component (features, bugs, refactoring, migrations):
  1. ALWAYS read BOTH .ts AND .html files before making changes
  2. Apply changes to BOTH TypeScript and HTML in the same session
  3. Never modify TypeScript without verifying HTML impact (and vice versa)
  4. An Angular component is a UNIT (TS + HTML + potentially CSS/spec) - treat it as such
  5. Missing signal parentheses () in templates can cause ngtsc errors without linter warnings
  
  Rule 2: Systematic Work Process
  For ANY development task (features, bugs, debugging, refactoring, migrations):
  1. Work on ONE component/file/issue at a time
  2. Read relevant files completely before making changes
  3. Report what was changed clearly after completion
  4. Wait for user approval before proceeding to next item in multi-step work
  5. Never batch multiple components/issues without explicit approval
  
  Rule 3: Verification Over Assumption
  When encountering ANY uncertainty (features, debugging, dependencies, APIs):
  1. NEVER guess or assume - verify by reading source code/docs
  2. For library defaults: check actual implementation files (.mjs, source code), not just type definitions
  3. If a solution doesn't match established patterns, ask before applying
  4. Report what cannot be verified and request guidance
  5. Check related

  *Created: 30/10/2025, 17:30:14*


  </details>

## 🤖 Agent Response #1

  **🕐 Timestamp:** 2026-01-11T18:12:13.112Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 💬 Response

  ---
  
  ## ? Portfolio Complete with Internationalization!
  
  Your Next.js portfolio is now fully functional with **French/English language support**. Here's what's included:
  
  ### ?? Internationalization Features
  - **Language Switcher** in the navigation (globe icon with dropdown)
  - **Automatic URL routing**: `/` for English, `/fr` for French
  - **Complete translations** for all content in both languages
  - **Locale-aware metadata** (page titles, descriptions)
  
  ### ?? Files Added/Updated for i18n
  
  | File | Purpose |
  |------|---------|
  | `src/i18n/config.ts` | Locale configuration (en, fr) |
  | `src/i18n/request.ts` | Next-intl request config |
  | `src/i18n/locales/en.json` | English translations |
  | `src/i18n/locales/fr.json` | French translations |
  | `src/middleware.ts` | Locale routing middleware |
  | `src/components/language-switcher.tsx` | Language dropdown component |
  
  ### ?? To Deploy on Vercel
  
  1. Push to GitHub:
     ```bash
     git init
     git add .
     git commit -m "Initial portfolio with i18n"
     git remote add origin https://github.com/Khalil-Khaled/portfolio.git
     git push -u origin main
     ```
  
  2. Go to [vercel.com](https://vercel.com) and import your repository
  3. Deploy with one click - it's free!
  
  ### ?? What You Need to Add
  
  1. **Your photo** - Replace the placeholder in About section
  2. **Project screenshots** - Add to `public/projects/` folder
  3. **Your CV PDF** - Add as `public/cv.pdf`
  
  The portfolio is running at **http://localhost:3000** - try switching between ???? English and ???? Fran?ais using the language dropdown! ??

  ### 📝 File Changes

  #### ✏️ `en.json`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\en.json`

  **🟢 New:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Frontend Engineer",
      "description": "Frontend engineer with 5+ years of experience building scalable, modern web applications using Angular, React, and TypeScript."
    },
    "nav": {
      "about": "About",
      "experience": "Experience",
      "projects": "Projects",
      "skills": "Skills",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Available for opportunities",
      "greeting": "Hi, I'm",
      "title": "Frontend Engineer",
      "titleSeparator": "|",
      "subtitle": "Angular Expert",
      "location": "Tunis, Tunisia ? Open to relocation",
      "description": "Building scalable, modern web applications with {years} of experience. Passionate about UI performance, developer experience, and clean architecture.",
      "yearsExperience": "5+ years",
      "cta": {
        "contact": "Get in Touch",
        "projects": "View Projects"
      },
      "scroll": "scroll"
    },
    "about": {
      "sectionNumber": "01",
      "title": "About Me",
      "paragraph1": "I'm a frontend engineer passionate about building <accent>scalable, modern web applications</accent> that deliver exceptional user experiences. With expertise in Angular and a strong foundation in React and TypeScript, I bring ideas to life with clean, maintainable code.",
      "paragraph2": "Currently at <company>VERMEG</company>, I lead frontend development for a low-code platform, where I've designed a <accent>reusable component library of 75+ widgets</accent> and mentored junior developers. I'm always exploring new technologies and best practices to level up my craft.",
      "paragraph3": "When I'm not coding, you'll find me contributing to open-source, exploring AI/ML certifications, or planning my next adventure. I'm open to international relocation and excited about new challenges in dynamic, product-driven teams.",
      "techTitle": "Technologies I work with daily:",
      "stats": {
        "years": "Years Experience",
        "components": "Components Built",
        "bugs": "Bugs Squashed",
        "languages": "Languages Spoken"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Experience",
      "jobs": {
        "vermeg_lead": {
          "title": "Software Engineer ? Frontend (Low-Code Platform)",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Jan 2024 ? Present",
          "description": [
            "Led code reviews and mentored 2 junior developers, improving code quality and onboarding efficiency.",
            "Designed and developed a reusable Angular component library (75+ widgets), reducing duplication by 35%.",
            "Migrated GitLab CI/CD pipelines to cloud, achieving 65% faster build times and 30% fewer failures.",
            "Contributed to functional design and actively participated in Agile ceremonies."
          ]
        },
        "vermeg_dev": {
          "title": "Frontend Developer ? Financial Products",
          "company": "VERMEG",
          "location": "Tunisia",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Fixed 160+ bugs and delivered high-impact features across multiple Angular-based financial apps.",
            "Refactored legacy modules and contributed to Angular version upgrades (v11 to v16).",
            "Achieved 95% test coverage with unit and E2E testing (Jest, Cypress).",
            "Collaborated with UI/UX teams to convert Figma prototypes into scalable, responsive interfaces."
          ]
        },
        "transcom": {
          "title": "Customer Service Representative ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisia",
          "period": "Oct 2017 ? Apr 2020",
          "description": [
            "Handled customer calls and support inquiries in English and French.",
            "Managed PayPal claims, disputes, and technical issues related to e-commerce integrations.",
            "Assisted in onboarding new hires through peer mentoring and training.",
            "Achieved 90%+ in KPIs related to resolution time, empathy, and customer satisfaction."
          ]
        },
        "stellar": {
          "title": "Software Developer Intern ? Game Development",
          "company": "Stellar VFX",
          "location": "Tunisia",
          "period": "Feb 2017 ? Jul 2017",
          "description": [
            "Built interactive game mechanics and UI with performance optimizations.",
            "Integrated assets and performed functional testing based on gameplay feedback."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projects",
      "featured": "Featured",
      "viewLive": "Live",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Low-Code Platform",
          "description": "Enterprise low-code platform for building financial applications. Led frontend development, designed 75+ reusable Angular widgets, and established component architecture patterns.",
          "period": "2024 - Present"
        },
        "pijiz": {
          "title": "E-commerce Store ? Pijiz",
          "description": "Shopify-based e-commerce platform with custom theme development, multi-language support, payment integration, and SEO optimization.",
          "period": "May 2024"
        },
        "dubai": {
          "title": "Visit Dubai UI Redesign",
          "description": "Freelance project to improve the UI/UX of Visit Dubai website. Enhanced page structure, navigation, and implemented responsive design fixes.",
          "period": "Jan 2024 - Feb 2024"
        },
        "banking": {
          "title": "Banking App Migration",
          "description": "Led the full framework upgrade from Angular v11 to v16 for a banking application. Refactored UI components and migrated custom themes.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Corporate Website",
          "description": "Built and deployed a corporate WordPress website with business email setup, SEO optimization, and GoDaddy hosting configuration.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Skills",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Testing",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "Security"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["Problem-solving", "Adaptability", "Team collaboration", "Communication", "Creativity", "Decision-making", "Mentoring"]
      },
      "languages": {
        "title": "Languages",
        "arabic": "Arabic",
        "arabicLevel": "Native",
        "english": "English",
        "englishLevel": "Fluent (B2)",
        "french": "French",
        "frenchLevel": "Fluent (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Education",
      "certificationsTitle": "Certifications",
      "educationTitle": "Education",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "October 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "July 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Engineering Degree ? Software Engineering",
          "institution": "ESPRIT University",
          "location": "Tunisia",
          "year": "2024"
        },
        "isamm": {
          "degree": "Bachelor's Degree in Computer Science",
          "institution": "Higher Institute of Multimedia Arts",
          "location": "Tunisia",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Get in Touch",
      "subtitle": "Let's Work Together",
      "description": "I'm currently open to new opportunities and exciting projects. Whether you have a question, want to discuss a potential collaboration, or just want to say hi, my inbox is always open!",
      "email": "Email",
      "phone": "Phone",
      "location": "Location",
      "findOnline": "Find me online:",
      "readyTitle": "Ready to Chat?",
      "readyDescription": "I typically respond within 24 hours. Looking forward to hearing from you!",
      "sendEmail": "Send Email",
      "orReachOut": "Or reach out on"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. All rights reserved.",
      "builtWith": "Built with",
      "using": "using"
    },
    "theme": {
      "switchToLight": "Switch to light mode",
      "switchToDark": "Switch to dark mode"
    },
    "language": {
      "switchTo": "Fran?ais",
      "current": "EN"
    }
  }
  
  ```

  #### ✏️ `fr.json`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\fr.json`

  **🟢 New:**

  ```
  {
    "meta": {
      "title": "Khalil Khaled | Ing?nieur Frontend",
      "description": "Ing?nieur frontend avec plus de 5 ans d'exp?rience dans la cr?ation d'applications web modernes et ?volutives avec Angular, React et TypeScript."
    },
    "nav": {
      "about": "? propos",
      "experience": "Exp?rience",
      "projects": "Projets",
      "skills": "Comp?tences",
      "contact": "Contact",
      "cv": "CV"
    },
    "hero": {
      "available": "Disponible pour de nouvelles opportunit?s",
      "greeting": "Bonjour, je suis",
      "title": "Ing?nieur Frontend",
      "titleSeparator": "|",
      "subtitle": "Expert Angular",
      "location": "Tunis, Tunisie ? Ouvert ? la relocalisation",
      "description": "Cr?ation d'applications web modernes et ?volutives avec {years} d'exp?rience. Passionn? par la performance UI, l'exp?rience d?veloppeur et l'architecture propre.",
      "yearsExperience": "5+ ans",
      "cta": {
        "contact": "Me Contacter",
        "projects": "Voir les Projets"
      },
      "scroll": "d?filer"
    },
    "about": {
      "sectionNumber": "01",
      "title": "? Propos de Moi",
      "paragraph1": "Je suis un ing?nieur frontend passionn? par la cr?ation d'<accent>applications web modernes et ?volutives</accent> qui offrent des exp?riences utilisateur exceptionnelles. Avec une expertise en Angular et une solide base en React et TypeScript, je donne vie aux id?es avec un code propre et maintenable.",
      "paragraph2": "Actuellement chez <company>VERMEG</company>, je dirige le d?veloppement frontend d'une plateforme low-code, o? j'ai con?u une <accent>biblioth?que de composants r?utilisables de 75+ widgets</accent> et mentor? des d?veloppeurs juniors. J'explore constamment de nouvelles technologies et bonnes pratiques pour am?liorer mes comp?tences.",
      "paragraph3": "Quand je ne code pas, vous me trouverez en train de contribuer ? l'open-source, d'explorer des certifications AI/ML, ou de planifier ma prochaine aventure. Je suis ouvert ? la relocalisation internationale et enthousiaste face aux nouveaux d?fis dans des ?quipes dynamiques orient?es produit.",
      "techTitle": "Technologies que j'utilise quotidiennement :",
      "stats": {
        "years": "Ans d'Exp?rience",
        "components": "Composants Cr??s",
        "bugs": "Bugs R?solus",
        "languages": "Langues Parl?es"
      },
      "imagePlaceholder": "profile-image.jpg"
    },
    "experience": {
      "sectionNumber": "02",
      "title": "Exp?rience",
      "jobs": {
        "vermeg_lead": {
          "title": "Ing?nieur Logiciel ? Frontend (Plateforme Low-Code)",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Jan 2024 ? Pr?sent",
          "description": [
            "Direction des revues de code et mentorat de 2 d?veloppeurs juniors, am?liorant la qualit? du code et l'efficacit? de l'int?gration.",
            "Conception et d?veloppement d'une biblioth?que de composants Angular r?utilisables (75+ widgets), r?duisant la duplication de 35%.",
            "Migration des pipelines GitLab CI/CD vers le cloud, atteignant 65% de temps de build plus rapides et 30% moins d'?checs.",
            "Contribution ? la conception fonctionnelle et participation active aux c?r?monies Agile."
          ]
        },
        "vermeg_dev": {
          "title": "D?veloppeur Frontend ? Produits Financiers",
          "company": "VERMEG",
          "location": "Tunisie",
          "period": "Oct 2020 ? Jan 2024",
          "description": [
            "Correction de 160+ bugs et livraison de fonctionnalit?s ? fort impact sur plusieurs applications financi?res Angular.",
            "Refactorisation de modules legacy et contribution aux mises ? niveau Angular (v11 ? v16).",
            "Atteinte de 95% de couverture de tests avec tests unitaires et E2E (Jest, Cypress).",
            "Collaboration avec les ?quipes UI/UX pour convertir les prototypes Figma en interfaces r?actives et ?volutives."
          ]
        },
        "transcom": {
          "title": "Repr?sentant Service Client ? PayPal",
          "company": "TRANSCOM",
          "location": "Tunisie",
          "period": "Oct 2017 ? Avr 2020",
          "description": [
            "Gestion des appels clients et demandes de support en anglais et fran?ais.",
            "Gestion des r?clamations PayPal, litiges et probl?mes techniques li?s aux int?grations e-commerce.",
            "Assistance ? l'int?gration des nouvelles recrues par le mentorat et la formation.",
            "Atteinte de 90%+ dans les KPIs li?s au temps de r?solution, l'empathie et la satisfaction client."
          ]
        },
        "stellar": {
          "title": "D?veloppeur Logiciel Stagiaire ? D?veloppement de Jeux",
          "company": "Stellar VFX",
          "location": "Tunisie",
          "period": "F?v 2017 ? Juil 2017",
          "description": [
            "Cr?ation de m?caniques de jeu interactives et d'UI avec optimisations de performance.",
            "Int?gration d'assets et tests fonctionnels bas?s sur les retours de gameplay."
          ]
        }
      }
    },
    "projects": {
      "sectionNumber": "03",
      "title": "Projets",
      "featured": "En vedette",
      "viewLive": "Voir",
      "viewCode": "Code",
      "screenshotPlaceholder": "screenshot.png",
      "items": {
        "veggo": {
          "title": "VEGGO ? Plateforme Low-Code",
          "description": "Plateforme low-code d'entreprise pour cr?er des applications financi?res. Direction du d?veloppement frontend, conception de 75+ widgets Angular r?utilisables et ?tablissement de patterns d'architecture de composants.",
          "period": "2024 - Pr?sent"
        },
        "pijiz": {
          "title": "Boutique E-commerce ? Pijiz",
          "description": "Plateforme e-commerce bas?e sur Shopify avec d?veloppement de th?me personnalis?, support multilingue, int?gration de paiement et optimisation SEO.",
          "period": "Mai 2024"
        },
        "dubai": {
          "title": "Refonte UI Visit Dubai",
          "description": "Projet freelance pour am?liorer l'UI/UX du site Visit Dubai. Am?lioration de la structure des pages, navigation et impl?mentation de corrections de design responsive.",
          "period": "Jan 2024 - F?v 2024"
        },
        "banking": {
          "title": "Migration App Bancaire",
          "description": "Direction de la mise ? niveau compl?te du framework d'Angular v11 ? v16 pour une application bancaire. Refactorisation des composants UI et migration des th?mes personnalis?s.",
          "period": "Nov 2023 - Jan 2024"
        },
        "nrg": {
          "title": "NRG Global Power ? Site Corporate",
          "description": "Cr?ation et d?ploiement d'un site WordPress corporate avec configuration d'email professionnel, optimisation SEO et configuration d'h?bergement GoDaddy.",
          "period": "Oct 2023"
        }
      }
    },
    "skills": {
      "sectionNumber": "04",
      "title": "Comp?tences",
      "categories": {
        "frontend": "Frontend",
        "backend": "Backend & APIs",
        "testing": "Tests",
        "devops": "DevOps & CI/CD",
        "design": "Design & UX",
        "security": "S?curit?"
      },
      "softSkills": {
        "title": "Soft Skills",
        "items": ["R?solution de probl?mes", "Adaptabilit?", "Travail d'?quipe", "Communication", "Cr?ativit?", "Prise de d?cision", "Mentorat"]
      },
      "languages": {
        "title": "Langues",
        "arabic": "Arabe",
        "arabicLevel": "Natif",
        "english": "Anglais",
        "englishLevel": "Courant (B2)",
        "french": "Fran?ais",
        "frenchLevel": "Courant (B2)"
      }
    },
    "certifications": {
      "sectionNumber": "05",
      "title": "Certifications & Formation",
      "certificationsTitle": "Certifications",
      "educationTitle": "Formation",
      "items": {
        "genai": {
          "title": "Oracle Cloud Infrastructure Generative AI Professional",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "aifoundations": {
          "title": "Oracle Cloud Infrastructure Certified AI Foundations Associate",
          "issuer": "Oracle",
          "date": "Octobre 2025"
        },
        "java": {
          "title": "Oracle Certified Professional: Java SE 11 Developer",
          "issuer": "Oracle",
          "date": "Juillet 2025"
        }
      },
      "education": {
        "esprit": {
          "degree": "Dipl?me d'Ing?nieur ? G?nie Logiciel",
          "institution": "ESPRIT University",
          "location": "Tunisie",
          "year": "2024"
        },
        "isamm": {
          "degree": "Licence en Informatique",
          "institution": "Institut Sup?rieur des Arts Multim?dia",
          "location": "Tunisie",
          "year": "2017"
        }
      }
    },
    "contact": {
      "sectionNumber": "06",
      "title": "Me Contacter",
      "subtitle": "Travaillons Ensemble",
      "description": "Je suis actuellement ouvert aux nouvelles opportunit?s et projets passionnants. Que vous ayez une question, souhaitiez discuter d'une collaboration potentielle, ou simplement dire bonjour, ma bo?te de r?ception est toujours ouverte !",
      "email": "Email",
      "phone": "T?l?phone",
      "location": "Localisation",
      "findOnline": "Retrouvez-moi en ligne :",
      "readyTitle": "Pr?t ? Discuter ?",
      "readyDescription": "Je r?ponds g?n?ralement sous 24 heures. Au plaisir de vous lire !",
      "sendEmail": "Envoyer un Email",
      "orReachOut": "Ou contactez-moi sur"
    },
    "footer": {
      "copyright": "? {year} Khalil Khaled. Tous droits r?serv?s.",
      "builtWith": "Construit avec",
      "using": "avec"
    },
    "theme": {
      "switchToLight": "Passer en mode clair",
      "switchToDark": "Passer en mode sombre"
    },
    "language": {
      "switchTo": "English",
      "current": "FR"
    }
  }
  
  ```

  #### ✏️ `config.ts`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\config.ts`

  **🟢 New:**

  ```
  export const locales = ['en', 'fr'] as const;
  export type Locale = (typeof locales)[number];
  
  export const defaultLocale: Locale = 'en';
  
  export const localeNames: Record<Locale, string> = {
    en: 'English',
    fr: 'Fran?ais',
  };
  
  export const localeFlags: Record<Locale, string> = {
    en: '????',
    fr: '????',
  };
  
  ```

  #### ✏️ `request.ts`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\request.ts`

  **🟢 New:**

  ```
  import { getRequestConfig } from 'next-intl/server';
  import { locales, defaultLocale, type Locale } from './config';
  
  export default getRequestConfig(async ({ locale }) => {
    // Validate that the incoming locale is valid
    const validLocale = locales.includes(locale as Locale) ? locale : defaultLocale;
  
    return {
      messages: (await import(`./locales/${validLocale}.json`)).default,
    };
  });
  
  ```

  #### ✏️ `middleware.ts`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\middleware.ts`

  **🟢 New:**

  ```
  import createMiddleware from 'next-intl/middleware';
  import { locales, defaultLocale } from './i18n/config';
  
  export default createMiddleware({
    locales,
    defaultLocale,
    localePrefix: 'as-needed',
  });
  
  export const config = {
    matcher: ['/', '/(fr|en)/:path*', '/((?!_next|_vercel|.*\\..*).*)'],
  };
  
  ```

  #### ✏️ `next.config.js`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\next.config.js`

  **🔴 Old:**

  ```
  /** @type {import('next').NextConfig} */
  const nextConfig = {
    images: {
      remotePatterns: [
        {
          protocol: 'https',
          hostname: '**',
        },
      ],
    },
  };
  
  module.exports = nextConfig;
  
  ```

  **🟢 New:**

  ```
  const createNextIntlPlugin = require('next-intl/plugin');
  
  const withNextIntl = createNextIntlPlugin('./src/i18n/request.ts');
  
  /** @type {import('next').NextConfig} */
  const nextConfig = {
    images: {
      remotePatterns: [
        {
          protocol: 'https',
          hostname: '**',
        },
      ],
    },
  };
  
  module.exports = withNextIntl(nextConfig);
  
  ```

  #### ✏️ `layout.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\layout.tsx`

  **🟢 New:**

  ```
  import type { Metadata } from 'next';
  import { NextIntlClientProvider } from 'next-intl';
  import { getMessages, getTranslations } from 'next-intl/server';
  import { GeistSans } from 'geist/font/sans';
  import { GeistMono } from 'geist/font/mono';
  import { ThemeProvider } from '@/components/theme-provider';
  import { Navigation } from '@/components/navigation';
  import { Footer } from '@/components/footer';
  import { locales, type Locale } from '@/i18n/config';
  import '../globals.css';
  
  export function generateStaticParams() {
    return locales.map((locale) => ({ locale }));
  }
  
  export async function generateMetadata({
    params: { locale },
  }: {
    params: { locale: Locale };
  }): Promise<Metadata> {
    const t = await getTranslations({ locale, namespace: 'meta' });
  
    return {
      title: t('title'),
      description: t('description'),
      keywords: [
        'Frontend Engineer',
        'Angular Developer',
        'React Developer',
        'TypeScript',
        'Web Development',
        'Tunisia',
        'Software Engineer',
      ],
      authors: [{ name: 'Khalil Khaled' }],
      creator: 'Khalil Khaled',
      openGraph: {
        type: 'website',
        locale: locale === 'fr' ? 'fr_FR' : 'en_US',
        url: 'https://khalilkhaled.dev',
        title: t('title'),
        description: t('description'),
        siteName: 'Khalil Khaled Portfolio',
      },
      twitter: {
        card: 'summary_large_image',
        title: t('title'),
        description: t('description'),
      },
      robots: {
        index: true,
        follow: true,
      },
    };
  }
  
  export default async function LocaleLayout({
    children,
    params: { locale },
  }: {
    children: React.ReactNode;
    params: { locale: Locale };
  }) {
    const messages = await getMessages();
  
    return (
      <html
        lang={locale}
        className={`${GeistSans.variable} ${GeistMono.variable}`}
        suppressHydrationWarning
      >
        <body className="antialiased">
          <NextIntlClientProvider messages={messages}>
            <ThemeProvider>
              <Navigation />
              <main>{children}</main>
              <Footer />
            </ThemeProvider>
          </NextIntlClientProvider>
        </body>
      </html>
    );
  }
  
  ```

  #### ✏️ `page.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\page.tsx`

  **🟢 New:**

  ```
  import { Hero } from '@/components/hero';
  import { About } from '@/components/about';
  import { Experience } from '@/components/experience';
  import { Projects } from '@/components/projects';
  import { Skills } from '@/components/skills';
  import { Certifications } from '@/components/certifications';
  import { Contact } from '@/components/contact';
  
  export default function Home() {
    return (
      <>
        <Hero />
        <About />
        <Experience />
        <Projects />
        <Skills />
        <Certifications />
        <Contact />
      </>
    );
  }
  
  ```

  #### ✏️ `language-switcher.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\language-switcher.tsx`

  **🟢 New:**

  ```
  'use client';
  
  import { useLocale, useTranslations } from 'next-intl';
  import { usePathname, useRouter } from 'next/navigation';
  import { motion, AnimatePresence } from 'framer-motion';
  import { useState, useRef, useEffect } from 'react';
  import { Globe, ChevronDown } from 'lucide-react';
  import { locales, localeNames, localeFlags, type Locale } from '@/i18n/config';
  
  export function LanguageSwitcher() {
    const locale = useLocale() as Locale;
    const router = useRouter();
    const pathname = usePathname();
    const t = useTranslations('language');
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);
  
    // Close dropdown when clicking outside
    useEffect(() => {
      function handleClickOutside(event: MouseEvent) {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
          setIsOpen(false);
        }
      }
  
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
  
    const switchLocale = (newLocale: Locale) => {
      // Get the path without the current locale prefix
      const segments = pathname.split('/');
      const isLocaleInPath = locales.includes(segments[1] as Locale);
      
      let newPath: string;
      if (isLocaleInPath) {
        segments[1] = newLocale;
        newPath = segments.join('/');
      } else {
        newPath = `/${newLocale}${pathname}`;
      }
  
      router.push(newPath);
      setIsOpen(false);
    };
  
    return (
      <div ref={dropdownRef} className="relative">
        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 px-3 py-2 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight text-sm font-medium hover:border-day-accent dark:hover:border-night-cyan transition-colors"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          aria-label="Select language"
          aria-expanded={isOpen}
          aria-haspopup="listbox"
        >
          <Globe className="w-4 h-4 text-day-accent dark:text-night-cyan" />
          <span className="hidden sm:inline">{localeFlags[locale]}</span>
          <span className="text-day-text dark:text-night-text">{t('current')}</span>
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.2 }}
          >
            <ChevronDown className="w-4 h-4 text-day-comment dark:text-night-comment" />
          </motion.div>
        </motion.button>
  
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute top-full right-0 mt-2 py-2 min-w-[140px] bg-day-bg dark:bg-night-bg border border-day-bg-highlight dark:border-night-bg-highlight rounded-xl shadow-xl z-50"
              role="listbox"
              aria-label="Available languages"
            >
              {locales.map((loc) => (
                <motion.button
                  key={loc}
                  onClick={() => switchLocale(loc)}
                  className={`w-full flex items-center gap-3 px-4 py-2 text-sm transition-colors ${
                    locale === loc
                      ? 'bg-day-accent/10 dark:bg-night-cyan/10 text-day-accent dark:text-night-cyan'
                      : 'text-day-text dark:text-night-text hover:bg-day-bg-alt dark:hover:bg-night-bg-alt'
                  }`}
                  whileHover={{ x: 3 }}
                  role="option"
                  aria-selected={locale === loc}
                >
                  <span className="text-lg">{localeFlags[loc]}</span>
                  <span>{localeNames[loc]}</span>
                  {locale === loc && (
                    <motion.span
                      layoutId="activeLocale"
                      className="ml-auto w-2 h-2 rounded-full bg-day-accent dark:bg-night-cyan"
                    />
                  )}
                </motion.button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }
  
  ```

  #### ✏️ `navigation.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\navigation.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { useState, useEffect } from 'react';
  import { motion, AnimatePresence } from 'framer-motion';
  import { Menu, X, Download } from 'lucide-react';
  import { ThemeToggle } from './theme-toggle';
  
  const navItems = [
    { name: 'About', href: '#about' },
    { name: 'Experience', href: '#experience' },
    { name: 'Projects', href: '#projects' },
    { name: 'Skills', href: '#skills' },
    { name: 'Contact', href: '#contact' },
  ];
  
  export function Navigation() {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
    useEffect(() => {
      const handleScroll = () => {
        setIsScrolled(window.scrollY > 50);
      };
  
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }, []);
  
    return (
      <>
        <motion.header
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.5 }}
          className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
            isScrolled
              ? 'bg-day-bg/80 dark:bg-night-bg/80 backdrop-blur-lg shadow-lg'
              : 'bg-transparent'
          }`}
        >
          <nav className="section-container py-4">
            <div className="flex items-center justify-between">
              {/* Logo */}
              <motion.a
                href="#"
                className="text-xl font-bold font-mono"
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-day-accent dark:text-night-cyan">{'<'}</span>
                <span className="text-day-text dark:text-night-text">KK</span>
                <span className="text-day-accent dark:text-night-cyan">{'/>'}</span>
              </motion.a>
  
              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-8">
                {navItems.map((item, index) => (
                  <motion.a
                    key={item.name}
                    href={item.href}
                    className="text-day-text/80 dark:text-night-text/80 hover:text-day-accent dark:hover:text-night-cyan transition-colors relative group"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    {item.name}
                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-day-accent dark:bg-night-cyan transition-all duration-300 group-hover:w-full" />
                  </motion.a>
                ))}
              </div>
  
              {/* Actions */}
              <div className="flex items-center gap-4">
                <motion.a
                  href="/cv.pdf"
                  download
                  className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium text-sm transition-all hover:shadow-lg hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Download className="w-4 h-4" />
                  <span>CV</span>
                </motion.a>
                
                <ThemeToggle />
  
                {/* Mobile Menu Button */}
                <motion.button
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="md:hidden w-10 h-10 flex items-center justify-center"
                  whileTap={{ scale: 0.95 }}
                  aria-label="Toggle menu"
                >
                  {isMobileMenuOpen ? (
                    <X className="w-6 h-6" />
                  ) : (
                    <Menu className="w-6 h-6" />
                  )}
                </motion.button>
              </div>
            </div>
          </nav>
        </motion.header>
  
        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed inset-0 z-40 bg-day-bg dark:bg-night-bg pt-20 md:hidden"
            >
              <nav className="section-container py-8">
                <div className="flex flex-col gap-6">
                  {navItems.map((item, index) => (
                    <motion.a
                      key={item.name}
                      href={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="text-2xl font-medium text-day-text dark:text-night-text hover:text-day-accent dark:hover:text-night-cyan transition-colors"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <span className="text-day-accent dark:text-night-cyan font-mono mr-2">
                        0{index + 1}.
                      </span>
                      {item.name}
                    </motion.a>
                  ))}
                  <motion.a
                    href="/cv.pdf"
                    download
                    className="flex items-center gap-2 mt-4 px-6 py-3 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium w-fit"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: navItems.length * 0.1 }}
                  >
                    <Download className="w-5 h-5" />
                    <span>Download CV</span>
                  </motion.a>
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useState, useEffect } from 'react';
  import { useTranslations } from 'next-intl';
  import { motion, AnimatePresence } from 'framer-motion';
  import { Menu, X, Download } from 'lucide-react';
  import { ThemeToggle } from './theme-toggle';
  import { LanguageSwitcher } from './language-switcher';
  
  export function Navigation() {
    const t = useTranslations('nav');
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
    const navItems = [
      { name: t('about'), href: '#about' },
      { name: t('experience'), href: '#experience' },
      { name: t('projects'), href: '#projects' },
      { name: t('skills'), href: '#skills' },
      { name: t('contact'), href: '#contact' },
    ];
  
    useEffect(() => {
      const handleScroll = () => {
        setIsScrolled(window.scrollY > 50);
      };
  
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }, []);
  
    return (
      <>
        <motion.header
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.5 }}
          className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
            isScrolled
              ? 'bg-day-bg/80 dark:bg-night-bg/80 backdrop-blur-lg shadow-lg'
              : 'bg-transparent'
          }`}
        >
          <nav className="section-container py-4">
            <div className="flex items-center justify-between">
              {/* Logo */}
              <motion.a
                href="#"
                className="text-xl font-bold font-mono"
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-day-accent dark:text-night-cyan">{'<'}</span>
                <span className="text-day-text dark:text-night-text">KK</span>
                <span className="text-day-accent dark:text-night-cyan">{'/>'}</span>
              </motion.a>
  
              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-8">
                {navItems.map((item, index) => (
                  <motion.a
                    key={item.name}
                    href={item.href}
                    className="text-day-text/80 dark:text-night-text/80 hover:text-day-accent dark:hover:text-night-cyan transition-colors relative group"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    {item.name}
                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-day-accent dark:bg-night-cyan transition-all duration-300 group-hover:w-full" />
                  </motion.a>
                ))}
              </div>
  
              {/* Actions */}
              <div className="flex items-center gap-3">
                <motion.a
                  href="/cv.pdf"
                  download
                  className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium text-sm transition-all hover:shadow-lg hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Download className="w-4 h-4" />
                  <span>{t('cv')}</span>
                </motion.a>
  
                <LanguageSwitcher />
                <ThemeToggle />
  
                {/* Mobile Menu Button */}
                <motion.button
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="md:hidden w-10 h-10 flex items-center justify-center"
                  whileTap={{ scale: 0.95 }}
                  aria-label="Toggle menu"
                >
                  {isMobileMenuOpen ? (
                    <X className="w-6 h-6" />
                  ) : (
                    <Menu className="w-6 h-6" />
                  )}
                </motion.button>
              </div>
            </div>
          </nav>
        </motion.header>
  
        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed inset-0 z-40 bg-day-bg dark:bg-night-bg pt-20 md:hidden"
            >
              <nav className="section-container py-8">
                <div className="flex flex-col gap-6">
                  {navItems.map((item, index) => (
                    <motion.a
                      key={item.name}
                      href={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="text-2xl font-medium text-day-text dark:text-night-text hover:text-day-accent dark:hover:text-night-cyan transition-colors"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <span className="text-day-accent dark:text-night-cyan font-mono mr-2">
                        0{index + 1}.
                      </span>
                      {item.name}
                    </motion.a>
                  ))}
                  <motion.a
                    href="/cv.pdf"
                    download
                    className="flex items-center gap-2 mt-4 px-6 py-3 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium w-fit"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: navItems.length * 0.1 }}
                  >
                    <Download className="w-5 h-5" />
                    <span>{t('cv')}</span>
                  </motion.a>
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }
  
  ```

  #### ✏️ `hero.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\hero.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion } from 'framer-motion';
  import { ArrowDown, Github, Linkedin, Mail, MapPin } from 'lucide-react';
  
  export function Hero() {
    return (
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 -z-10">
          {/* Gradient Orbs */}
          <motion.div
            className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-day-accent/20 dark:bg-night-cyan/20 blur-3xl"
            animate={{
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-day-accent-alt/20 dark:bg-night-accent/20 blur-3xl"
            animate={{
              x: [0, -30, 0],
              y: [0, 50, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.03)_1px,transparent_1px)] dark:bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
        </div>
  
        <div className="section-container py-20">
          <div className="max-w-4xl mx-auto text-center">
            {/* Greeting */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-6"
            >
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight text-sm font-mono">
                <span className="w-2 h-2 rounded-full bg-day-green dark:bg-night-green animate-pulse" />
                Available for opportunities
              </span>
            </motion.div>
  
            {/* Name */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-5xl sm:text-6xl md:text-7xl font-bold mb-4"
            >
              <span className="text-day-text dark:text-night-text">Khalil </span>
              <span className="text-gradient">Khaled</span>
            </motion.h1>
  
            {/* Title */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-6"
            >
              <h2 className="text-xl sm:text-2xl md:text-3xl text-day-text/80 dark:text-night-text/80 font-mono">
                <span className="text-day-accent dark:text-night-cyan">{'>'}</span>{' '}
                Frontend Engineer{' '}
                <span className="text-day-accent-alt dark:text-night-accent">|</span>{' '}
                Angular Expert
              </h2>
            </motion.div>
  
            {/* Location */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex items-center justify-center gap-2 text-day-comment dark:text-night-comment mb-8"
            >
              <MapPin className="w-4 h-4" />
              <span>Tunis, Tunisia ? Open to relocation</span>
            </motion.div>
  
            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="text-lg text-day-text/70 dark:text-night-text/70 max-w-2xl mx-auto mb-10 leading-relaxed"
            >
              Building scalable, modern web applications with{' '}
              <span className="text-day-accent dark:text-night-cyan font-medium">5+ years</span> of experience.
              Passionate about UI performance, developer experience, and clean architecture.
            </motion.p>
  
            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex flex-wrap items-center justify-center gap-4 mb-12"
            >
              <motion.a
                href="#contact"
                className="px-8 py-3 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium transition-all hover:shadow-xl hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                Get in Touch
              </motion.a>
              <motion.a
                href="#projects"
                className="px-8 py-3 rounded-full border border-day-accent dark:border-night-cyan text-day-accent dark:text-night-cyan font-medium hover:bg-day-accent/10 dark:hover:bg-night-cyan/10 transition-all"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                View Projects
              </motion.a>
            </motion.div>
  
            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="flex items-center justify-center gap-4"
            >
              {[
                { icon: Github, href: 'https://github.com/Khalil-Khaled', label: 'GitHub' },
                { icon: Linkedin, href: 'https://linkedin.com/in/khalil-khaled', label: 'LinkedIn' },
                { icon: Mail, href: 'mailto:khalilkhaled1995@gmail.com', label: 'Email' },
              ].map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  target={social.href.startsWith('http') ? '_blank' : undefined}
                  rel={social.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="w-12 h-12 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight flex items-center justify-center text-day-text/70 dark:text-night-text/70 hover:text-day-accent dark:hover:text-night-cyan hover:border-day-accent dark:hover:border-night-cyan transition-all"
                  whileHover={{ scale: 1.1, y: -3 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </motion.div>
          </div>
  
          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
          >
            <motion.a
              href="#about"
              className="flex flex-col items-center gap-2 text-day-comment dark:text-night-comment hover:text-day-accent dark:hover:text-night-cyan transition-colors"
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              aria-label="Scroll down"
            >
              <span className="text-xs font-mono">scroll</span>
              <ArrowDown className="w-4 h-4" />
            </motion.a>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion } from 'framer-motion';
  import { ArrowDown, Github, Linkedin, Mail, MapPin } from 'lucide-react';
  
  export function Hero() {
    const t = useTranslations('hero');
  
    return (
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 -z-10">
          {/* Gradient Orbs */}
          <motion.div
            className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-day-accent/20 dark:bg-night-cyan/20 blur-3xl"
            animate={{
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-day-accent-alt/20 dark:bg-night-accent/20 blur-3xl"
            animate={{
              x: [0, -30, 0],
              y: [0, 50, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.03)_1px,transparent_1px)] dark:bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
        </div>
  
        <div className="section-container py-20">
          <div className="max-w-4xl mx-auto text-center">
            {/* Greeting */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-6"
            >
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight text-sm font-mono">
                <span className="w-2 h-2 rounded-full bg-day-green dark:bg-night-green animate-pulse" />
                {t('available')}
              </span>
            </motion.div>
  
            {/* Name */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-5xl sm:text-6xl md:text-7xl font-bold mb-4"
            >
              <span className="text-day-text dark:text-night-text">Khalil </span>
              <span className="text-gradient">Khaled</span>
            </motion.h1>
  
            {/* Title */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-6"
            >
              <h2 className="text-xl sm:text-2xl md:text-3xl text-day-text/80 dark:text-night-text/80 font-mono">
                <span className="text-day-accent dark:text-night-cyan">{'>'}</span>{' '}
                {t('title')}{' '}
                <span className="text-day-accent-alt dark:text-night-accent">{t('titleSeparator')}</span>{' '}
                {t('subtitle')}
              </h2>
            </motion.div>
  
            {/* Location */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex items-center justify-center gap-2 text-day-comment dark:text-night-comment mb-8"
            >
              <MapPin className="w-4 h-4" />
              <span>{t('location')}</span>
            </motion.div>
  
            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="text-lg text-day-text/70 dark:text-night-text/70 max-w-2xl mx-auto mb-10 leading-relaxed"
            >
              {t('description', { years: '' })}
              <span className="text-day-accent dark:text-night-cyan font-medium">{t('yearsExperience')}</span>
              {t('description', { years: '' }).includes('{years}') ? '' : '.'}
            </motion.p>
  
            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex flex-wrap items-center justify-center gap-4 mb-12"
            >
              <motion.a
                href="#contact"
                className="px-8 py-3 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium transition-all hover:shadow-xl hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                {t('cta.contact')}
              </motion.a>
              <motion.a
                href="#projects"
                className="px-8 py-3 rounded-full border border-day-accent dark:border-night-cyan text-day-accent dark:text-night-cyan font-medium hover:bg-day-accent/10 dark:hover:bg-night-cyan/10 transition-all"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                {t('cta.projects')}
              </motion.a>
            </motion.div>
  
            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="flex items-center justify-center gap-4"
            >
              {[
                { icon: Github, href: 'https://github.com/Khalil-Khaled', label: 'GitHub' },
                { icon: Linkedin, href: 'https://linkedin.com/in/khalil-khaled', label: 'LinkedIn' },
                { icon: Mail, href: 'mailto:khalilkhaled1995@gmail.com', label: 'Email' },
              ].map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  target={social.href.startsWith('http') ? '_blank' : undefined}
                  rel={social.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="w-12 h-12 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight flex items-center justify-center text-day-text/70 dark:text-night-text/70 hover:text-day-accent dark:hover:text-night-cyan hover:border-day-accent dark:hover:border-night-cyan transition-all"
                  whileHover={{ scale: 1.1, y: -3 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </motion.div>
          </div>
  
          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
          >
            <motion.a
              href="#about"
              className="flex flex-col items-center gap-2 text-day-comment dark:text-night-comment hover:text-day-accent dark:hover:text-night-cyan transition-colors"
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              aria-label="Scroll down"
            >
              <span className="text-xs font-mono">{t('scroll')}</span>
              <ArrowDown className="w-4 h-4" />
            </motion.a>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `about.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\about.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion } from 'framer-motion';
  import { useInView } from 'framer-motion';
  import { useRef } from 'react';
  import { Code2, Users, Zap, Globe } from 'lucide-react';
  
  const stats = [
    { icon: Code2, value: '5+', label: 'Years Experience' },
    { icon: Users, value: '75+', label: 'Components Built' },
    { icon: Zap, value: '160+', label: 'Bugs Squashed' },
    { icon: Globe, value: '3', label: 'Languages Spoken' },
  ];
  
  export function About() {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="about" className="py-24 relative">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">01.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">About Me</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            <div className="grid md:grid-cols-2 gap-12 items-center">
              {/* Text Content */}
              <div className="space-y-6">
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  I&apos;m a frontend engineer passionate about building{' '}
                  <span className="text-day-accent dark:text-night-cyan font-medium">
                    scalable, modern web applications
                  </span>{' '}
                  that deliver exceptional user experiences. With expertise in Angular and a
                  strong foundation in React and TypeScript, I bring ideas to life with clean,
                  maintainable code.
                </p>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  Currently at <span className="font-medium">VERMEG</span>, I lead frontend
                  development for a low-code platform, where I&apos;ve designed a{' '}
                  <span className="text-day-accent dark:text-night-cyan font-medium">
                    reusable component library of 75+ widgets
                  </span>{' '}
                  and mentored junior developers. I&apos;m always exploring new technologies
                  and best practices to level up my craft.
                </p>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  When I&apos;m not coding, you&apos;ll find me contributing to open-source,
                  exploring AI/ML certifications, or planning my next adventure.
                  I&apos;m open to international relocation and excited about new challenges
                  in dynamic, product-driven teams.
                </p>
  
                {/* Tech Stack Highlight */}
                <div className="pt-4">
                  <p className="text-sm font-mono text-day-comment dark:text-night-comment mb-3">
                    Technologies I work with daily:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {['Angular', 'TypeScript', 'RxJS', 'NgRx', 'Tailwind', 'Jest', 'Cypress'].map(
                      (tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 text-sm font-mono bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight rounded-full text-day-accent dark:text-night-cyan"
                        >
                          {tech}
                        </span>
                      )
                    )}
                  </div>
                </div>
              </div>
  
              {/* Image Placeholder & Stats */}
              <div className="space-y-8">
                {/* Profile Image Placeholder */}
                <motion.div
                  className="relative aspect-square max-w-sm mx-auto"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-day-accent/20 to-day-accent-alt/20 dark:from-night-cyan/20 dark:to-night-accent/20 rounded-2xl transform rotate-3" />
                  <div className="relative bg-day-bg-alt dark:bg-night-bg-alt rounded-2xl overflow-hidden border border-day-bg-highlight dark:border-night-bg-highlight">
                    {/* Replace this div with your actual image */}
                    <div className="aspect-square flex items-center justify-center bg-gradient-to-br from-day-accent/10 to-day-accent-alt/10 dark:from-night-cyan/10 dark:to-night-accent/10">
                      <div className="text-center">
                        <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-day-bg-highlight dark:bg-night-bg-highlight flex items-center justify-center">
                          <span className="text-4xl font-bold text-gradient">KK</span>
                        </div>
                        <p className="text-sm text-day-comment dark:text-night-comment font-mono">
                          {/* Your photo here */}
                          profile-image.jpg
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
  
                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4">
                  {stats.map((stat, index) => (
                    <motion.div
                      key={stat.label}
                      className="bento-card text-center"
                      initial={{ opacity: 0, y: 20 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      whileHover={{ y: -5 }}
                    >
                      <stat.icon className="w-6 h-6 mx-auto mb-2 text-day-accent dark:text-night-cyan" />
                      <div className="text-2xl font-bold text-day-text dark:text-night-text">
                        {stat.value}
                      </div>
                      <div className="text-sm text-day-comment dark:text-night-comment">
                        {stat.label}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion } from 'framer-motion';
  import { useInView } from 'framer-motion';
  import { useRef } from 'react';
  import { Code2, Users, Zap, Globe } from 'lucide-react';
  
  export function About() {
    const t = useTranslations('about');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    const stats = [
      { icon: Code2, value: '5+', label: t('stats.years') },
      { icon: Users, value: '75+', label: t('stats.components') },
      { icon: Zap, value: '160+', label: t('stats.bugs') },
      { icon: Globe, value: '3', label: t('stats.languages') },
    ];
  
    return (
      <section id="about" className="py-24 relative">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            <div className="grid md:grid-cols-2 gap-12 items-center">
              {/* Text Content */}
              <div className="space-y-6">
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  I&apos;m a frontend engineer passionate about building{' '}
                  <span className="text-day-accent dark:text-night-cyan font-medium">
                    scalable, modern web applications
                  </span>{' '}
                  that deliver exceptional user experiences. With expertise in Angular and a
                  strong foundation in React and TypeScript, I bring ideas to life with clean,
                  maintainable code.
                </p>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  Currently at <span className="font-medium">VERMEG</span>, I lead frontend
                  development for a low-code platform, where I&apos;ve designed a{' '}
                  <span className="text-day-accent dark:text-night-cyan font-medium">
                    reusable component library of 75+ widgets
                  </span>{' '}
                  and mentored junior developers. I&apos;m always exploring new technologies
                  and best practices to level up my craft.
                </p>
                <p className="text-day-text/80 dark:text-night-text/80 leading-relaxed">
                  When I&apos;m not coding, you&apos;ll find me contributing to open-source,
                  exploring AI/ML certifications, or planning my next adventure.
                  I&apos;m open to international relocation and excited about new challenges
                  in dynamic, product-driven teams.
                </p>
  
                {/* Tech Stack Highlight */}
                <div className="pt-4">
                  <p className="text-sm font-mono text-day-comment dark:text-night-comment mb-3">
                    {t('techTitle')}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {['Angular', 'TypeScript', 'RxJS', 'NgRx', 'Tailwind', 'Jest', 'Cypress'].map(
                      (tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 text-sm font-mono bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight rounded-full text-day-accent dark:text-night-cyan"
                        >
                          {tech}
                        </span>
                      )
                    )}
                  </div>
                </div>
              </div>
  
              {/* Image Placeholder & Stats */}
              <div className="space-y-8">
                {/* Profile Image Placeholder */}
                <motion.div
                  className="relative aspect-square max-w-sm mx-auto"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-day-accent/20 to-day-accent-alt/20 dark:from-night-cyan/20 dark:to-night-accent/20 rounded-2xl transform rotate-3" />
                  <div className="relative bg-day-bg-alt dark:bg-night-bg-alt rounded-2xl overflow-hidden border border-day-bg-highlight dark:border-night-bg-highlight">
                    {/* Replace this div with your actual image */}
                    <div className="aspect-square flex items-center justify-center bg-gradient-to-br from-day-accent/10 to-day-accent-alt/10 dark:from-night-cyan/10 dark:to-night-accent/10">
                      <div className="text-center">
                        <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-day-bg-highlight dark:bg-night-bg-highlight flex items-center justify-center">
                          <span className="text-4xl font-bold text-gradient">KK</span>
                        </div>
                        <p className="text-sm text-day-comment dark:text-night-comment font-mono">
                          {/* Your photo here */}
                          {t('imagePlaceholder')}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
  
                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4">
                  {stats.map((stat, index) => (
                    <motion.div
                      key={stat.label}
                      className="bento-card text-center"
                      initial={{ opacity: 0, y: 20 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      whileHover={{ y: -5 }}
                    >
                      <stat.icon className="w-6 h-6 mx-auto mb-2 text-day-accent dark:text-night-cyan" />
                      <div className="text-2xl font-bold text-day-text dark:text-night-text">
                        {stat.value}
                      </div>
                      <div className="text-sm text-day-comment dark:text-night-comment">
                        {stat.label}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `experience.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\experience.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { Briefcase, Calendar, ChevronDown } from 'lucide-react';
  
  interface Experience {
    title: string;
    company: string;
    location: string;
    period: string;
    description: string[];
    technologies?: string[];
  }
  
  const experiences: Experience[] = [
    {
      title: 'Software Engineer ? Frontend (Low-Code Platform)',
      company: 'VERMEG',
      location: 'Tunisia',
      period: 'Jan 2024 ? Present',
      description: [
        'Led code reviews and mentored 2 junior developers, improving code quality and onboarding efficiency.',
        'Designed and developed a reusable Angular component library (75+ widgets), reducing duplication by 35%.',
        'Migrated GitLab CI/CD pipelines to cloud, achieving 65% faster build times and 30% fewer failures.',
        'Contributed to functional design and actively participated in Agile ceremonies.',
      ],
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'GitLab CI/CD', 'Docker'],
    },
    {
      title: 'Frontend Developer ? Financial Products',
      company: 'VERMEG',
      location: 'Tunisia',
      period: 'Oct 2020 ? Jan 2024',
      description: [
        'Fixed 160+ bugs and delivered high-impact features across multiple Angular-based financial apps.',
        'Refactored legacy modules and contributed to Angular version upgrades (v11 to v16).',
        'Achieved 95% test coverage with unit and E2E testing (Jest, Cypress).',
        'Collaborated with UI/UX teams to convert Figma prototypes into scalable, responsive interfaces.',
      ],
      technologies: ['Angular', 'Jest', 'Cypress', 'Figma', 'SASS', 'REST APIs'],
    },
    {
      title: 'Customer Service Representative ? PayPal',
      company: 'TRANSCOM',
      location: 'Tunisia',
      period: 'Oct 2017 ? Apr 2020',
      description: [
        'Handled customer calls and support inquiries in English and French.',
        'Managed PayPal claims, disputes, and technical issues related to e-commerce integrations.',
        'Assisted in onboarding new hires through peer mentoring and training.',
        'Achieved 90%+ in KPIs related to resolution time, empathy, and customer satisfaction.',
      ],
    },
    {
      title: 'Software Developer Intern ? Game Development',
      company: 'Stellar VFX',
      location: 'Tunisia',
      period: 'Feb 2017 ? Jul 2017',
      description: [
        'Built interactive game mechanics and UI with performance optimizations.',
        'Integrated assets and performed functional testing based on gameplay feedback.',
      ],
    },
  ];
  
  function ExperienceCard({ experience, index }: { experience: Experience; index: number }) {
    const [isExpanded, setIsExpanded] = useState(index === 0);
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, x: -50 }}
        animate={isInView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="relative pl-8 pb-8 last:pb-0"
      >
        {/* Timeline Line */}
        <div className="absolute left-0 top-0 bottom-0 w-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
        
        {/* Timeline Dot */}
        <motion.div
          className="absolute left-0 top-0 w-4 h-4 -translate-x-1/2 rounded-full bg-day-accent dark:bg-night-cyan"
          initial={{ scale: 0 }}
          animate={isInView ? { scale: 1 } : {}}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
        >
          <div className="absolute inset-0 rounded-full bg-day-accent dark:bg-night-cyan animate-ping opacity-20" />
        </motion.div>
  
        {/* Card */}
        <motion.div
          className="bento-card cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
          whileHover={{ x: 5 }}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text mb-1">
                {experience.title}
              </h3>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="flex items-center gap-1 text-day-accent dark:text-night-cyan font-medium">
                  <Briefcase className="w-4 h-4" />
                  {experience.company}
                </span>
                <span className="text-day-comment dark:text-night-comment">
                  {experience.location}
                </span>
                <span className="flex items-center gap-1 text-day-comment dark:text-night-comment font-mono text-xs">
                  <Calendar className="w-3 h-3" />
                  {experience.period}
                </span>
              </div>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="text-day-comment dark:text-night-comment"
            >
              <ChevronDown className="w-5 h-5" />
            </motion.div>
          </div>
  
          {/* Expanded Content */}
          <motion.div
            initial={false}
            animate={{
              height: isExpanded ? 'auto' : 0,
              opacity: isExpanded ? 1 : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <ul className="mt-4 space-y-2">
              {experience.description.map((item, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2 text-day-text/80 dark:text-night-text/80 text-sm"
                >
                  <span className="text-day-accent dark:text-night-cyan mt-1">?</span>
                  {item}
                </li>
              ))}
            </ul>
  
            {experience.technologies && (
              <div className="mt-4 flex flex-wrap gap-2">
                {experience.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Experience() {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="experience" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">02.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">Experience</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Timeline */}
            <div className="max-w-3xl">
              {experiences.map((exp, index) => (
                <ExperienceCard key={index} experience={exp} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { Briefcase, Calendar, ChevronDown } from 'lucide-react';
  
  interface ExperienceData {
    key: string;
    technologies?: string[];
  }
  
  const experienceData: ExperienceData[] = [
    {
      key: 'vermeg_lead',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'GitLab CI/CD', 'Docker'],
    },
    {
      key: 'vermeg_dev',
      technologies: ['Angular', 'Jest', 'Cypress', 'Figma', 'SASS', 'REST APIs'],
    },
    {
      key: 'transcom',
    },
    {
      key: 'stellar',
    },
  ];
  
  function ExperienceCard({
    expKey,
    technologies,
    index,
  }: {
    expKey: string;
    technologies?: string[];
    index: number;
  }) {
    const t = useTranslations('experience.jobs');
    const [isExpanded, setIsExpanded] = useState(index === 0);
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
  
    // Get description array from translations
    const descriptionKeys = [0, 1, 2, 3];
    const descriptions: string[] = [];
    descriptionKeys.forEach((i) => {
      try {
        const desc = t(`${expKey}.description.${i}`);
        if (desc && !desc.includes('description')) {
          descriptions.push(desc);
        }
      } catch {
        // Key doesn't exist
      }
    });
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, x: -50 }}
        animate={isInView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="relative pl-8 pb-8 last:pb-0"
      >
        {/* Timeline Line */}
        <div className="absolute left-0 top-0 bottom-0 w-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
        
        {/* Timeline Dot */}
        <motion.div
          className="absolute left-0 top-0 w-4 h-4 -translate-x-1/2 rounded-full bg-day-accent dark:bg-night-cyan"
          initial={{ scale: 0 }}
          animate={isInView ? { scale: 1 } : {}}
          transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
        >
          <div className="absolute inset-0 rounded-full bg-day-accent dark:bg-night-cyan animate-ping opacity-20" />
        </motion.div>
  
        {/* Card */}
        <motion.div
          className="bento-card cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
          whileHover={{ x: 5 }}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text mb-1">
                {t(`${expKey}.title`)}
              </h3>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="flex items-center gap-1 text-day-accent dark:text-night-cyan font-medium">
                  <Briefcase className="w-4 h-4" />
                  {t(`${expKey}.company`)}
                </span>
                <span className="text-day-comment dark:text-night-comment">
                  {t(`${expKey}.location`)}
                </span>
                <span className="flex items-center gap-1 text-day-comment dark:text-night-comment font-mono text-xs">
                  <Calendar className="w-3 h-3" />
                  {t(`${expKey}.period`)}
                </span>
              </div>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="text-day-comment dark:text-night-comment"
            >
              <ChevronDown className="w-5 h-5" />
            </motion.div>
          </div>
  
          {/* Expanded Content */}
          <motion.div
            initial={false}
            animate={{
              height: isExpanded ? 'auto' : 0,
              opacity: isExpanded ? 1 : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <ul className="mt-4 space-y-2">
              {descriptions.map((item, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2 text-day-text/80 dark:text-night-text/80 text-sm"
                >
                  <span className="text-day-accent dark:text-night-cyan mt-1">?</span>
                  {item}
                </li>
              ))}
            </ul>
  
            {technologies && (
              <div className="mt-4 flex flex-wrap gap-2">
                {technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Experience() {
    const t = useTranslations('experience');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="experience" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Timeline */}
            <div className="max-w-3xl">
              {experienceData.map((exp, index) => (
                <ExperienceCard
                  key={exp.key}
                  expKey={exp.key}
                  technologies={exp.technologies}
                  index={index}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `projects.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\projects.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { ExternalLink, Github, Star, Folder } from 'lucide-react';
  
  interface Project {
    title: string;
    description: string;
    image?: string;
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    featured?: boolean;
    period?: string;
  }
  
  const projects: Project[] = [
    {
      title: 'VEGGO ? Low-Code Platform',
      description:
        'Enterprise low-code platform for building financial applications. Led frontend development, designed 75+ reusable Angular widgets, and established component architecture patterns.',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'SASS', 'Storybook'],
      featured: true,
      period: '2024 - Present',
    },
    {
      title: 'E-commerce Store ? Pijiz',
      description:
        'Shopify-based e-commerce platform with custom theme development, multi-language support, payment integration, and SEO optimization.',
      technologies: ['Shopify', 'Liquid', 'JavaScript', 'CSS'],
      liveUrl: 'https://pijiz.com',
      period: 'May 2024',
    },
    {
      title: 'Visit Dubai UI Redesign',
      description:
        'Freelance project to improve the UI/UX of Visit Dubai website. Enhanced page structure, navigation, and implemented responsive design fixes.',
      technologies: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS'],
      period: 'Jan 2024 - Feb 2024',
    },
    {
      title: 'Banking App Migration',
      description:
        'Led the full framework upgrade from Angular v11 to v16 for a banking application. Refactored UI components and migrated custom themes.',
      technologies: ['Angular', 'TypeScript', 'Jest', 'Cypress'],
      period: 'Nov 2023 - Jan 2024',
    },
    {
      title: 'NRG Global Power ? Corporate Website',
      description:
        'Built and deployed a corporate WordPress website with business email setup, SEO optimization, and GoDaddy hosting configuration.',
      technologies: ['WordPress', 'PHP', 'CSS', 'SEO'],
      liveUrl: 'https://nrgglobalpower.us',
      period: 'Oct 2023',
    },
  ];
  
  function ProjectCard({ project, index }: { project: Project; index: number }) {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
    const [isHovered, setIsHovered] = useState(false);
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className={`group ${project.featured ? 'md:col-span-2' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <motion.div
          className="bento-card h-full relative overflow-hidden"
          whileHover={{ y: -5 }}
          style={{
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Featured Badge */}
          {project.featured && (
            <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-day-accent/10 dark:bg-night-cyan/10 rounded-full text-day-accent dark:text-night-cyan text-xs font-mono">
              <Star className="w-3 h-3" />
              Featured
            </div>
          )}
  
          {/* Image Placeholder */}
          <div className="relative mb-4 rounded-lg overflow-hidden bg-day-bg-highlight dark:bg-night-bg-highlight aspect-video">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Folder className="w-12 h-12 mx-auto mb-2 text-day-accent/40 dark:text-night-cyan/40" />
                <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                  {/* Add screenshot here */}
                  screenshot.png
                </p>
              </div>
            </div>
            
            {/* Hover Overlay */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-t from-day-accent/80 dark:from-night-cyan/80 to-transparent flex items-end justify-center p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex gap-3">
                {project.liveUrl && (
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View live site"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </a>
                )}
                {project.githubUrl && (
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View source code"
                  >
                    <Github className="w-5 h-5" />
                  </a>
                )}
              </div>
            </motion.div>
          </div>
  
          {/* Content */}
          <div>
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors">
                {project.title}
              </h3>
              {project.period && (
                <span className="text-xs font-mono text-day-comment dark:text-night-comment whitespace-nowrap">
                  {project.period}
                </span>
              )}
            </div>
            
            <p className="text-sm text-day-text/70 dark:text-night-text/70 mb-4 leading-relaxed">
              {project.description}
            </p>
  
            {/* Technologies */}
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
  
          {/* Links for non-hovered state */}
          <div className="mt-4 flex gap-4">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <ExternalLink className="w-4 h-4" />
                Live
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <Github className="w-4 h-4" />
                Code
              </a>
            )}
          </div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Projects() {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="projects" className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">03.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">Projects</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {projects.map((project, index) => (
                <ProjectCard key={project.title} project={project} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { ExternalLink, Github, Star, Folder } from 'lucide-react';
  
  interface ProjectData {
    key: string;
    technologies: string[];
    liveUrl?: string;
    githubUrl?: string;
    featured?: boolean;
  }
  
  const projectsData: ProjectData[] = [
    {
      key: 'veggo',
      technologies: ['Angular', 'TypeScript', 'RxJS', 'NgRx', 'SASS', 'Storybook'],
      featured: true,
    },
    {
      key: 'pijiz',
      technologies: ['Shopify', 'Liquid', 'JavaScript', 'CSS'],
      liveUrl: 'https://pijiz.com',
    },
    {
      key: 'dubai',
      technologies: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS'],
    },
    {
      key: 'banking',
      technologies: ['Angular', 'TypeScript', 'Jest', 'Cypress'],
    },
    {
      key: 'nrg',
      technologies: ['WordPress', 'PHP', 'CSS', 'SEO'],
      liveUrl: 'https://nrgglobalpower.us',
    },
  ];
  
  function ProjectCard({ project, index }: { project: ProjectData; index: number }) {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
    const [isHovered, setIsHovered] = useState(false);
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 50 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className={`group ${project.featured ? 'md:col-span-2' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <motion.div
          className="bento-card h-full relative overflow-hidden"
          whileHover={{ y: -5 }}
          style={{
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Featured Badge */}
          {project.featured && (
            <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-day-accent/10 dark:bg-night-cyan/10 rounded-full text-day-accent dark:text-night-cyan text-xs font-mono">
              <Star className="w-3 h-3" />
              {t('featured')}
            </div>
          )}
  
          {/* Image Placeholder */}
          <div className="relative mb-4 rounded-lg overflow-hidden bg-day-bg-highlight dark:bg-night-bg-highlight aspect-video">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Folder className="w-12 h-12 mx-auto mb-2 text-day-accent/40 dark:text-night-cyan/40" />
                <p className="text-xs text-day-comment dark:text-night-comment font-mono">
                  {t('screenshotPlaceholder')}
                </p>
              </div>
            </div>
            
            {/* Hover Overlay */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-t from-day-accent/80 dark:from-night-cyan/80 to-transparent flex items-end justify-center p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex gap-3">
                {project.liveUrl && (
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View live site"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </a>
                )}
                {project.githubUrl && (
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center text-day-accent hover:bg-white transition-colors"
                    aria-label="View source code"
                  >
                    <Github className="w-5 h-5" />
                  </a>
                )}
              </div>
            </motion.div>
          </div>
  
          {/* Content */}
          <div>
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="text-lg font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors">
                {t(`items.${project.key}.title`)}
              </h3>
              <span className="text-xs font-mono text-day-comment dark:text-night-comment whitespace-nowrap">
                {t(`items.${project.key}.period`)}
              </span>
            </div>
            
            <p className="text-sm text-day-text/70 dark:text-night-text/70 mb-4 leading-relaxed">
              {t(`items.${project.key}.description`)}
            </p>
  
            {/* Technologies */}
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-muted dark:text-night-muted"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
  
          {/* Links for non-hovered state */}
          <div className="mt-4 flex gap-4">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <ExternalLink className="w-4 h-4" />
                {t('viewLive')}
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-day-accent dark:text-night-cyan hover:underline"
              >
                <Github className="w-4 h-4" />
                {t('viewCode')}
              </a>
            )}
          </div>
        </motion.div>
      </motion.div>
    );
  }
  
  export function Projects() {
    const t = useTranslations('projects');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="projects" className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {projectsData.map((project, index) => (
                <ProjectCard key={project.key} project={project} index={index} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `skills.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\skills.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion, useInView } from 'framer-motion';
  import { useRef } from 'react';
  import {
    Code2,
    Server,
    TestTube,
    GitBranch,
    Palette,
    Shield,
    Languages,
    Brain,
  } from 'lucide-react';
  
  interface SkillCategory {
    icon: typeof Code2;
    title: string;
    skills: string[];
    color: string;
  }
  
  const skillCategories: SkillCategory[] = [
    {
      icon: Code2,
      title: 'Frontend',
      skills: [
        'Angular',
        'TypeScript',
        'JavaScript (ES6+)',
        'RxJS',
        'NgRx',
        'React',
        'Next.js',
        'HTML5',
        'CSS3',
        'SASS',
        'Tailwind',
        'Bootstrap',
        'PrimeNG',
        'Angular Material',
      ],
      color: 'cyan',
    },
    {
      icon: Server,
      title: 'Backend & APIs',
      skills: ['Java', 'Spring Boot', 'NestJS', 'ExpressJS', 'SQL', 'REST APIs', 'RabbitMQ'],
      color: 'accent',
    },
    {
      icon: TestTube,
      title: 'Testing',
      skills: ['Jest', 'Cypress', 'Storybook', 'ESLint', 'JUnit', 'Postman'],
      color: 'green',
    },
    {
      icon: GitBranch,
      title: 'DevOps & CI/CD',
      skills: ['Git', 'GitLab CI/CD', 'Docker', 'Nexus', 'Vercel', 'GoDaddy', 'OVH'],
      color: 'orange',
    },
    {
      icon: Palette,
      title: 'Design & UX',
      skills: ['Figma', 'Adobe Photoshop', 'Sketch'],
      color: 'pink',
    },
    {
      icon: Shield,
      title: 'Security',
      skills: ['Keycloak', 'JWT'],
      color: 'yellow',
    },
  ];
  
  const softSkills = [
    'Problem-solving',
    'Adaptability',
    'Team collaboration',
    'Communication',
    'Creativity',
    'Decision-making',
    'Mentoring',
  ];
  
  const languages = [
    { name: 'Arabic', level: 'Native', percentage: 100 },
    { name: 'English', level: 'Fluent (B2)', percentage: 80 },
    { name: 'French', level: 'Fluent (B2)', percentage: 80 },
  ];
  
  function SkillCard({
    category,
    index,
  }: {
    category: SkillCategory;
    index: number;
  }) {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
  
    const colorClasses: Record<string, string> = {
      cyan: 'text-day-cyan dark:text-night-cyan bg-day-cyan/10 dark:bg-night-cyan/10 border-day-cyan/20 dark:border-night-cyan/20',
      accent:
        'text-day-accent dark:text-night-accent bg-day-accent/10 dark:bg-night-accent/10 border-day-accent/20 dark:border-night-accent/20',
      green:
        'text-day-green dark:text-night-green bg-day-green/10 dark:bg-night-green/10 border-day-green/20 dark:border-night-green/20',
      orange:
        'text-day-orange dark:text-night-orange bg-day-orange/10 dark:bg-night-orange/10 border-day-orange/20 dark:border-night-orange/20',
      pink: 'text-day-pink dark:text-night-pink bg-day-pink/10 dark:bg-night-pink/10 border-day-pink/20 dark:border-night-pink/20',
      yellow:
        'text-day-yellow dark:text-night-yellow bg-day-yellow/10 dark:bg-night-yellow/10 border-day-yellow/20 dark:border-night-yellow/20',
    };
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="bento-card group"
        whileHover={{ y: -5 }}
      >
        <div
          className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colorClasses[category.color]}`}
        >
          <category.icon className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-day-text dark:text-night-text mb-3">
          {category.title}
        </h3>
        <div className="flex flex-wrap gap-2">
          {category.skills.map((skill) => (
            <span
              key={skill}
              className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-text/70 dark:text-night-text/70 transition-colors group-hover:text-day-accent dark:group-hover:text-night-cyan"
            >
              {skill}
            </span>
          ))}
        </div>
      </motion.div>
    );
  }
  
  export function Skills() {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="skills" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">04.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">Skills</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Technical Skills Grid */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {skillCategories.map((category, index) => (
                <SkillCard key={category.title} category={category} index={index} />
              ))}
            </div>
  
            {/* Bottom Row: Soft Skills + Languages */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Soft Skills */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.6 }}
                className="bento-card"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Brain className="w-6 h-6 text-day-accent-alt dark:text-night-accent" />
                  <h3 className="text-lg font-bold text-day-text dark:text-night-text">
                    Soft Skills
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {softSkills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1.5 text-sm bg-day-accent-alt/10 dark:bg-night-accent/10 border border-day-accent-alt/20 dark:border-night-accent/20 rounded-full text-day-accent-alt dark:text-night-accent"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.div>
  
              {/* Languages */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.7 }}
                className="bento-card"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Languages className="w-6 h-6 text-day-accent dark:text-night-cyan" />
                  <h3 className="text-lg font-bold text-day-text dark:text-night-text">
                    Languages
                  </h3>
                </div>
                <div className="space-y-4">
                  {languages.map((lang) => (
                    <div key={lang.name}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-day-text dark:text-night-text">
                          {lang.name}
                        </span>
                        <span className="text-xs text-day-comment dark:text-night-comment">
                          {lang.level}
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-day-bg-highlight dark:bg-night-bg-highlight overflow-hidden">
                        <motion.div
                          className="h-full rounded-full bg-gradient-to-r from-day-accent to-day-cyan dark:from-night-cyan dark:to-night-accent"
                          initial={{ width: 0 }}
                          animate={isInView ? { width: `${lang.percentage}%` } : {}}
                          transition={{ duration: 0.8, delay: 0.8 }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef } from 'react';
  import {
    Code2,
    Server,
    TestTube,
    GitBranch,
    Palette,
    Shield,
    Languages,
    Brain,
  } from 'lucide-react';
  
  interface SkillCategory {
    icon: typeof Code2;
    key: string;
    skills: string[];
    color: string;
  }
  
  const skillCategories: SkillCategory[] = [
    {
      icon: Code2,
      key: 'frontend',
      skills: [
        'Angular',
        'TypeScript',
        'JavaScript (ES6+)',
        'RxJS',
        'NgRx',
        'React',
        'Next.js',
        'HTML5',
        'CSS3',
        'SASS',
        'Tailwind',
        'Bootstrap',
        'PrimeNG',
        'Angular Material',
      ],
      color: 'cyan',
    },
    {
      icon: Server,
      key: 'backend',
      skills: ['Java', 'Spring Boot', 'NestJS', 'ExpressJS', 'SQL', 'REST APIs', 'RabbitMQ'],
      color: 'accent',
    },
    {
      icon: TestTube,
      key: 'testing',
      skills: ['Jest', 'Cypress', 'Storybook', 'ESLint', 'JUnit', 'Postman'],
      color: 'green',
    },
    {
      icon: GitBranch,
      key: 'devops',
      skills: ['Git', 'GitLab CI/CD', 'Docker', 'Nexus', 'Vercel', 'GoDaddy', 'OVH'],
      color: 'orange',
    },
    {
      icon: Palette,
      key: 'design',
      skills: ['Figma', 'Adobe Photoshop', 'Sketch'],
      color: 'pink',
    },
    {
      icon: Shield,
      key: 'security',
      skills: ['Keycloak', 'JWT'],
      color: 'yellow',
    },
  ];
  
  function SkillCard({
    category,
    index,
  }: {
    category: SkillCategory;
    index: number;
  }) {
    const t = useTranslations('skills');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-50px' });
  
    const colorClasses: Record<string, string> = {
      cyan: 'text-day-cyan dark:text-night-cyan bg-day-cyan/10 dark:bg-night-cyan/10 border-day-cyan/20 dark:border-night-cyan/20',
      accent:
        'text-day-accent dark:text-night-accent bg-day-accent/10 dark:bg-night-accent/10 border-day-accent/20 dark:border-night-accent/20',
      green:
        'text-day-green dark:text-night-green bg-day-green/10 dark:bg-night-green/10 border-day-green/20 dark:border-night-green/20',
      orange:
        'text-day-orange dark:text-night-orange bg-day-orange/10 dark:bg-night-orange/10 border-day-orange/20 dark:border-night-orange/20',
      pink: 'text-day-pink dark:text-night-pink bg-day-pink/10 dark:bg-night-pink/10 border-day-pink/20 dark:border-night-pink/20',
      yellow:
        'text-day-yellow dark:text-night-yellow bg-day-yellow/10 dark:bg-night-yellow/10 border-day-yellow/20 dark:border-night-yellow/20',
    };
  
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="bento-card group"
        whileHover={{ y: -5 }}
      >
        <div
          className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colorClasses[category.color]}`}
        >
          <category.icon className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-day-text dark:text-night-text mb-3">
          {t(`categories.${category.key}`)}
        </h3>
        <div className="flex flex-wrap gap-2">
          {category.skills.map((skill) => (
            <span
              key={skill}
              className="px-2 py-1 text-xs font-mono bg-day-bg dark:bg-night-bg rounded text-day-text/70 dark:text-night-text/70 transition-colors group-hover:text-day-accent dark:group-hover:text-night-cyan"
            >
              {skill}
            </span>
          ))}
        </div>
      </motion.div>
    );
  }
  
  export function Skills() {
    const t = useTranslations('skills');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    const languages = [
      { key: 'arabic', percentage: 100 },
      { key: 'english', percentage: 80 },
      { key: 'french', percentage: 80 },
    ];
  
    return (
      <section id="skills" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            {/* Technical Skills Grid */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {skillCategories.map((category, index) => (
                <SkillCard key={category.key} category={category} index={index} />
              ))}
            </div>
  
            {/* Bottom Row: Soft Skills + Languages */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Soft Skills */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.6 }}
                className="bento-card"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Brain className="w-6 h-6 text-day-accent-alt dark:text-night-accent" />
                  <h3 className="text-lg font-bold text-day-text dark:text-night-text">
                    {t('softSkills.title')}
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {[0, 1, 2, 3, 4, 5, 6].map((i) => {
                    try {
                      const skill = t(`softSkills.items.${i}`);
                      if (skill && !skill.includes('items')) {
                        return (
                          <span
                            key={i}
                            className="px-3 py-1.5 text-sm bg-day-accent-alt/10 dark:bg-night-accent/10 border border-day-accent-alt/20 dark:border-night-accent/20 rounded-full text-day-accent-alt dark:text-night-accent"
                          >
                            {skill}
                          </span>
                        );
                      }
                      return null;
                    } catch {
                      return null;
                    }
                  })}
                </div>
              </motion.div>
  
              {/* Languages */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.7 }}
                className="bento-card"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Languages className="w-6 h-6 text-day-accent dark:text-night-cyan" />
                  <h3 className="text-lg font-bold text-day-text dark:text-night-text">
                    {t('languages.title')}
                  </h3>
                </div>
                <div className="space-y-4">
                  {languages.map((lang) => (
                    <div key={lang.key}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-day-text dark:text-night-text">
                          {t(`languages.${lang.key}`)}
                        </span>
                        <span className="text-xs text-day-comment dark:text-night-comment">
                          {t(`languages.${lang.key}Level`)}
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-day-bg-highlight dark:bg-night-bg-highlight overflow-hidden">
                        <motion.div
                          className="h-full rounded-full bg-gradient-to-r from-day-accent to-day-cyan dark:from-night-cyan dark:to-night-accent"
                          initial={{ width: 0 }}
                          animate={isInView ? { width: `${lang.percentage}%` } : {}}
                          transition={{ duration: 0.8, delay: 0.8 }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `certifications.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\certifications.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion, useInView } from 'framer-motion';
  import { useRef } from 'react';
  import { Award, ExternalLink, Calendar } from 'lucide-react';
  
  interface Certification {
    title: string;
    issuer: string;
    date: string;
    credentialId: string;
    icon: string;
  }
  
  const certifications: Certification[] = [
    {
      title: 'Oracle Cloud Infrastructure Generative AI Professional',
      issuer: 'Oracle',
      date: 'October 2025',
      credentialId: '101878709OCI25GAIOCP',
      icon: '??',
    },
    {
      title: 'Oracle Cloud Infrastructure Certified AI Foundations Associate',
      issuer: 'Oracle',
      date: 'October 2025',
      credentialId: '101878709OCI25AICFA',
      icon: '??',
    },
    {
      title: 'Oracle Certified Professional: Java SE 11 Developer',
      issuer: 'Oracle',
      date: 'July 2025',
      credentialId: '101878709OCPJSE11',
      icon: '?',
    },
  ];
  
  const education = [
    {
      degree: 'Engineering Degree ? Software Engineering',
      institution: 'ESPRIT University',
      location: 'Tunisia',
      year: '2024',
    },
    {
      degree: "Bachelor's Degree in Computer Science",
      institution: 'Higher Institute of Multimedia Arts',
      location: 'Tunisia',
      year: '2017',
    },
  ];
  
  export function Certifications() {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">05.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">Certifications & Education</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Certifications */}
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <Award className="w-5 h-5 text-day-accent dark:text-night-cyan" />
                  <h3 className="text-xl font-bold">Certifications</h3>
                </div>
                <div className="space-y-4">
                  {certifications.map((cert, index) => (
                    <motion.div
                      key={cert.credentialId}
                      initial={{ opacity: 0, x: -30 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="bento-card group"
                      whileHover={{ x: 5 }}
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-day-accent/10 dark:bg-night-cyan/10 flex items-center justify-center text-2xl flex-shrink-0">
                          {cert.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors text-sm sm:text-base">
                            {cert.title}
                          </h4>
                          <p className="text-sm text-day-accent dark:text-night-cyan font-medium mt-1">
                            {cert.issuer}
                          </p>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-xs text-day-comment dark:text-night-comment">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {cert.date}
                            </span>
                            <span className="font-mono">ID: {cert.credentialId}</span>
                          </div>
                        </div>
                        <ExternalLink className="w-4 h-4 text-day-comment dark:text-night-comment opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
  
              {/* Education */}
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <svg
                    className="w-5 h-5 text-day-accent dark:text-night-cyan"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 14l9-5-9-5-9 5 9 5z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222"
                    />
                  </svg>
                  <h3 className="text-xl font-bold">Education</h3>
                </div>
                <div className="space-y-4">
                  {education.map((edu, index) => (
                    <motion.div
                      key={edu.degree}
                      initial={{ opacity: 0, x: 30 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                      className="bento-card"
                      whileHover={{ x: -5 }}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h4 className="font-bold text-day-text dark:text-night-text">
                            {edu.degree}
                          </h4>
                          <p className="text-sm text-day-accent dark:text-night-cyan font-medium mt-1">
                            {edu.institution}
                          </p>
                          <p className="text-xs text-day-comment dark:text-night-comment mt-1">
                            {edu.location}
                          </p>
                        </div>
                        <span className="px-3 py-1 bg-day-bg dark:bg-night-bg rounded-full text-sm font-mono text-day-accent dark:text-night-cyan">
                          {edu.year}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef } from 'react';
  import { Award, ExternalLink, Calendar } from 'lucide-react';
  
  interface CertificationData {
    key: string;
    credentialId: string;
    icon: string;
  }
  
  interface EducationData {
    key: string;
  }
  
  const certificationsData: CertificationData[] = [
    {
      key: 'genai',
      credentialId: '101878709OCI25GAIOCP',
      icon: '??',
    },
    {
      key: 'aifoundations',
      credentialId: '101878709OCI25AICFA',
      icon: '??',
    },
    {
      key: 'java',
      credentialId: '101878709OCPJSE11',
      icon: '?',
    },
  ];
  
  const educationData: EducationData[] = [
    { key: 'esprit' },
    { key: 'isamm' },
  ];
  
  export function Certifications() {
    const t = useTranslations('certifications');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section className="py-24">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Certifications */}
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <Award className="w-5 h-5 text-day-accent dark:text-night-cyan" />
                  <h3 className="text-xl font-bold">{t('certificationsTitle')}</h3>
                </div>
                <div className="space-y-4">
                  {certificationsData.map((cert, index) => (
                    <motion.div
                      key={cert.credentialId}
                      initial={{ opacity: 0, x: -30 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="bento-card group"
                      whileHover={{ x: 5 }}
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-day-accent/10 dark:bg-night-cyan/10 flex items-center justify-center text-2xl flex-shrink-0">
                          {cert.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors text-sm sm:text-base">
                            {t(`items.${cert.key}.title`)}
                          </h4>
                          <p className="text-sm text-day-accent dark:text-night-cyan font-medium mt-1">
                            {t(`items.${cert.key}.issuer`)}
                          </p>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-xs text-day-comment dark:text-night-comment">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {t(`items.${cert.key}.date`)}
                            </span>
                            <span className="font-mono">ID: {cert.credentialId}</span>
                          </div>
                        </div>
                        <ExternalLink className="w-4 h-4 text-day-comment dark:text-night-comment opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
  
              {/* Education */}
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <svg
                    className="w-5 h-5 text-day-accent dark:text-night-cyan"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 14l9-5-9-5-9 5 9 5z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222"
                    />
                  </svg>
                  <h3 className="text-xl font-bold">{t('educationTitle')}</h3>
                </div>
                <div className="space-y-4">
                  {educationData.map((edu, index) => (
                    <motion.div
                      key={edu.key}
                      initial={{ opacity: 0, x: 30 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                      className="bento-card"
                      whileHover={{ x: -5 }}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h4 className="font-bold text-day-text dark:text-night-text">
                            {t(`education.${edu.key}.degree`)}
                          </h4>
                          <p className="text-sm text-day-accent dark:text-night-cyan font-medium mt-1">
                            {t(`education.${edu.key}.institution`)}
                          </p>
                          <p className="text-xs text-day-comment dark:text-night-comment mt-1">
                            {t(`education.${edu.key}.location`)}
                          </p>
                        </div>
                        <span className="px-3 py-1 bg-day-bg dark:bg-night-bg rounded-full text-sm font-mono text-day-accent dark:text-night-cyan">
                          {t(`education.${edu.key}.year`)}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `contact.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\contact.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { Mail, Phone, MapPin, Linkedin, Github, Send, Copy, Check } from 'lucide-react';
  
  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'khalilkhaled1995@gmail.com',
      href: 'mailto:khalilkhaled1995@gmail.com',
      copyable: true,
    },
    {
      icon: Phone,
      label: 'Phone',
      value: '+216 20233656',
      href: 'tel:+21620233656',
      copyable: true,
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'Tunis, Tunisia',
      href: 'https://maps.google.com/?q=Tunis,Tunisia',
      copyable: false,
    },
  ];
  
  const socialLinks = [
    {
      icon: Linkedin,
      label: 'LinkedIn',
      href: 'https://linkedin.com/in/khalil-khaled',
      username: 'khalil-khaled',
    },
    {
      icon: Github,
      label: 'GitHub',
      href: 'https://github.com/Khalil-Khaled',
      username: 'Khalil-Khaled',
    },
  ];
  
  function CopyButton({ text }: { text: string }) {
    const [copied, setCopied] = useState(false);
  
    const handleCopy = async () => {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };
  
    return (
      <motion.button
        onClick={handleCopy}
        className="p-2 rounded-lg bg-day-bg dark:bg-night-bg hover:bg-day-accent/10 dark:hover:bg-night-cyan/10 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label={copied ? 'Copied!' : 'Copy to clipboard'}
      >
        {copied ? (
          <Check className="w-4 h-4 text-day-green dark:text-night-green" />
        ) : (
          <Copy className="w-4 h-4 text-day-comment dark:text-night-comment" />
        )}
      </motion.button>
    );
  }
  
  export function Contact() {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    return (
      <section id="contact" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">06.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">Get in Touch</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            <div className="max-w-4xl mx-auto">
              {/* Intro Text */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-center mb-12"
              >
                <h3 className="text-2xl sm:text-3xl font-bold text-day-text dark:text-night-text mb-4">
                  Let&apos;s Work Together
                </h3>
                <p className="text-day-text/70 dark:text-night-text/70 max-w-2xl mx-auto">
                  I&apos;m currently open to new opportunities and exciting projects.
                  Whether you have a question, want to discuss a potential collaboration,
                  or just want to say hi, my inbox is always open!
                </p>
              </motion.div>
  
              <div className="grid md:grid-cols-2 gap-8">
                {/* Contact Info Cards */}
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="space-y-4"
                >
                  {contactInfo.map((info, index) => (
                    <motion.div
                      key={info.label}
                      className="bento-card group"
                      initial={{ opacity: 0, y: 20 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                      whileHover={{ x: 5 }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-day-accent/10 dark:bg-night-cyan/10 flex items-center justify-center flex-shrink-0">
                          <info.icon className="w-5 h-5 text-day-accent dark:text-night-cyan" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-day-comment dark:text-night-comment font-mono mb-1">
                            {info.label}
                          </p>
                          <a
                            href={info.href}
                            target={info.href.startsWith('http') ? '_blank' : undefined}
                            rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                            className="font-medium text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors truncate block"
                          >
                            {info.value}
                          </a>
                        </div>
                        {info.copyable && <CopyButton text={info.value} />}
                      </div>
                    </motion.div>
                  ))}
  
                  {/* Social Links */}
                  <div className="pt-4">
                    <p className="text-sm font-mono text-day-comment dark:text-night-comment mb-3">
                      Find me online:
                    </p>
                    <div className="flex gap-4">
                      {socialLinks.map((social) => (
                        <motion.a
                          key={social.label}
                          href={social.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-day-bg dark:bg-night-bg border border-day-bg-highlight dark:border-night-bg-highlight hover:border-day-accent dark:hover:border-night-cyan transition-colors"
                          whileHover={{ y: -3 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <social.icon className="w-5 h-5" />
                          <span className="text-sm font-medium">{social.label}</span>
                        </motion.a>
                      ))}
                    </div>
                  </div>
                </motion.div>
  
                {/* CTA Card */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 }}
                  className="bento-card flex flex-col justify-center text-center"
                >
                  <div className="mb-6">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-day-accent to-day-accent-alt dark:from-night-cyan dark:to-night-accent p-0.5">
                      <div className="w-full h-full rounded-full bg-day-bg-alt dark:bg-night-bg-alt flex items-center justify-center">
                        <Send className="w-6 h-6 text-day-accent dark:text-night-cyan" />
                      </div>
                    </div>
                    <h4 className="text-xl font-bold text-day-text dark:text-night-text mb-2">
                      Ready to Chat?
                    </h4>
                    <p className="text-sm text-day-text/70 dark:text-night-text/70">
                      I typically respond within 24 hours.
                      Looking forward to hearing from you!
                    </p>
                  </div>
  
                  <motion.a
                    href="mailto:khalilkhaled1995@gmail.com"
                    className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium transition-all hover:shadow-xl hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25"
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Mail className="w-5 h-5" />
                    Send Email
                  </motion.a>
  
                  <p className="mt-4 text-xs text-day-comment dark:text-night-comment">
                    Or reach out on{' '}
                    <a
                      href="https://linkedin.com/in/khalil-khaled"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-day-accent dark:text-night-cyan hover:underline"
                    >
                      LinkedIn
                    </a>
                  </p>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion, useInView } from 'framer-motion';
  import { useRef, useState } from 'react';
  import { Mail, Phone, MapPin, Linkedin, Github, Send, Copy, Check } from 'lucide-react';
  
  function CopyButton({ text }: { text: string }) {
    const [copied, setCopied] = useState(false);
  
    const handleCopy = async () => {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };
  
    return (
      <motion.button
        onClick={handleCopy}
        className="p-2 rounded-lg bg-day-bg dark:bg-night-bg hover:bg-day-accent/10 dark:hover:bg-night-cyan/10 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label={copied ? 'Copied!' : 'Copy to clipboard'}
      >
        {copied ? (
          <Check className="w-4 h-4 text-day-green dark:text-night-green" />
        ) : (
          <Copy className="w-4 h-4 text-day-comment dark:text-night-comment" />
        )}
      </motion.button>
    );
  }
  
  export function Contact() {
    const t = useTranslations('contact');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-100px' });
  
    const contactInfo = [
      {
        icon: Mail,
        labelKey: 'email',
        value: 'khalilkhaled1995@gmail.com',
        href: 'mailto:khalilkhaled1995@gmail.com',
        copyable: true,
      },
      {
        icon: Phone,
        labelKey: 'phone',
        value: '+216 20233656',
        href: 'tel:+21620233656',
        copyable: true,
      },
      {
        icon: MapPin,
        labelKey: 'location',
        value: 'Tunis, Tunisia',
        href: 'https://maps.google.com/?q=Tunis,Tunisia',
        copyable: false,
      },
    ];
  
    const socialLinks = [
      {
        icon: Linkedin,
        label: 'LinkedIn',
        href: 'https://linkedin.com/in/khalil-khaled',
      },
      {
        icon: Github,
        label: 'GitHub',
        href: 'https://github.com/Khalil-Khaled',
      },
    ];
  
    return (
      <section id="contact" className="py-24 bg-day-bg-alt/50 dark:bg-night-bg-alt/50">
        <div className="section-container">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Section Header */}
            <div className="flex items-center gap-4 mb-12">
              <span className="text-day-accent dark:text-night-cyan font-mono">{t('sectionNumber')}.</span>
              <h2 className="text-3xl sm:text-4xl font-bold">{t('title')}</h2>
              <div className="flex-1 h-px bg-day-bg-highlight dark:bg-night-bg-highlight" />
            </div>
  
            <div className="max-w-4xl mx-auto">
              {/* Intro Text */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-center mb-12"
              >
                <h3 className="text-2xl sm:text-3xl font-bold text-day-text dark:text-night-text mb-4">
                  {t('subtitle')}
                </h3>
                <p className="text-day-text/70 dark:text-night-text/70 max-w-2xl mx-auto">
                  {t('description')}
                </p>
              </motion.div>
  
              <div className="grid md:grid-cols-2 gap-8">
                {/* Contact Info Cards */}
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="space-y-4"
                >
                  {contactInfo.map((info, index) => (
                    <motion.div
                      key={info.labelKey}
                      className="bento-card group"
                      initial={{ opacity: 0, y: 20 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                      whileHover={{ x: 5 }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-day-accent/10 dark:bg-night-cyan/10 flex items-center justify-center flex-shrink-0">
                          <info.icon className="w-5 h-5 text-day-accent dark:text-night-cyan" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-day-comment dark:text-night-comment font-mono mb-1">
                            {t(info.labelKey)}
                          </p>
                          <a
                            href={info.href}
                            target={info.href.startsWith('http') ? '_blank' : undefined}
                            rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                            className="font-medium text-day-text dark:text-night-text group-hover:text-day-accent dark:group-hover:text-night-cyan transition-colors truncate block"
                          >
                            {info.value}
                          </a>
                        </div>
                        {info.copyable && <CopyButton text={info.value} />}
                      </div>
                    </motion.div>
                  ))}
  
                  {/* Social Links */}
                  <div className="pt-4">
                    <p className="text-sm font-mono text-day-comment dark:text-night-comment mb-3">
                      {t('findOnline')}
                    </p>
                    <div className="flex gap-4">
                      {socialLinks.map((social) => (
                        <motion.a
                          key={social.label}
                          href={social.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-day-bg dark:bg-night-bg border border-day-bg-highlight dark:border-night-bg-highlight hover:border-day-accent dark:hover:border-night-cyan transition-colors"
                          whileHover={{ y: -3 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <social.icon className="w-5 h-5" />
                          <span className="text-sm font-medium">{social.label}</span>
                        </motion.a>
                      ))}
                    </div>
                  </div>
                </motion.div>
  
                {/* CTA Card */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 }}
                  className="bento-card flex flex-col justify-center text-center"
                >
                  <div className="mb-6">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-day-accent to-day-accent-alt dark:from-night-cyan dark:to-night-accent p-0.5">
                      <div className="w-full h-full rounded-full bg-day-bg-alt dark:bg-night-bg-alt flex items-center justify-center">
                        <Send className="w-6 h-6 text-day-accent dark:text-night-cyan" />
                      </div>
                    </div>
                    <h4 className="text-xl font-bold text-day-text dark:text-night-text mb-2">
                      {t('readyTitle')}
                    </h4>
                    <p className="text-sm text-day-text/70 dark:text-night-text/70">
                      {t('readyDescription')}
                    </p>
                  </div>
  
                  <motion.a
                    href="mailto:khalilkhaled1995@gmail.com"
                    className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-full bg-day-accent dark:bg-night-cyan text-white dark:text-night-bg font-medium transition-all hover:shadow-xl hover:shadow-day-accent/25 dark:hover:shadow-night-cyan/25"
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Mail className="w-5 h-5" />
                    {t('sendEmail')}
                  </motion.a>
  
                  <p className="mt-4 text-xs text-day-comment dark:text-night-comment">
                    {t('orReachOut')}{' '}
                    <a
                      href="https://linkedin.com/in/khalil-khaled"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-day-accent dark:text-night-cyan hover:underline"
                    >
                      LinkedIn
                    </a>
                  </p>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
  
  ```

  #### ✏️ `footer.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\footer.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { motion } from 'framer-motion';
  import { Heart, Github, Linkedin, Mail } from 'lucide-react';
  
  export function Footer() {
    const currentYear = new Date().getFullYear();
  
    return (
      <footer className="py-8 border-t border-day-bg-highlight dark:border-night-bg-highlight">
        <div className="section-container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Logo & Copyright */}
            <div className="flex flex-col sm:flex-row items-center gap-2 text-sm text-day-comment dark:text-night-comment">
              <motion.a
                href="#"
                className="text-lg font-bold font-mono"
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-day-accent dark:text-night-cyan">{'<'}</span>
                <span className="text-day-text dark:text-night-text">KK</span>
                <span className="text-day-accent dark:text-night-cyan">{'/>'}</span>
              </motion.a>
              <span className="hidden sm:inline">?</span>
              <span>
                ? {currentYear} Khalil Khaled. All rights reserved.
              </span>
            </div>
  
            {/* Social Links */}
            <div className="flex items-center gap-4">
              {[
                { icon: Github, href: 'https://github.com/Khalil-Khaled', label: 'GitHub' },
                { icon: Linkedin, href: 'https://linkedin.com/in/khalil-khaled', label: 'LinkedIn' },
                { icon: Mail, href: 'mailto:khalilkhaled1995@gmail.com', label: 'Email' },
              ].map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  target={social.href.startsWith('http') ? '_blank' : undefined}
                  rel={social.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="w-10 h-10 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight flex items-center justify-center text-day-comment dark:text-night-comment hover:text-day-accent dark:hover:text-night-cyan hover:border-day-accent dark:hover:border-night-cyan transition-all"
                  whileHover={{ y: -3 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4" />
                </motion.a>
              ))}
            </div>
          </div>
  
          {/* Built with */}
          <motion.div
            className="mt-6 text-center text-xs text-day-comment dark:text-night-comment"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <span>Built with </span>
            <Heart className="w-3 h-3 inline text-day-red dark:text-night-red" />
            <span> using </span>
            <span className="text-day-accent dark:text-night-cyan">Next.js</span>
            <span>, </span>
            <span className="text-day-accent dark:text-night-cyan">Tailwind CSS</span>
            <span> & </span>
            <span className="text-day-accent dark:text-night-cyan">Framer Motion</span>
          </motion.div>
        </div>
      </footer>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTranslations } from 'next-intl';
  import { motion } from 'framer-motion';
  import { Heart, Github, Linkedin, Mail } from 'lucide-react';
  
  export function Footer() {
    const t = useTranslations('footer');
    const currentYear = new Date().getFullYear();
  
    return (
      <footer className="py-8 border-t border-day-bg-highlight dark:border-night-bg-highlight">
        <div className="section-container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Logo & Copyright */}
            <div className="flex flex-col sm:flex-row items-center gap-2 text-sm text-day-comment dark:text-night-comment">
              <motion.a
                href="#"
                className="text-lg font-bold font-mono"
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-day-accent dark:text-night-cyan">{'<'}</span>
                <span className="text-day-text dark:text-night-text">KK</span>
                <span className="text-day-accent dark:text-night-cyan">{'/>'}</span>
              </motion.a>
              <span className="hidden sm:inline">?</span>
              <span>{t('copyright', { year: currentYear })}</span>
            </div>
  
            {/* Social Links */}
            <div className="flex items-center gap-4">
              {[
                { icon: Github, href: 'https://github.com/Khalil-Khaled', label: 'GitHub' },
                { icon: Linkedin, href: 'https://linkedin.com/in/khalil-khaled', label: 'LinkedIn' },
                { icon: Mail, href: 'mailto:khalilkhaled1995@gmail.com', label: 'Email' },
              ].map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  target={social.href.startsWith('http') ? '_blank' : undefined}
                  rel={social.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="w-10 h-10 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight flex items-center justify-center text-day-comment dark:text-night-comment hover:text-day-accent dark:hover:text-night-cyan hover:border-day-accent dark:hover:border-night-cyan transition-all"
                  whileHover={{ y: -3 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4" />
                </motion.a>
              ))}
            </div>
          </div>
  
          {/* Built with */}
          <motion.div
            className="mt-6 text-center text-xs text-day-comment dark:text-night-comment"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <span>{t('builtWith')} </span>
            <Heart className="w-3 h-3 inline text-day-red dark:text-night-red" />
            <span> {t('using')} </span>
            <span className="text-day-accent dark:text-night-cyan">Next.js</span>
            <span>, </span>
            <span className="text-day-accent dark:text-night-cyan">Tailwind CSS</span>
            <span> & </span>
            <span className="text-day-accent dark:text-night-cyan">Framer Motion</span>
          </motion.div>
        </div>
      </footer>
    );
  }
  
  ```

  #### ✏️ `theme-toggle.tsx`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\theme-toggle.tsx`

  **🔴 Old:**

  ```
  'use client';
  
  import { useTheme } from 'next-themes';
  import { useEffect, useState } from 'react';
  import { Moon, Sun } from 'lucide-react';
  import { motion } from 'framer-motion';
  
  export function ThemeToggle() {
    const [mounted, setMounted] = useState(false);
    const { theme, setTheme } = useTheme();
  
    useEffect(() => {
      setMounted(true);
    }, []);
  
    if (!mounted) {
      return (
        <div className="w-10 h-10 rounded-full bg-day-bg-alt dark:bg-night-bg-alt" />
      );
    }
  
    const isDark = theme === 'dark';
  
    return (
      <motion.button
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        className="relative w-10 h-10 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight flex items-center justify-center overflow-hidden"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label={`Switch to ${isDark ? 'light' : 'dark'} mode`}
      >
        <motion.div
          initial={false}
          animate={{
            y: isDark ? 0 : -30,
            opacity: isDark ? 1 : 0,
          }}
          transition={{ duration: 0.2 }}
          className="absolute"
        >
          <Moon className="w-5 h-5 text-night-cyan" />
        </motion.div>
        <motion.div
          initial={false}
          animate={{
            y: isDark ? 30 : 0,
            opacity: isDark ? 0 : 1,
          }}
          transition={{ duration: 0.2 }}
          className="absolute"
        >
          <Sun className="w-5 h-5 text-day-yellow" />
        </motion.div>
      </motion.button>
    );
  }
  
  ```

  **🟢 New:**

  ```
  'use client';
  
  import { useTheme } from 'next-themes';
  import { useTranslations } from 'next-intl';
  import { useEffect, useState } from 'react';
  import { Moon, Sun } from 'lucide-react';
  import { motion } from 'framer-motion';
  
  export function ThemeToggle() {
    const [mounted, setMounted] = useState(false);
    const { theme, setTheme } = useTheme();
    const t = useTranslations('theme');
  
    useEffect(() => {
      setMounted(true);
    }, []);
  
    if (!mounted) {
      return (
        <div className="w-10 h-10 rounded-full bg-day-bg-alt dark:bg-night-bg-alt" />
      );
    }
  
    const isDark = theme === 'dark';
  
    return (
      <motion.button
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        className="relative w-10 h-10 rounded-full bg-day-bg-alt dark:bg-night-bg-alt border border-day-bg-highlight dark:border-night-bg-highlight flex items-center justify-center overflow-hidden"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label={isDark ? t('switchToLight') : t('switchToDark')}
      >
        <motion.div
          initial={false}
          animate={{
            y: isDark ? 0 : -30,
            opacity: isDark ? 1 : 0,
          }}
          transition={{ duration: 0.2 }}
          className="absolute"
        >
          <Moon className="w-5 h-5 text-night-cyan" />
        </motion.div>
        <motion.div
          initial={false}
          animate={{
            y: isDark ? 30 : 0,
            opacity: isDark ? 0 : 1,
          }}
          transition={{ duration: 0.2 }}
          className="absolute"
        >
          <Sun className="w-5 h-5 text-day-yellow" />
        </motion.div>
      </motion.button>
    );
  }
  
  ```

  #### ✏️ `index.ts`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\index.ts`

  **🔴 Old:**

  ```
  export { ThemeProvider } from './theme-provider';
  export { ThemeToggle } from './theme-toggle';
  export { Navigation } from './navigation';
  export { Hero } from './hero';
  export { About } from './about';
  export { Experience } from './experience';
  export { Projects } from './projects';
  export { Skills } from './skills';
  export { Certifications } from './certifications';
  export { Contact } from './contact';
  export { Footer } from './footer';
  
  ```

  **🟢 New:**

  ```
  export { ThemeProvider } from './theme-provider';
  export { ThemeToggle } from './theme-toggle';
  export { LanguageSwitcher } from './language-switcher';
  export { Navigation } from './navigation';
  export { Hero } from './hero';
  export { About } from './about';
  export { Experience } from './experience';
  export { Projects } from './projects';
  export { Skills } from './skills';
  export { Certifications } from './certifications';
  export { Contact } from './contact';
  export { Footer } from './footer';
  
  ```

  #### ✏️ `request.ts`

  **📄 Path:** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\request.ts`

  **🔴 Old:**

  ```
  import { getRequestConfig } from 'next-intl/server';
  import { locales, defaultLocale, type Locale } from './config';
  
  export default getRequestConfig(async ({ locale }) => {
    // Validate that the incoming locale is valid
    const validLocale = locales.includes(locale as Locale) ? locale : defaultLocale;
  
    return {
      messages: (await import(`./locales/${validLocale}.json`)).default,
    };
  });
  
  ```

  **🟢 New:**

  ```
  import { getRequestConfig } from 'next-intl/server';
  import { locales, defaultLocale, type Locale } from './config';
  
  export default getRequestConfig(async ({ requestLocale }) => {
    // Get the locale from the request, which comes from the middleware
    let locale = await requestLocale;
  
    // Validate and fallback to default if needed
    if (!locale || !locales.includes(locale as Locale)) {
      locale = defaultLocale;
    }
  
    return {
      locale,
      messages: (await import(`./locales/${locale}.json`)).default,
    };
  });
  
  ```


---

## 👤 User Prompt #2

  **🕐 Timestamp:** 2026-01-11T18:25:50.661Z  
  **🤖 Model:** claude-4.5-opus-high-thinking  
  **💬 Conversation ID:** 83c85b86-163e-4906-b13d-5434b3bfd7ce

  ### 📝 Prompt

  i noticed some visual issues, small ones. how can we fix these together? i give you screenshots or i tell you in what component? also for the projects, i think one image is not enough right? should we make pages for each project or we keep it to only one page and we put a carousel in cards? 

  ### 📎 Attachments

  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\en.json`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\locales\fr.json`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\config.ts`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\i18n\request.ts`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\middleware.ts`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\next.config.js`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\layout.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\app\[locale]\page.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\language-switcher.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\navigation.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\hero.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\about.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\experience.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\projects.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\skills.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\certifications.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\contact.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\footer.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\theme-toggle.tsx`
  - **[file]** `c:\Users\kkhaled\Desktop\Personal\portfolio\src\components\index.ts`
  - **[file]** `c:\Users\kkhaled\.cursor\projects\c-Users-kkhaled-Desktop-Personal-portfolio\terminals\3.txt`

  ### 📋 Team Rules

  <details>
  <summary>View Team Rules</summary>

  **Angular Standard Rules**

  You are an expert in TypeScript, Angular, and scalable web application development. You write functional, maintainable, performant, and accessible code following Angular and TypeScript best practices.
  ## TypeScript Best Practices
  - Use strict type checking
  - Prefer type inference when the type is obvious
  - Avoid the `any` type; use `unknown` when type is uncertain
  ## Angular Best Practices
  - Always use standalone components over NgModules
  - Must NOT set `standalone: true` inside Angular decorators. It's the default in Angular v20+.
  - Use signals for state management
  - Implement lazy loading for feature routes
  - Do NOT use the `@HostBinding` and `@HostListener` decorators. Put host bindings inside the `host` object of the `@Component` or `@Directive` decorator instead
  - Use `NgOptimizedImage` for all static images.
    - `NgOptimizedImage` does not work for inline base64 images.
  ## Accessibility Requirements
  - It MUST pass all AXE checks.
  - It MUST follow all WCAG AA minimums, including focus management, color contrast, and ARIA attributes.
  ### Components
  - Keep components small and focused on a single responsibility
  - Use `input()` and `output()` functions instead of decorators
  - Use `computed()` for derived state
  - Set `changeDetection: ChangeDetectionStrategy.OnPush` in `@Component` decorator
  - Prefer inline templates for small components
  - Prefer Reactive forms instead of Template-driven ones
  - Do NOT use `ngClass`, use `class` bindings instead
  - Do NOT use `ngStyle`, use `style` bindings instead
  - When using external templates/styles, use paths relative to the component TS file.
  ## State Management
  - Use signals for local component state
  - Use `computed()` for derived state
  - Keep state transformations pure and predictable
  - Do NOT use `mutate` on signals, use `update` or `set` instead
  ## Templates
  - Keep templates simple and avoid complex logic
  - Use native control flow (`@if`, `@for`, `@switch`) instead of `*ngIf`, `*ngFor`, `*ngSwitch`
  - Use the async pipe to handle observables
  - Do not assume globals like (`new Date()`) are available. 
  - Do not write arrow functions in templates (they are not supported).
  - Do not write Regular expressions in templates (they are not supported).
  ## Services
  - Design services around a single responsibility
  - Use the `providedIn: 'root'` option for singleton services
  - Use the `inject()` function instead of constructor injection 
  �
  


  ---

  **Java Design & Quality Rules**

  ### **Best Practices to Follow**
  1. **File Length & Structure**
     * Never exceed 500 lines per file.
     * Organize code using folders and logical naming conventions.
  2. **OOP & Design Principles**
     * Encapsulate functionality in dedicated classes, structs, or protocols.
     * Favor composition over inheritance.
     * Follow Single Responsibility Principle (one class/function does one thing).
     * Use modular design: components should be interchangeable, testable, and loosely coupled.
  4. **Function & Class Size**
     * Keep functions under 30–40 lines.
     * If a class exceeds 200 lines, consider splitting into helper classes.
  5. **Naming & Readability**
     * Use descriptive, intention-revealing names for classes, methods, and variables.
     * Avoid vague names like data, info, helper, or temp.
  6. **Scalability Mindset**
     * Code as if others will scale it.
     * Include extension points and consider dependency injection from day one.
  7. **Avoid “God” Classes**
     * Don’t let one file or class hold everything. 



  </details>

  ### 🧠 User Rules & Memories

  <details>
  <summary>View User Rules & Memories</summary>

  **dependent files before claiming completion
Untitled**

  �
  Rule 1: Angular Component Development
  When working on ANY Angular component (features, bugs, refactoring, migrations):
  1. ALWAYS read BOTH .ts AND .html files before making changes
  2. Apply changes to BOTH TypeScript and HTML in the same session
  3. Never modify TypeScript without verifying HTML impact (and vice versa)
  4. An Angular component is a UNIT (TS + HTML + potentially CSS/spec) - treat it as such
  5. Missing signal parentheses () in templates can cause ngtsc errors without linter warnings
  
  Rule 2: Systematic Work Process
  For ANY development task (features, bugs, debugging, refactoring, migrations):
  1. Work on ONE component/file/issue at a time
  2. Read relevant files completely before making changes
  3. Report what was changed clearly after completion
  4. Wait for user approval before proceeding to next item in multi-step work
  5. Never batch multiple components/issues without explicit approval
  
  Rule 3: Verification Over Assumption
  When encountering ANY uncertainty (features, debugging, dependencies, APIs):
  1. NEVER guess or assume - verify by reading source code/docs
  2. For library defaults: check actual implementation files (.mjs, source code), not just type definitions
  3. If a solution doesn't match established patterns, ask before applying
  4. Report what cannot be verified and request guidance
  5. Check related

  *Created: 30/10/2025, 17:30:14*


  </details>

